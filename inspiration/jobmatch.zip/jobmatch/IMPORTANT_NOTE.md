# ✅ UNIFIED BACKEND - Ready to Use!

## Current Status

**Single unified backend**: `main.py`
- ✅ All existing features (offers, candidates, matching)
- ✅ All auth features (login, activation, invites)
- ✅ Shot 1 + Shot 2 fully integrated

## How to Use

### Start the Backend
```bash
python main.py
```

### Start the Frontend
```bash
cd frontend
npm run dev
```

### Access the Application
- **Frontend**: http://127.0.0.1:5173
- **Backend API**: http://127.0.0.1:8000
- **API Docs**: http://127.0.0.1:8000/docs

## Test Users

See `TEST_CREDENTIALS.md` for login credentials.

**Admin**:
- Email: `admin@test.com`
- Password: `admin123`

**Recruiter**:
- Email: `recruiter@test.com`
- Password: `recruiter123`

## What's Available

### All Features Working ✅
- ✅ User authentication (login/logout)
- ✅ Offers management
- ✅ Candidates management
- ✅ CV parsing and matching
- ✅ Applications tracker
- ✅ User invites (admin only)
- ✅ License verification
- ✅ Seat management

### Endpoints Available
- `/api/auth/*` - Authentication
- `/api/system/*` - System activation
- `/api/admin/users/*` - User management
- `/api/offers/*` - Offers
- `/api/candidates/*` - Candidates
- `/api/applications/*` - Applications
- `/api/files/*` - File uploads

## Quick Test

```bash
# Login
curl -X POST http://127.0.0.1:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"admin123"}' \
  -c cookies.txt

# Get current user
curl -b cookies.txt http://127.0.0.1:8000/api/auth/me

# List offers
curl http://127.0.0.1:8000/api/offers?limit=10
```

---

**Status**: ✅ Fully integrated and ready for testing!
