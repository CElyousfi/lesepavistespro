# ============================================================================
# SMART MATCH ENDPOINT - Add this to main.py before if __name__ == "__main__"
# ============================================================================

@app.post("/api/offers/{offer_id}/smart-match", response_model=SmartMatchResponse)
async def smart_match_candidates_to_offer(
    offer_id: str,
    top_k: int = Query(5, ge=1, le=100, description="Number of top candidates to return")
):
    """
    Smart LLM-powered matching with transparent sub-scores
    
    - Uses GPT-4 for intelligent matching with explanations
    - Falls back to deterministic matching if LLM fails
    - Returns detailed sub-scores and reasoning
    """
    
    # Check if smart matching is enabled
    if not config.SMART_MATCH_ENABLE:
        # Fallback to deterministic matching
        return await _deterministic_smart_match(offer_id, top_k)
    
    try:
        # Fetch offer
        offer = fetch_one("SELECT * FROM offers WHERE id = ?", (offer_id,))
        if not offer:
            raise HTTPException(status_code=404, detail="Offer not found")
        
        # Parse offer data - use enhanced extraction if available
        offer_data = json.loads(offer["parsed_json"])
        
        # Try to enrich with smart extraction (cached in memory)
        try:
            offer_enhanced = llm_extract_offer(offer["raw_text"])
        except:
            # Use existing parsed data
            offer_enhanced = offer_data
            offer_enhanced.setdefault("signals", {"hard_requirement_phrases": [], "preferred_phrases": []})
            offer_enhanced.setdefault("language", "fr")
        
        # Fetch all candidate profiles
        profiles_query = """
            SELECT 
                cp.candidate_id,
                cp.skills_json,
                cp.years_experience
            FROM candidate_profiles cp
            GROUP BY cp.candidate_id
        """
        
        profiles = execute_query(profiles_query, fetch=True)
        
        if not profiles:
            return SmartMatchResponse(
                mode="smart",
                offer_id=offer_id,
                offer_title=offer_enhanced.get("title", "Untitled"),
                total_candidates=0,
                results=[]
            )
        
        # Build match request for LLM
        candidates_data = []
        for profile in profiles:
            skills = json.loads(profile["skills_json"])
            candidates_data.append({
                "candidate_id": profile["candidate_id"],
                "profile": {
                    "skills": skills,
                    "years_experience": float(profile["years_experience"]),
                    "languages": [],
                    "titles": [],
                    "summary": "",
                    "confidence": 0.9,
                    "evidence": []
                }
            })
        
        # Prepare LLM request
        match_request = {
            "offer": offer_enhanced,
            "candidates": candidates_data,
            "alpha": config.SMART_MATCH_ALPHA,
            "beta": config.SMART_MATCH_BETA
        }
        
        # Call LLM for smart matching
        system = SMART_MATCH_SYS
        user = f"MATCH REQUEST:\n\n{json.dumps(match_request, ensure_ascii=False)}"
        model = config.GPT4_TURBO_MODEL or config.LLM_MODEL
        
        llm_response = call_openai_json(user, system, MATCH_RESPONSE_SCHEMA, model_override=model)
        
        # Validate and parse response
        if "results" not in llm_response:
            raise ValueError("Invalid LLM response: missing results")
        
        # Convert to SmartMatchResult objects
        results = []
        for item in llm_response["results"]:
            # Find years_experience from original profile
            years_exp = 0.0
            for p in profiles:
                if p["candidate_id"] == item["candidate_id"]:
                    years_exp = float(p["years_experience"])
                    break
            
            results.append(SmartMatchResult(
                candidate_id=item["candidate_id"],
                percent_match=int(item["percent_match"]),
                subscores=item["subscores"],
                matched_skills=item["matched_skills"],
                missing_must_haves=item["missing_must_haves"],
                nice_hits=item["nice_hits"],
                explanation=item["explanation"],
                years_experience=years_exp
            ))
        
        # Sort by percent_match descending
        results.sort(key=lambda x: x.percent_match, reverse=True)
        
        # Take top K
        top_results = results[:top_k]
        
        # Cache results in matches table
        for result in top_results:
            match_id = str(uuid.uuid4())
            match_details = json.dumps({
                "mode": "smart",
                "result": result.dict()
            }, ensure_ascii=False)
            
            try:
                execute_query(
                    "INSERT INTO matches (id, offer_id, candidate_id, score, match_details) VALUES (?, ?, ?, ?, ?)",
                    (match_id, offer_id, result.candidate_id, result.percent_match, match_details)
                )
            except:
                pass  # Ignore duplicate errors
        
        return SmartMatchResponse(
            mode="smart",
            offer_id=offer_id,
            offer_title=offer_enhanced.get("title", "Untitled"),
            total_candidates=len(results),
            results=top_results
        )
    
    except Exception as e:
        # Fallback to deterministic matching on any error
        print(f"Smart match failed: {e}, falling back to deterministic")
        return await _deterministic_smart_match(offer_id, top_k)


async def _deterministic_smart_match(offer_id: str, top_k: int) -> SmartMatchResponse:
    """
    Deterministic fallback matching that returns SmartMatchResponse format
    """
    # Fetch offer
    offer = fetch_one("SELECT * FROM offers WHERE id = ?", (offer_id,))
    if not offer:
        raise HTTPException(status_code=404, detail="Offer not found")
    
    # Parse offer data
    offer_data = json.loads(offer["parsed_json"])
    
    # Fetch all candidate profiles
    profiles_query = """
        SELECT 
            cp.candidate_id,
            cp.skills_json,
            cp.years_experience
        FROM candidate_profiles cp
        GROUP BY cp.candidate_id
    """
    
    profiles = execute_query(profiles_query, fetch=True)
    
    if not profiles:
        return SmartMatchResponse(
            mode="deterministic",
            offer_id=offer_id,
            offer_title=offer_data.get("title", "Untitled"),
            total_candidates=0,
            results=[]
        )
    
    # Compute scores for all candidates using deterministic algorithm
    results = []
    
    for profile in profiles:
        skills = json.loads(profile["skills_json"])
        
        match_data = compute_match_score(
            offer_data=offer_data,
            candidate_skills=skills,
            alpha=config.SMART_MATCH_ALPHA,
            beta=config.SMART_MATCH_BETA
        )
        
        # Convert to SmartMatchResult format
        subscores = {
            "required_coverage": match_data["required_coverage"] / 100.0,
            "preferred_coverage": match_data["preferred_coverage"] / 100.0,
            "experience_fit": 0.8,  # Neutral default
            "language_fit": 0.5  # Neutral default
        }
        
        results.append(SmartMatchResult(
            candidate_id=profile["candidate_id"],
            percent_match=match_data["percent"],
            subscores=subscores,
            matched_skills=match_data["matched_skills"],
            missing_must_haves=match_data["missing_must_haves"],
            nice_hits=match_data["nice_hits"],
            explanation=match_data["explanation"] + " (deterministic)",
            years_experience=profile["years_experience"]
        ))
    
    # Sort by score descending
    results.sort(key=lambda x: x.percent_match, reverse=True)
    
    # Take top K
    top_results = results[:top_k]
    
    # Cache results
    for result in top_results:
        match_id = str(uuid.uuid4())
        match_details = json.dumps({
            "mode": "deterministic",
            "result": result.dict()
        }, ensure_ascii=False)
        
        try:
            execute_query(
                "INSERT INTO matches (id, offer_id, candidate_id, score, match_details) VALUES (?, ?, ?, ?, ?)",
                (match_id, offer_id, result.candidate_id, result.percent_match, match_details)
            )
        except:
            pass
    
    return SmartMatchResponse(
        mode="deterministic",
        offer_id=offer_id,
        offer_title=offer_data.get("title", "Untitled"),
        total_candidates=len(results),
        results=top_results
    )
