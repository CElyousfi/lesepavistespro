import sys
from pathlib import Path
import uuid
from datetime import datetime

# Ensure project root on path
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.append(str(PROJECT_ROOT))

from backend.api.database import execute_query, fetch_one  # noqa: E402
from backend.api.utils import hash_password  # noqa: E402


def create_user(email: str, first_name: str, last_name: str, role: str, password: str, must_change: bool = False):
    existing = fetch_one("SELECT id FROM users WHERE email = ?", (email.lower(),))
    if existing:
        print(f"User already exists: {email}")
        return existing['id']

    user_id = str(uuid.uuid4())
    password_hash = hash_password(password) if password else None
    now = datetime.now().isoformat()
    execute_query(
        """INSERT INTO users (id, email, password_hash, first_name, last_name, role, is_active, must_change_password, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, TRUE, ?, ?, ?)""",
        (user_id, email.lower(), password_hash, first_name, last_name, role, must_change, now, now)
    )
    print(f"Created {role}: {email} (id={user_id})")
    return user_id


def main():
    # Ensure users table exists (SQLite-compatible DDL)
    execute_query(
        """
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NULL,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'recruiter',
            must_change_password INTEGER NOT NULL DEFAULT 0,
            org_id TEXT NULL,
            external_user_id TEXT NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            deleted_at TEXT NULL,
            created_at TEXT,
            updated_at TEXT
        )
        """
    )

    # Default demo users
    create_user("admin@example.com", "Admin", "User", "admin", "Admin123!", must_change=False)
    create_user("recruiter@example.com", "Recruiter", "User", "recruiter", "Recruiter123!", must_change=False)


if __name__ == "__main__":
    main()


