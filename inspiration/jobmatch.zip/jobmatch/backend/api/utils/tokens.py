"""JWT token utilities"""
import jwt
from datetime import datetime, timedelta
from typing import Dict, Optional
from backend.api.config import config

def create_access_token(user_id: str, email: str, role: str) -> str:
    """Create an access token"""
    payload = {
        'user_id': user_id,
        'email': email,
        'role': role,
        'type': 'access',
        'exp': datetime.utcnow() + timedelta(minutes=config.ACCESS_TOKEN_MINUTES),
        'iat': datetime.utcnow()
    }
    return jwt.encode(payload, config.JWT_SECRET, algorithm=config.JWT_ALG)

def create_refresh_token(user_id: str) -> str:
    """Create a refresh token"""
    payload = {
        'user_id': user_id,
        'type': 'refresh',
        'exp': datetime.utcnow() + timedelta(days=config.REFRESH_TOKEN_DAYS),
        'iat': datetime.utcnow()
    }
    return jwt.encode(payload, config.JWT_SECRET, algorithm=config.JWT_ALG)

def verify_token(token: str, token_type: str = 'access') -> Optional[Dict]:
    """Verify and decode a JWT token"""
    try:
        payload = jwt.decode(token, config.JWT_SECRET, algorithms=[config.JWT_ALG])
        if payload.get('type') != token_type:
            return None
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None
