"""Email sending utilities"""
import aiosmtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from backend.api.config import config

async def send_email(to_email: str, subject: str, html_body: str, text_body: str = None):
    """Send an email via SMTP"""
    
    # Skip if SMTP not configured
    if not config.SMTP_HOST:
        print(f"⚠️  SMTP not configured, skipping email to {to_email}")
        print(f"   Subject: {subject}")
        print(f"   Body: {text_body or html_body[:100]}...")
        return
    
    message = MIMEMultipart('alternative')
    message['From'] = f"{config.SMTP_FROM_NAME} <{config.SMTP_FROM_EMAIL}>"
    message['To'] = to_email
    message['Subject'] = subject
    
    # Add text and HTML parts
    if text_body:
        part1 = MIMEText(text_body, 'plain')
        message.attach(part1)
    
    part2 = MIMEText(html_body, 'html')
    message.attach(part2)
    
    try:
        await aiosmtplib.send(
            message,
            hostname=config.SMTP_HOST,
            port=config.SMTP_PORT,
            username=config.SMTP_USER,
            password=config.SMTP_PASSWORD,
            use_tls=config.SMTP_TLS
        )
        print(f"✓ Email sent to {to_email}")
    except Exception as e:
        print(f"✗ Failed to send email to {to_email}: {e}")
        raise
