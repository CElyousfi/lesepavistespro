"""Password hashing utilities using Argon2"""
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

ph = PasswordHasher()

def hash_password(password: str) -> str:
    """Hash a password using Argon2"""
    return ph.hash(password)

def verify_password(password_hash: str, password: str) -> bool:
    """Verify a password against its hash"""
    try:
        ph.verify(password_hash, password)
        # Check if rehashing is needed (Argon2 will update parameters over time)
        if ph.check_needs_rehash(password_hash):
            # In production, you'd update the hash in the database here
            pass
        return True
    except VerifyMismatchError:
        return False
