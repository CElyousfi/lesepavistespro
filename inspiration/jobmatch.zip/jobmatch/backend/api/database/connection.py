"""Database connection and query utilities"""
import sys
from contextlib import contextmanager
from fastapi import HTTPException
from backend.api.config import config

# Prefer MariaDB connector; fall back to PyMySQL (pure Python) if unavailable
try:
    import mariadb as db_driver
    DB_BACKEND = "mariadb"
    DictCursor = None  # MariaDB connector supports dictionary=True
except Exception:  # ModuleNotFoundError or other import issues
    import pymysql as db_driver
    from pymysql.cursors import DictCursor  # type: ignore
    DB_BACKEND = "pymysql"

@contextmanager
def get_db_connection():
    """Get a database connection from the pool"""
    conn = None
    try:
        # Attempt MariaDB/MySQL first
        try:
            conn = db_driver.connect(
                host=config.DB_HOST,
                port=config.DB_PORT,
                user=config.DB_USER,
                password=config.DB_PASSWORD,
                database=config.DB_NAME
            )
            yield conn
        except Exception as primary_error:
            # Fallback to SQLite (same as application startup fallback)
            import sqlite3
            from pathlib import Path
            storage_root = Path(config.STORAGE_ROOT)
            storage_root.mkdir(parents=True, exist_ok=True)
            db_path = storage_root / "jobmatch.db"
            conn = sqlite3.connect(str(db_path))
            conn.row_factory = sqlite3.Row
            yield conn
    except Exception as e:
        print(f"Database connection error: {e}")
        raise HTTPException(status_code=500, detail=f"Database error: {str(e)}")
    finally:
        if conn:
            conn.close()

def execute_query(query: str, params: tuple = None, fetch: bool = False):
    """Execute a database query"""
    with get_db_connection() as conn:
        # Convert placeholder style only for MySQL drivers
        conn_module = getattr(conn.__class__, '__module__', '')
        if not conn_module.startswith('sqlite3'):
            query_to_run = query.replace('?', '%s')
        else:
            # Convert MySQL-ish DDL to SQLite where needed
            qt = query
            upper = qt.strip().upper()
            if upper.startswith('CREATE TABLE') or upper.startswith('ALTER TABLE'):
                # Drop ENGINE/CHARSET and ON UPDATE, convert TIMESTAMP defaults, ENUM → TEXT, BOOLEAN → INTEGER
                import re
                qt = re.sub(r"ENGINE\s*=\s*[^\s]+", "", qt, flags=re.IGNORECASE)
                qt = re.sub(r"DEFAULT\s+CHARSET\s*=\s*[^\s]+", "", qt, flags=re.IGNORECASE)
                qt = re.sub(r"COLLATE\s*=[^\s]+", "", qt, flags=re.IGNORECASE)
                qt = re.sub(r"ON\s+UPDATE\s+CURRENT_TIMESTAMP", "", qt, flags=re.IGNORECASE)
                qt = re.sub(r"\bTIMESTAMP\b\s+DEFAULT\s+CURRENT_TIMESTAMP", "TEXT", qt, flags=re.IGNORECASE)
                qt = re.sub(r"\bDATETIME\b", "TEXT", qt, flags=re.IGNORECASE)
                qt = re.sub(r"\bLONGTEXT\b", "TEXT", qt, flags=re.IGNORECASE)
                qt = re.sub(r"\bENUM\s*\([^)]*\)", "TEXT", qt, flags=re.IGNORECASE)
                qt = re.sub(r"\bBOOLEAN\b", "INTEGER", qt, flags=re.IGNORECASE)
                # Remove inline INDEX definitions inside CREATE TABLE (SQLite doesn't allow them inside)
                qt = re.sub(r",\s*INDEX\s+[^)]+", "", qt, flags=re.IGNORECASE)
                qt = re.sub(r",\s*UNIQUE\s+KEY\s+[^)]+", "", qt, flags=re.IGNORECASE)
                qt = re.sub(r"\)\s*ENGINE[^;]*;?\s*$", ")", qt, flags=re.IGNORECASE | re.MULTILINE)
            query_to_run = qt
        # Choose appropriate cursor based on the actual connection type
        if conn_module.startswith('sqlite3'):
            cursor = conn.cursor()
        elif DB_BACKEND == 'pymysql':
            cursor = conn.cursor(DictCursor)
        else:  # MariaDB connector
            cursor = conn.cursor(dictionary=True)
        cursor.execute(query_to_run, params or ())
        
        if fetch:
            result = cursor.fetchall()
            # Normalize sqlite3.Row to dict for consistency
            if conn_module.startswith('sqlite3') and result:
                result = [dict(r) for r in result]
            cursor.close()
            return result
        else:
            conn.commit()
            last_id = cursor.lastrowid
            cursor.close()
            return last_id

def fetch_one(query: str, params: tuple = None):
    """Fetch a single row"""
    with get_db_connection() as conn:
        # Convert placeholder style only for MySQL drivers
        conn_module = getattr(conn.__class__, '__module__', '')
        if not conn_module.startswith('sqlite3'):
            query_to_run = query.replace('?', '%s')
        else:
            query_to_run = query
        # Choose appropriate cursor based on the actual connection type
        if conn_module.startswith('sqlite3'):
            cursor = conn.cursor()
        elif DB_BACKEND == 'pymysql':
            cursor = conn.cursor(DictCursor)
        else:  # MariaDB connector
            cursor = conn.cursor(dictionary=True)
        cursor.execute(query_to_run, params or ())
        result = cursor.fetchone()
        # Normalize sqlite3.Row to dict
        if conn_module.startswith('sqlite3') and result is not None:
            result = dict(result)
        cursor.close()
        return result

def init_database():
    """Initialize database tables and run migrations"""
    print("\n" + "="*60)
    print("🔧 Initializing Database Schema")
    print("="*60)
    
    # Import migrations
    from .migrations import run_all_migrations
    
    try:
        run_all_migrations()
        print("✓ Database initialization complete")
    except Exception as e:
        print(f"ERROR: Failed to initialize database: {e}")
        sys.exit(1)
