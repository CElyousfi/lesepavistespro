"""Database migrations for JobMatch"""
from .connection import execute_query, db_pool

def run_all_migrations():
    """Run all database migrations in order"""
    
    # Step 1: Create base tables
    create_base_tables()
    
    # Step 2: Create auth tables
    create_auth_tables()
    
    # Step 3: Run column migrations
    run_column_migrations()
    
    # Step 4: Create indexes
    create_indexes()

def create_base_tables():
    """Create base application tables"""
    print("→ Creating base tables...")
    
    tables = [
        # Users table
        """
        CREATE TABLE IF NOT EXISTS users (
            id VARCHAR(36) PRIMARY KEY,
            email VARCHAR(255) NOT NULL UNIQUE,
            password_hash VARCHAR(255) NULL,
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            role ENUM('admin','recruiter') NOT NULL DEFAULT 'recruiter',
            must_change_password BOOLEAN NOT NULL DEFAULT FALSE,
            org_id VARCHAR(36) NULL,
            external_user_id VARCHAR(64) NULL,
            is_active BOOLEAN NOT NULL DEFAULT TRUE,
            deleted_at DATETIME NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_email (email),
            INDEX idx_org (org_id),
            INDEX idx_active (is_active),
            INDEX idx_deleted (deleted_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        
        # Offers table
        """
        CREATE TABLE IF NOT EXISTS offers (
            id VARCHAR(36) PRIMARY KEY,
            raw_text LONGTEXT NOT NULL,
            parsed_json LONGTEXT,
            status VARCHAR(50) DEFAULT 'active',
            remote_policy VARCHAR(50) DEFAULT 'on_site',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_created (created_at),
            INDEX idx_status (status),
            INDEX idx_remote_policy (remote_policy)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        
        # Candidates table
        """
        CREATE TABLE IF NOT EXISTS candidates (
            id VARCHAR(36) PRIMARY KEY,
            first_name VARCHAR(80) NULL,
            last_name VARCHAR(80) NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        
        # Candidate files table
        """
        CREATE TABLE IF NOT EXISTS candidate_files (
            id VARCHAR(36) PRIMARY KEY,
            candidate_id VARCHAR(36) NOT NULL,
            file_path VARCHAR(512) NOT NULL,
            file_name VARCHAR(255) NOT NULL,
            file_type VARCHAR(50) DEFAULT 'application/pdf',
            kind VARCHAR(32) DEFAULT 'resume',
            mime VARCHAR(64) DEFAULT 'application/pdf',
            extracted_text LONGTEXT,
            is_parsed BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE,
            INDEX idx_candidate (candidate_id),
            INDEX idx_candidate_kind (candidate_id, kind)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        
        # Candidate profiles table
        """
        CREATE TABLE IF NOT EXISTS candidate_profiles (
            id VARCHAR(36) PRIMARY KEY,
            candidate_id VARCHAR(36) NOT NULL,
            file_id VARCHAR(36) NOT NULL,
            skills_json LONGTEXT NOT NULL,
            years_experience DECIMAL(4,1) DEFAULT 0.0,
            email VARCHAR(255) NULL,
            phone VARCHAR(64) NULL,
            location VARCHAR(255) NULL,
            current_title VARCHAR(255) NULL,
            socials_json LONGTEXT NULL,
            contact_json LONGTEXT NULL,
            lang VARCHAR(8) NULL,
            pii_version INT DEFAULT 1,
            profile_json LONGTEXT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE,
            FOREIGN KEY (file_id) REFERENCES candidate_files(id) ON DELETE CASCADE,
            INDEX idx_candidate (candidate_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        
        # Matches table
        """
        CREATE TABLE IF NOT EXISTS matches (
            id VARCHAR(36) PRIMARY KEY,
            offer_id VARCHAR(36) NOT NULL,
            candidate_id VARCHAR(36) NOT NULL,
            score INT NOT NULL,
            match_details LONGTEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (offer_id) REFERENCES offers(id) ON DELETE CASCADE,
            FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE,
            INDEX idx_offer (offer_id),
            INDEX idx_candidate (candidate_id),
            INDEX idx_score (score)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        
        # Applications table
        """
        CREATE TABLE IF NOT EXISTS applications (
            id VARCHAR(36) PRIMARY KEY,
            offer_id VARCHAR(36) NOT NULL,
            candidate_id VARCHAR(36) NOT NULL,
            match_id VARCHAR(36),
            status VARCHAR(50) DEFAULT 'bookmarked',
            stage VARCHAR(50) DEFAULT 'bookmarked',
            match_score INT,
            date_bookmarked TIMESTAMP,
            date_applied TIMESTAMP,
            date_interviewing TIMESTAMP,
            date_negotiating TIMESTAMP,
            date_accepted TIMESTAMP,
            date_rejected TIMESTAMP,
            notes LONGTEXT,
            excitement_level INT DEFAULT 0,
            salary_expectation VARCHAR(100),
            follow_up_date DATE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (offer_id) REFERENCES offers(id) ON DELETE CASCADE,
            FOREIGN KEY (candidate_id) REFERENCES candidates(id) ON DELETE CASCADE,
            FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE SET NULL,
            INDEX idx_offer (offer_id),
            INDEX idx_candidate (candidate_id),
            INDEX idx_status (status),
            INDEX idx_stage (stage),
            UNIQUE KEY unique_application (offer_id, candidate_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        
        # App settings table
        """
        CREATE TABLE IF NOT EXISTS app_settings (
            k VARCHAR(64) PRIMARY KEY,
            v LONGTEXT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        
        # LLM calls table
        """
        CREATE TABLE IF NOT EXISTS llm_calls (
            id VARCHAR(36) PRIMARY KEY,
            purpose VARCHAR(32) NOT NULL,
            lang VARCHAR(8) NOT NULL,
            token_count INT NULL,
            redaction_level VARCHAR(16) NOT NULL,
            payload_hash CHAR(64) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """
    ]
    
    for table_sql in tables:
        execute_query(table_sql)
    
    print("  ✓ Base tables created")

def create_auth_tables():
    """Create authentication and licensing tables"""
    print("→ Creating auth tables...")
    
    tables = [
        # Licenses table
        """
        CREATE TABLE IF NOT EXISTS licenses (
            id VARCHAR(36) PRIMARY KEY,
            org_id VARCHAR(36) NOT NULL,
            plan VARCHAR(64) NOT NULL,
            seats INT NOT NULL,
            expires_at DATETIME NOT NULL,
            status ENUM('active','expired','revoked','pending') NOT NULL DEFAULT 'active',
            license_jwt LONGTEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_org (org_id),
            INDEX idx_status (status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        
        # Activation codes table
        """
        CREATE TABLE IF NOT EXISTS activation_codes (
            id VARCHAR(36) PRIMARY KEY,
            email VARCHAR(255) NOT NULL,
            activation_key VARCHAR(128) NOT NULL,
            code_hash CHAR(64) NOT NULL,
            expires_at DATETIME NOT NULL,
            attempts INT NOT NULL DEFAULT 0,
            verified BOOLEAN NOT NULL DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_email_key (email, activation_key)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        
        # User invites table
        """
        CREATE TABLE IF NOT EXISTS user_invites (
            id VARCHAR(36) PRIMARY KEY,
            email VARCHAR(255) NOT NULL,
            first_name VARCHAR(100) NOT NULL,
            last_name VARCHAR(100) NOT NULL,
            role ENUM('admin','recruiter') NOT NULL DEFAULT 'recruiter',
            token CHAR(64) NOT NULL,
            expires_at DATETIME NOT NULL,
            consumed_at DATETIME NULL,
            created_by VARCHAR(36) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_invite_token (token),
            INDEX idx_email_exp (email, expires_at),
            FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """
    ]
    
    for table_sql in tables:
        execute_query(table_sql)
    
    print("  ✓ Auth tables created")

def run_column_migrations():
    """Run column addition migrations (idempotent)"""
    print("→ Running column migrations...")
    
    # These are already in the table definitions above, but keeping for existing DBs
    migrations = []
    
    for migration_sql in migrations:
        try:
            execute_query(migration_sql)
        except Exception:
            pass  # Column already exists
    
    print("  ✓ Column migrations complete")

def create_indexes():
    """Create additional indexes for performance"""
    print("→ Creating indexes...")
    
    indexes = [
        ("idx_matches_offer", "matches", "offer_id"),
        ("idx_matches_candidate", "matches", "candidate_id"),
        ("idx_matches_score", "matches", "score"),
        ("idx_matches_created", "matches", "created_at"),
        ("idx_candidate_files_candidate", "candidate_files", "candidate_id"),
        ("idx_candidate_profiles_candidate", "candidate_profiles", "candidate_id"),
        ("idx_offers_created", "offers", "created_at"),
        ("idx_candidates_created", "candidates", "created_at"),
    ]
    
    for idx_name, table_name, column_name in indexes:
        try:
            execute_query(f"CREATE INDEX {idx_name} ON {table_name}({column_name})")
        except Exception:
            pass  # Index already exists
    
    print("  ✓ Indexes created")
