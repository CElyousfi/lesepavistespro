"""Application settings loaded from environment variables"""
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Application configuration"""
    
    # Database
    DB_HOST = os.getenv('DB_HOST', '127.0.0.1')
    DB_PORT = int(os.getenv('DB_PORT', '3306'))
    DB_USER = os.getenv('DB_USER', 'jobmatch')
    DB_PASSWORD = os.getenv('DB_PASSWORD', 'jobmatch_pw')
    DB_NAME = os.getenv('DB_NAME', 'jobmatch_db')
    
    # Application
    APP_PORT = int(os.getenv('APP_PORT', '8000'))
    # Use absolute storage path under backend/ by default to avoid CWD issues
    DEFAULT_STORAGE = str(Path(__file__).resolve().parents[2] / 'storage')
    STORAGE_ROOT = os.getenv('STORAGE_ROOT', DEFAULT_STORAGE)
    
    # OpenAI
    OPENAI_API_KEY = os.getenv('OPENAI_API_KEY', '')
    
    # JWT & Session
    JWT_SECRET = os.getenv('JWT_SECRET', 'change_me_to_a_secure_random_string_in_production')
    JWT_ALG = os.getenv('JWT_ALG', 'HS256')
    ACCESS_TOKEN_MINUTES = int(os.getenv('ACCESS_TOKEN_MINUTES', '30'))
    REFRESH_TOKEN_DAYS = int(os.getenv('REFRESH_TOKEN_DAYS', '7'))
    COOKIE_DOMAIN = os.getenv('COOKIE_DOMAIN', '127.0.0.1')
    COOKIE_SECURE = os.getenv('COOKIE_SECURE', 'false').lower() == 'true'
    
    # Central Licensing
    LICENSE_API_BASE = os.getenv('LICENSE_API_BASE', 'https://license.yourcompany.com')
    LICENSE_API_KEY = os.getenv('LICENSE_API_KEY', 'your_server_to_server_key')
    LICENSE_PUBLIC_KEY_PEM = os.getenv('LICENSE_PUBLIC_KEY_PEM', '').replace('\\n', '\n')
    
    # SMTP (Invite Emails)
    SMTP_HOST = os.getenv('SMTP_HOST', '')
    SMTP_PORT = int(os.getenv('SMTP_PORT', '587'))
    SMTP_USER = os.getenv('SMTP_USER', '')
    SMTP_PASSWORD = os.getenv('SMTP_PASSWORD', '')
    SMTP_TLS = os.getenv('SMTP_TLS', 'true').lower() == 'true'
    SMTP_FROM_EMAIL = os.getenv('SMTP_FROM_EMAIL', 'noreply@yourcompany.com')
    SMTP_FROM_NAME = os.getenv('SMTP_FROM_NAME', 'JobMatch ATS')
    
    # Public Base URL (for invite links)
    PUBLIC_BASE_URL = os.getenv('PUBLIC_BASE_URL', 'http://127.0.0.1:5173')

config = Config()
