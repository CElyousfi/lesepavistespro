"""Configuration module for JobMatch API"""
from .settings import config

__all__ = ['config']
