"""License verification and seat management"""
import jwt
from datetime import datetime
from typing import Optional, Dict
from fastapi import HTTPException
from backend.api.config import config
from backend.api.database import fetch_one, execute_query

def verify_license_jwt(license_jwt: str) -> Optional[Dict]:
    """Verify a license JWT signature and expiration"""
    try:
        # For MVP, we'll use symmetric key (HS256) instead of asymmetric (RS256)
        # In production, you'd use the public key from LICENSE_PUBLIC_KEY_PEM
        payload = jwt.decode(
            license_jwt,
            config.JWT_SECRET,  # In prod: use public key
            algorithms=['HS256']  # In prod: ['RS256', 'ES256']
        )
        
        # Check expiration
        exp = payload.get('exp')
        if exp and datetime.utcfromtimestamp(exp) < datetime.utcnow():
            return None
        
        return payload
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

def get_current_license() -> Optional[Dict]:
    """Get the current active license"""
    license_row = fetch_one(
        """SELECT * FROM licenses 
           WHERE status IN ('active', 'pending') 
           ORDER BY created_at DESC 
           LIMIT 1"""
    )
    
    if not license_row:
        return None
    
    # Verify the JWT
    payload = verify_license_jwt(license_row['license_jwt'])
    if not payload:
        return None
    
    return {
        'id': license_row['id'],
        'org_id': license_row['org_id'],
        'plan': license_row['plan'],
        'seats': license_row['seats'],
        'expires_at': license_row['expires_at'],
        'status': license_row['status'],
        'payload': payload
    }

def require_valid_license():
    """Dependency to require a valid license"""
    license_data = get_current_license()
    if not license_data:
        raise HTTPException(
            status_code=403,
            detail="No valid license found. Please activate your installation."
        )
    
    # Check if expired
    if license_data['expires_at'] < datetime.now():
        raise HTTPException(
            status_code=403,
            detail="License has expired. Please renew your license."
        )
    
    return license_data

def seats_available() -> bool:
    """Check if there are available seats"""
    license_data = get_current_license()
    if not license_data:
        return False
    
    # Count active users
    result = fetch_one("SELECT COUNT(*) as count FROM users WHERE is_active = TRUE AND deleted_at IS NULL")
    active_users = result['count'] if result else 0
    
    return active_users < license_data['seats']

def get_seat_info() -> Dict:
    """Get current seat usage information"""
    license_data = get_current_license()
    if not license_data:
        return {'total': 0, 'used': 0, 'available': 0}
    
    result = fetch_one("SELECT COUNT(*) as count FROM users WHERE is_active = TRUE AND deleted_at IS NULL")
    used = result['count'] if result else 0
    
    return {
        'total': license_data['seats'],
        'used': used,
        'available': license_data['seats'] - used
    }
