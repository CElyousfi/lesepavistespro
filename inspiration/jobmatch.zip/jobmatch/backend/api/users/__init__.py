"""User management module"""
from .routes import router as users_router

__all__ = ['users_router']
