"""User management and invite routes"""
from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, EmailStr
from datetime import datetime, timedelta
import uuid
import secrets

from backend.api.database import execute_query, fetch_one
from backend.api.config import config
from backend.api.auth.dependencies import require_admin
from backend.api.license import seats_available, get_seat_info
from backend.api.utils import send_email

router = APIRouter(prefix="/api/admin/users", tags=["users"])

# Pydantic models
class InviteUserRequest(BaseModel):
    email: EmailStr
    first_name: str
    last_name: str
    role: str = 'recruiter'

@router.post("/invite")
async def invite_user(request: InviteUserRequest, admin: dict = Depends(require_admin)):
    """Invite a new user (admin only)"""
    # Validate role
    if request.role not in ['admin', 'recruiter']:
        raise HTTPException(status_code=400, detail="Invalid role")
    
    # Check seats
    if not seats_available():
        raise HTTPException(status_code=403, detail="No available seats. Please upgrade your plan.")
    
    # Check if user already exists
    existing_user = fetch_one(
        "SELECT * FROM users WHERE email = ?",
        (request.email.lower(),)
    )
    
    if existing_user:
        if existing_user['is_active'] and not existing_user['deleted_at']:
            raise HTTPException(status_code=409, detail="User already exists")
        else:
            raise HTTPException(status_code=409, detail="User exists but is inactive")
    
    # Check if pending invite exists
    pending_invite = fetch_one(
        """SELECT * FROM user_invites 
           WHERE email = ? 
           AND consumed_at IS NULL 
           AND expires_at > NOW()""",
        (request.email.lower(),)
    )
    
    if pending_invite:
        raise HTTPException(status_code=409, detail="Invite already sent to this email")
    
    # Create invite
    invite_id = str(uuid.uuid4())
    token = secrets.token_hex(32)  # 64 character hex string
    expires_at = datetime.now() + timedelta(days=7)
    
    execute_query(
        """INSERT INTO user_invites (id, email, first_name, last_name, role, token, expires_at, created_by)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            invite_id,
            request.email.lower(),
            request.first_name,
            request.last_name,
            request.role,
            token,
            expires_at,
            admin['id']
        )
    )
    
    # Send invite email
    invite_link = f"{config.PUBLIC_BASE_URL}/accept-invite?token={token}"
    
    html_body = f"""
    <html>
    <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px;">
            <h2 style="color: #0d9488;">You're invited to join JobMatch!</h2>
            <p>Hi {request.first_name},</p>
            <p>{admin['first_name']} {admin['last_name']} has invited you to join their JobMatch team as a <strong>{request.role}</strong>.</p>
            <p>Click the button below to accept the invitation and set your password:</p>
            <div style="text-align: center; margin: 30px 0;">
                <a href="{invite_link}" 
                   style="background-color: #0d9488; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">
                    Accept Invitation
                </a>
            </div>
            <p style="color: #666; font-size: 14px;">Or copy and paste this link into your browser:</p>
            <p style="color: #666; font-size: 14px; word-break: break-all;">{invite_link}</p>
            <p style="color: #666; font-size: 14px; margin-top: 30px;">This invitation expires in 7 days.</p>
            <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
            <p style="color: #999; font-size: 12px;">If you didn't expect this invitation, you can safely ignore this email.</p>
        </div>
    </body>
    </html>
    """
    
    text_body = f"""
You're invited to join JobMatch!

Hi {request.first_name},

{admin['first_name']} {admin['last_name']} has invited you to join their JobMatch team as a {request.role}.

Accept the invitation and set your password by visiting:
{invite_link}

This invitation expires in 7 days.

If you didn't expect this invitation, you can safely ignore this email.
    """
    
    try:
        await send_email(
            to_email=request.email,
            subject=f"You're invited to join JobMatch",
            html_body=html_body,
            text_body=text_body
        )
    except Exception as e:
        print(f"Failed to send invite email: {e}")
        # Don't fail the request if email fails
    
    return {
        "ok": True,
        "invite_id": invite_id,
        "message": "Invitation sent successfully"
    }

@router.get("/seats")
async def get_seats(admin: dict = Depends(require_admin)):
    """Get seat usage information"""
    return get_seat_info()

@router.get("/list")
async def list_users(admin: dict = Depends(require_admin)):
    """List all users"""
    users = execute_query(
        """SELECT id, email, first_name, last_name, role, is_active, created_at, deleted_at
           FROM users 
           WHERE deleted_at IS NULL
           ORDER BY created_at DESC""",
        fetch=True
    )
    
    return {"users": users or [], "count": len(users) if users else 0}

@router.get("/invites")
async def list_invites(admin: dict = Depends(require_admin)):
    """List pending invites"""
    invites = execute_query(
        """SELECT i.id, i.email, i.first_name, i.last_name, i.role, i.expires_at, i.created_at,
                  u.first_name as invited_by_first_name, u.last_name as invited_by_last_name
           FROM user_invites i
           LEFT JOIN users u ON i.created_by = u.id
           WHERE i.consumed_at IS NULL
           ORDER BY i.created_at DESC""",
        fetch=True
    )
    
    return {"invites": invites or [], "count": len(invites) if invites else 0}
