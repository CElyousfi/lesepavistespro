"""System activation and bootstrap routes"""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from datetime import datetime, timedelta
import uuid
import hashlib
import requests

from backend.api.database import execute_query, fetch_one
from backend.api.config import config
from backend.api.license import verify_license_jwt

router = APIRouter(prefix="/api/system", tags=["system"])

# Pydantic models
class RequestCodeRequest(BaseModel):
    activation_key: str
    admin_email: EmailStr

class VerifyCodeRequest(BaseModel):
    activation_key: str
    admin_email: EmailStr
    code: str

@router.get("/bootstrap-status")
async def bootstrap_status():
    """Check if system needs activation"""
    # Check if any admin user exists
    admin = fetch_one("SELECT COUNT(*) as count FROM users WHERE role = 'admin'")
    needs_activation = admin['count'] == 0 if admin else True
    
    return {"needs_activation": needs_activation}

@router.post("/activate/request-code")
async def request_activation_code(request: RequestCodeRequest):
    """Request activation code from central server (Step 1)"""
    # Check if admin already exists
    admin = fetch_one("SELECT COUNT(*) as count FROM users WHERE role = 'admin'")
    if admin and admin['count'] > 0:
        raise HTTPException(status_code=409, detail="System already activated")
    
    # Generate fingerprint (simple version - in production use hardware/system info)
    fingerprint = hashlib.sha256(f"{config.DB_NAME}-{config.APP_PORT}".encode()).hexdigest()[:16]
    
    try:
        # Call central licensing server
        response = requests.post(
            f"{config.LICENSE_API_BASE}/api/activate/send-code",
            json={
                "activation_key": request.activation_key,
                "admin_email": request.admin_email.lower(),
                "fingerprint": fingerprint
            },
            headers={
                "Authorization": f"Bearer {config.LICENSE_API_KEY}",
                "Content-Type": "application/json"
            },
            timeout=10
        )
        
        if response.status_code != 200:
            error_detail = response.json().get('detail', 'Activation failed')
            raise HTTPException(status_code=response.status_code, detail=error_detail)
        
        data = response.json()
        
        # Store activation code hash locally
        # In real implementation, central server sends the code via email
        # and returns a hash or confirmation. For MVP, we'll simulate this.
        code_id = str(uuid.uuid4())
        
        # For MVP: generate a 6-digit code (in production, central server does this)
        import random
        code = str(random.randint(100000, 999999))
        code_hash = hashlib.sha256(code.encode()).hexdigest()
        
        # Store in database
        execute_query(
            """INSERT INTO activation_codes (id, email, activation_key, code_hash, expires_at, attempts, verified)
               VALUES (?, ?, ?, ?, ?, 0, FALSE)
               ON DUPLICATE KEY UPDATE code_hash = VALUES(code_hash), expires_at = VALUES(expires_at), attempts = 0, verified = FALSE""",
            (code_id, request.admin_email.lower(), request.activation_key, code_hash, datetime.now() + timedelta(minutes=15))
        )
        
        # For MVP: print code to console (in production, it's emailed)
        print(f"\n{'='*60}")
        print(f"🔑 ACTIVATION CODE (for testing): {code}")
        print(f"   Email: {request.admin_email}")
        print(f"   Expires in 15 minutes")
        print(f"{'='*60}\n")
        
        return {"ok": True, "message": "Activation code sent to email"}
        
    except requests.RequestException as e:
        # For MVP: if central server is not available, allow local activation
        print(f"⚠️  Central server not available: {e}")
        print("   Using local activation mode for development")
        
        # Generate local activation code
        code_id = str(uuid.uuid4())
        import random
        code = str(random.randint(100000, 999999))
        code_hash = hashlib.sha256(code.encode()).hexdigest()
        
        execute_query(
            """INSERT INTO activation_codes (id, email, activation_key, code_hash, expires_at, attempts, verified)
               VALUES (?, ?, ?, ?, ?, 0, FALSE)
               ON DUPLICATE KEY UPDATE code_hash = VALUES(code_hash), expires_at = VALUES(expires_at), attempts = 0, verified = FALSE""",
            (code_id, request.admin_email.lower(), request.activation_key, code_hash, datetime.now() + timedelta(minutes=15))
        )
        
        print(f"\n{'='*60}")
        print(f"🔑 LOCAL ACTIVATION CODE: {code}")
        print(f"   Email: {request.admin_email}")
        print(f"   Expires in 15 minutes")
        print(f"{'='*60}\n")
        
        return {"ok": True, "message": "Activation code generated (local mode)"}

@router.post("/activate/verify-code")
async def verify_activation_code(request: VerifyCodeRequest):
    """Verify activation code and create admin user (Step 2)"""
    # Find activation code
    activation = fetch_one(
        """SELECT * FROM activation_codes 
           WHERE email = ? 
           AND activation_key = ? 
           AND verified = FALSE 
           AND expires_at > NOW()""",
        (request.admin_email.lower(), request.activation_key)
    )
    
    if not activation:
        raise HTTPException(status_code=404, detail="Invalid or expired activation request")
    
    # Check attempts
    if activation['attempts'] >= 5:
        raise HTTPException(status_code=429, detail="Too many attempts. Please request a new code.")
    
    # Verify code hash
    code_hash = hashlib.sha256(request.code.encode()).hexdigest()
    if code_hash != activation['code_hash']:
        # Increment attempts
        execute_query(
            "UPDATE activation_codes SET attempts = attempts + 1 WHERE id = ?",
            (activation['id'],)
        )
        raise HTTPException(status_code=401, detail="Invalid code")
    
    # Generate fingerprint
    fingerprint = hashlib.sha256(f"{config.DB_NAME}-{config.APP_PORT}".encode()).hexdigest()[:16]
    
    try:
        # Call central server to verify and get license
        response = requests.post(
            f"{config.LICENSE_API_BASE}/api/activate/verify",
            json={
                "activation_key": request.activation_key,
                "admin_email": request.admin_email.lower(),
                "code": request.code,
                "fingerprint": fingerprint
            },
            headers={
                "Authorization": f"Bearer {config.LICENSE_API_KEY}",
                "Content-Type": "application/json"
            },
            timeout=10
        )
        
        if response.status_code != 200:
            error_detail = response.json().get('detail', 'Verification failed')
            raise HTTPException(status_code=response.status_code, detail=error_detail)
        
        data = response.json()
        org = data['org']
        license_jwt = data['license_jwt']
        
    except requests.RequestException as e:
        # For MVP: if central server not available, create local license
        print(f"⚠️  Central server not available: {e}")
        print("   Creating local license for development")
        
        # Create a local license JWT
        import jwt
        org = {
            'id': str(uuid.uuid4()),
            'plan': 'starter',
            'seats': 5,
            'expires_at': (datetime.now() + timedelta(days=365)).isoformat(),
            'status': 'active'
        }
        
        license_jwt = jwt.encode(
            {
                'org_id': org['id'],
                'plan': org['plan'],
                'seats': org['seats'],
                'exp': datetime.utcnow() + timedelta(days=365),
                'iat': datetime.utcnow()
            },
            config.JWT_SECRET,
            algorithm='HS256'
        )
    
    # Verify license JWT
    payload = verify_license_jwt(license_jwt)
    if not payload:
        raise HTTPException(status_code=500, detail="Invalid license JWT received")
    
    # Store license
    license_id = str(uuid.uuid4())
    execute_query(
        """INSERT INTO licenses (id, org_id, plan, seats, expires_at, status, license_jwt)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (
            license_id,
            org['id'],
            org['plan'],
            org['seats'],
            org['expires_at'],
            org['status'],
            license_jwt
        )
    )
    
    # Create admin user (no password yet, must_change_password=TRUE)
    admin_id = str(uuid.uuid4())
    email_parts = request.admin_email.lower().split('@')
    first_name = email_parts[0].capitalize()
    
    execute_query(
        """INSERT INTO users (id, email, password_hash, first_name, last_name, role, org_id, is_active, must_change_password)
           VALUES (?, ?, NULL, ?, ?, 'admin', ?, TRUE, TRUE)""",
        (admin_id, request.admin_email.lower(), first_name, 'Admin', org['id'])
    )
    
    # Mark activation as verified
    execute_query(
        "UPDATE activation_codes SET verified = TRUE WHERE id = ?",
        (activation['id'],)
    )
    
    print(f"\n{'='*60}")
    print(f"✓ System activated successfully!")
    print(f"  Organization: {org['id']}")
    print(f"  Plan: {org['plan']}")
    print(f"  Seats: {org['seats']}")
    print(f"  Admin: {request.admin_email}")
    print(f"{'='*60}\n")
    
    return {"ok": True, "message": "Activation successful. Please set your password."}
