"""System activation and bootstrap module"""
from .routes import router as system_router

__all__ = ['system_router']
