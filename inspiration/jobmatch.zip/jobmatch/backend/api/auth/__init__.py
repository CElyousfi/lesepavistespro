"""Authentication module"""
from .routes import router as auth_router
from .dependencies import get_current_user, require_admin

__all__ = ['auth_router', 'get_current_user', 'require_admin']
