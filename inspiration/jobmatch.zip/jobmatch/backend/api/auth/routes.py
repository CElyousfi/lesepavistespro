"""Authentication routes"""
from fastapi import APIRouter, HTTPException, Response, Depends
from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime
import uuid

from backend.api.utils import hash_password, verify_password, create_access_token, create_refresh_token, verify_token
from backend.api.database import execute_query, fetch_one
from backend.api.config import config
from .dependencies import get_current_user

router = APIRouter(prefix="/api/auth", tags=["auth"])

# Pydantic models
class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class FirstSetPasswordRequest(BaseModel):
    email: EmailStr
    password: str

class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str

class AcceptInviteRequest(BaseModel):
    token: str
    password: str

# Helper function to set auth cookies
def set_auth_cookies(response: Response, user_id: str, email: str, role: str):
    """Set access and refresh token cookies"""
    access_token = create_access_token(user_id, email, role)
    refresh_token = create_refresh_token(user_id)
    
    # Access token cookie
    response.set_cookie(
        key="access_token",
        value=access_token,
        httponly=True,
        secure=config.COOKIE_SECURE,
        samesite="lax",
        max_age=config.ACCESS_TOKEN_MINUTES * 60,
        domain=config.COOKIE_DOMAIN if config.COOKIE_DOMAIN != '127.0.0.1' else None
    )
    
    # Refresh token cookie
    response.set_cookie(
        key="refresh_token",
        value=refresh_token,
        httponly=True,
        secure=config.COOKIE_SECURE,
        samesite="lax",
        max_age=config.REFRESH_TOKEN_DAYS * 24 * 60 * 60,
        domain=config.COOKIE_DOMAIN if config.COOKIE_DOMAIN != '127.0.0.1' else None
    )

@router.post("/login")
async def login(request: LoginRequest, response: Response):
    """Login with email and password"""
    # Find user
    user = fetch_one(
        "SELECT * FROM users WHERE email = ? AND is_active = TRUE AND deleted_at IS NULL",
        (request.email.lower(),)
    )
    
    if not user or not user.get('password_hash'):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    # Verify password
    if not verify_password(user['password_hash'], request.password):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    
    # Set auth cookies
    set_auth_cookies(response, user['id'], user['email'], user['role'])
    
    return {
        "ok": True,
        "user": {
            "id": user['id'],
            "email": user['email'],
            "first_name": user['first_name'],
            "last_name": user['last_name'],
            "role": user['role'],
            "must_change_password": user['must_change_password']
        }
    }

@router.post("/first-set-password")
async def first_set_password(request: FirstSetPasswordRequest, response: Response):
    """Set password for first-time admin (after activation)"""
    # Find admin user with must_change_password flag
    user = fetch_one(
        """SELECT * FROM users 
           WHERE email = ? 
           AND role = 'admin' 
           AND must_change_password = TRUE 
           AND is_active = TRUE 
           AND deleted_at IS NULL""",
        (request.email.lower(),)
    )
    
    if not user:
        raise HTTPException(
            status_code=404,
            detail="Admin user not found or password already set"
        )
    
    # Validate password strength (basic)
    if len(request.password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")
    
    # Hash and set password
    password_hash = hash_password(request.password)
    execute_query(
        "UPDATE users SET password_hash = ?, must_change_password = FALSE WHERE id = ?",
        (password_hash, user['id'])
    )
    
    # Set auth cookies
    set_auth_cookies(response, user['id'], user['email'], user['role'])
    
    return {
        "ok": True,
        "user": {
            "id": user['id'],
            "email": user['email'],
            "first_name": user['first_name'],
            "last_name": user['last_name'],
            "role": user['role'],
            "must_change_password": False
        }
    }

@router.post("/change-password")
async def change_password(
    request: ChangePasswordRequest,
    current_user: dict = Depends(get_current_user)
):
    """Change password for authenticated user"""
    # Verify current password
    if not current_user.get('password_hash'):
        raise HTTPException(status_code=400, detail="No password set")
    
    if not verify_password(current_user['password_hash'], request.current_password):
        raise HTTPException(status_code=401, detail="Current password is incorrect")
    
    # Validate new password
    if len(request.new_password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")
    
    # Hash and update password
    password_hash = hash_password(request.new_password)
    execute_query(
        "UPDATE users SET password_hash = ?, must_change_password = FALSE WHERE id = ?",
        (password_hash, current_user['id'])
    )
    
    return {"ok": True, "message": "Password changed successfully"}

@router.post("/refresh")
async def refresh(response: Response, refresh_token: Optional[str] = None):
    """Refresh access token using refresh token"""
    if not refresh_token:
        raise HTTPException(status_code=401, detail="No refresh token provided")
    
    payload = verify_token(refresh_token, 'refresh')
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid or expired refresh token")
    
    # Fetch user
    user = fetch_one(
        "SELECT * FROM users WHERE id = ? AND is_active = TRUE AND deleted_at IS NULL",
        (payload['user_id'],)
    )
    
    if not user:
        raise HTTPException(status_code=401, detail="User not found or inactive")
    
    # Issue new tokens
    set_auth_cookies(response, user['id'], user['email'], user['role'])
    
    return {"ok": True}

@router.post("/logout")
async def logout(response: Response):
    """Logout by clearing cookies"""
    response.delete_cookie(
        key="access_token",
        domain=config.COOKIE_DOMAIN if config.COOKIE_DOMAIN != '127.0.0.1' else None
    )
    response.delete_cookie(
        key="refresh_token",
        domain=config.COOKIE_DOMAIN if config.COOKIE_DOMAIN != '127.0.0.1' else None
    )
    return {"ok": True}

@router.get("/me")
async def get_me(current_user: dict = Depends(get_current_user)):
    """Get current user info"""
    return {
        "id": current_user['id'],
        "email": current_user['email'],
        "first_name": current_user['first_name'],
        "last_name": current_user['last_name'],
        "role": current_user['role'],
        "must_change_password": current_user['must_change_password'],
        "org_id": current_user.get('org_id')
    }

@router.get("/accept-invite")
async def preview_invite(token: str):
    """Preview an invite (check if valid)"""
    invite = fetch_one(
        """SELECT * FROM user_invites 
           WHERE token = ? 
           AND consumed_at IS NULL 
           AND expires_at > NOW()""",
        (token,)
    )
    
    if not invite:
        raise HTTPException(status_code=404, detail="Invalid or expired invite")
    
    # Return masked email and names
    email_parts = invite['email'].split('@')
    masked_email = f"{email_parts[0][:2]}***@{email_parts[1]}"
    
    return {
        "ok": True,
        "email": masked_email,
        "first_name": invite['first_name'],
        "last_name": invite['last_name'],
        "role": invite['role']
    }

@router.post("/complete-invite")
async def complete_invite(request: AcceptInviteRequest, response: Response):
    """Complete invite by setting password and activating user"""
    # Find invite
    invite = fetch_one(
        """SELECT * FROM user_invites 
           WHERE token = ? 
           AND consumed_at IS NULL 
           AND expires_at > NOW()""",
        (request.token,)
    )
    
    if not invite:
        raise HTTPException(status_code=404, detail="Invalid or expired invite")
    
    # Check if user already exists
    existing_user = fetch_one(
        "SELECT * FROM users WHERE email = ?",
        (invite['email'].lower(),)
    )
    
    if existing_user:
        raise HTTPException(status_code=409, detail="User already exists")
    
    # Check seats (import here to avoid circular dependency)
    from backend.api.license import seats_available
    if not seats_available():
        raise HTTPException(status_code=403, detail="No available seats")
    
    # Validate password
    if len(request.password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters")
    
    # Create user
    user_id = str(uuid.uuid4())
    password_hash = hash_password(request.password)
    
    execute_query(
        """INSERT INTO users (id, email, password_hash, first_name, last_name, role, is_active, must_change_password)
           VALUES (?, ?, ?, ?, ?, ?, TRUE, FALSE)""",
        (user_id, invite['email'].lower(), password_hash, invite['first_name'], invite['last_name'], invite['role'])
    )
    
    # Mark invite as consumed
    execute_query(
        "UPDATE user_invites SET consumed_at = NOW() WHERE id = ?",
        (invite['id'],)
    )
    
    # Set auth cookies
    set_auth_cookies(response, user_id, invite['email'].lower(), invite['role'])
    
    return {
        "ok": True,
        "user": {
            "id": user_id,
            "email": invite['email'].lower(),
            "first_name": invite['first_name'],
            "last_name": invite['last_name'],
            "role": invite['role'],
            "must_change_password": False
        }
    }
