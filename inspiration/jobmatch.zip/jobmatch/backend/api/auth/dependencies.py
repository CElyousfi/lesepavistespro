"""Authentication dependencies"""
from fastapi import Cookie, HTTPException, Depends
from typing import Optional, Dict
from backend.api.utils import verify_token
from backend.api.database import fetch_one

async def get_current_user(access_token: Optional[str] = Cookie(None)) -> Dict:
    """Get the current authenticated user from access token cookie"""
    if not access_token:
        raise HTTPException(status_code=401, detail="Not authenticated")
    
    payload = verify_token(access_token, 'access')
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    
    # Fetch user from database
    user = fetch_one(
        "SELECT * FROM users WHERE id = ? AND is_active = TRUE AND deleted_at IS NULL",
        (payload['user_id'],)
    )
    
    if not user:
        raise HTTPException(status_code=401, detail="User not found or inactive")
    
    return user

async def require_admin(current_user: Dict = Depends(get_current_user)) -> Dict:
    """Require the current user to be an admin"""
    if current_user['role'] != 'admin':
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user
