# This file contains the API endpoints for application tracking
# To be added to main.py

# ============================================================================
# APPLICATION TRACKING ENDPOINTS
# ============================================================================

@app.post("/api/applications", response_model=ApplicationResponse)
async def create_application(request: ApplicationCreate):
    """Create a new application (bookmark a candidate for an offer)"""
    from datetime import datetime
    
    # Check if offer exists
    offer = fetch_one("SELECT * FROM offers WHERE id = ?", (request.offer_id,))
    if not offer:
        raise HTTPException(status_code=404, detail="Offer not found")
    
    # Check if candidate exists
    candidate = fetch_one("SELECT * FROM candidates WHERE id = ?", (request.candidate_id,))
    if not candidate:
        raise HTTPException(status_code=404, detail="Candidate not found")
    
    # Check if application already exists
    existing = fetch_one(
        "SELECT * FROM applications WHERE offer_id = ? AND candidate_id = ?",
        (request.offer_id, request.candidate_id)
    )
    if existing:
        raise HTTPException(status_code=400, detail="Application already exists")
    
    # Get match score if exists
    match = fetch_one(
        "SELECT score FROM matches WHERE offer_id = ? AND candidate_id = ?",
        (request.offer_id, request.candidate_id)
    )
    match_score = dict(match)["score"] if match and hasattr(match, 'keys') else None
    
    # Create application
    app_id = str(uuid.uuid4())
    now = datetime.now().isoformat()
    
    # Set date based on stage
    date_field = f"date_{request.stage}"
    
    execute_query(
        f"""INSERT INTO applications 
           (id, offer_id, candidate_id, stage, status, match_score, {date_field}, 
            notes, excitement_level, salary_expectation, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (app_id, request.offer_id, request.candidate_id, request.stage, request.stage,
         match_score, now, request.notes, request.excitement_level, 
         request.salary_expectation, now, now)
    )
    
    # Fetch created application with details
    return await get_application(app_id)


@app.get("/api/applications/{application_id}", response_model=ApplicationResponse)
async def get_application(application_id: str):
    """Get application details"""
    app = fetch_one(
        """SELECT a.*, 
                  o.parsed_json as offer_data,
                  c.first_name, c.last_name
           FROM applications a
           LEFT JOIN offers o ON a.offer_id = o.id
           LEFT JOIN candidates c ON a.candidate_id = c.id
           WHERE a.id = ?""",
        (application_id,)
    )
    
    if not app:
        raise HTTPException(status_code=404, detail="Application not found")
    
    app_dict = dict(app) if hasattr(app, 'keys') else app
    offer_data = json.loads(app_dict["offer_data"]) if app_dict.get("offer_data") else {}
    
    return ApplicationResponse(
        id=app_dict["id"],
        offer_id=app_dict["offer_id"],
        candidate_id=app_dict["candidate_id"],
        offer_title=offer_data.get("title", "Untitled"),
        candidate_name=f"{app_dict.get('first_name', '')} {app_dict.get('last_name', '')}".strip() or "Unknown",
        stage=app_dict["stage"],
        status=app_dict["status"],
        match_score=app_dict.get("match_score"),
        date_bookmarked=safe_isoformat(app_dict.get("date_bookmarked")),
        date_applied=safe_isoformat(app_dict.get("date_applied")),
        date_interviewing=safe_isoformat(app_dict.get("date_interviewing")),
        date_negotiating=safe_isoformat(app_dict.get("date_negotiating")),
        date_accepted=safe_isoformat(app_dict.get("date_accepted")),
        date_rejected=safe_isoformat(app_dict.get("date_rejected")),
        notes=app_dict.get("notes"),
        excitement_level=app_dict.get("excitement_level", 0),
        salary_expectation=app_dict.get("salary_expectation"),
        follow_up_date=app_dict.get("follow_up_date"),
        created_at=safe_isoformat(app_dict["created_at"]),
        updated_at=safe_isoformat(app_dict["updated_at"])
    )


@app.get("/api/applications")
async def list_applications(
    offer_id: Optional[str] = None,
    candidate_id: Optional[str] = None,
    stage: Optional[str] = None,
    limit: int = Query(100, ge=1, le=500)
):
    """List applications with optional filters"""
    
    query = """
        SELECT a.*, 
               o.parsed_json as offer_data,
               c.first_name, c.last_name
        FROM applications a
        LEFT JOIN offers o ON a.offer_id = o.id
        LEFT JOIN candidates c ON a.candidate_id = c.id
        WHERE 1=1
    """
    params = []
    
    if offer_id:
        query += " AND a.offer_id = ?"
        params.append(offer_id)
    
    if candidate_id:
        query += " AND a.candidate_id = ?"
        params.append(candidate_id)
    
    if stage:
        query += " AND a.stage = ?"
        params.append(stage)
    
    query += " ORDER BY a.updated_at DESC LIMIT ?"
    params.append(limit)
    
    applications = execute_query(query, tuple(params), fetch=True)
    
    result = []
    for app in applications:
        app_dict = dict(app) if hasattr(app, 'keys') else app
        offer_data = json.loads(app_dict["offer_data"]) if app_dict.get("offer_data") else {}
        
        result.append({
            "id": app_dict["id"],
            "offer_id": app_dict["offer_id"],
            "candidate_id": app_dict["candidate_id"],
            "offer_title": offer_data.get("title", "Untitled"),
            "candidate_name": f"{app_dict.get('first_name', '')} {app_dict.get('last_name', '')}".strip() or "Unknown",
            "stage": app_dict["stage"],
            "status": app_dict["status"],
            "match_score": app_dict.get("match_score"),
            "date_bookmarked": safe_isoformat(app_dict.get("date_bookmarked")),
            "date_applied": safe_isoformat(app_dict.get("date_applied")),
            "date_interviewing": safe_isoformat(app_dict.get("date_interviewing")),
            "date_negotiating": safe_isoformat(app_dict.get("date_negotiating")),
            "date_accepted": safe_isoformat(app_dict.get("date_accepted")),
            "date_rejected": safe_isoformat(app_dict.get("date_rejected")),
            "notes": app_dict.get("notes"),
            "excitement_level": app_dict.get("excitement_level", 0),
            "salary_expectation": app_dict.get("salary_expectation"),
            "follow_up_date": app_dict.get("follow_up_date"),
            "created_at": safe_isoformat(app_dict["created_at"]),
            "updated_at": safe_isoformat(app_dict["updated_at"])
        })
    
    # Get summary statistics
    stats_query = """
        SELECT 
            stage,
            COUNT(*) as count
        FROM applications
        WHERE 1=1
    """
    stats_params = []
    
    if offer_id:
        stats_query += " AND offer_id = ?"
        stats_params.append(offer_id)
    
    if candidate_id:
        stats_query += " AND candidate_id = ?"
        stats_params.append(candidate_id)
    
    stats_query += " GROUP BY stage"
    
    stats = execute_query(stats_query, tuple(stats_params), fetch=True)
    stats_dict = {}
    for stat in stats:
        stat_dict = dict(stat) if hasattr(stat, 'keys') else stat
        stats_dict[stat_dict["stage"]] = stat_dict["count"]
    
    return {
        "applications": result,
        "count": len(result),
        "stats": stats_dict
    }


@app.patch("/api/applications/{application_id}", response_model=ApplicationResponse)
async def update_application(application_id: str, request: ApplicationUpdate):
    """Update application status/stage"""
    from datetime import datetime
    
    # Check if application exists
    app = fetch_one("SELECT * FROM applications WHERE id = ?", (application_id,))
    if not app:
        raise HTTPException(status_code=404, detail="Application not found")
    
    # Build update query
    updates = []
    params = []
    
    if request.stage is not None:
        updates.append("stage = ?")
        params.append(request.stage)
        
        # Update date field for new stage
        now = datetime.now().isoformat()
        date_field = f"date_{request.stage}"
        updates.append(f"{date_field} = ?")
        params.append(now)
    
    if request.status is not None:
        updates.append("status = ?")
        params.append(request.status)
    
    if request.notes is not None:
        updates.append("notes = ?")
        params.append(request.notes)
    
    if request.excitement_level is not None:
        updates.append("excitement_level = ?")
        params.append(request.excitement_level)
    
    if request.salary_expectation is not None:
        updates.append("salary_expectation = ?")
        params.append(request.salary_expectation)
    
    if request.follow_up_date is not None:
        updates.append("follow_up_date = ?")
        params.append(request.follow_up_date)
    
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    
    # Add updated_at
    updates.append("updated_at = ?")
    params.append(datetime.now().isoformat())
    
    # Add application_id for WHERE clause
    params.append(application_id)
    
    # Execute update
    query = f"UPDATE applications SET {', '.join(updates)} WHERE id = ?"
    execute_query(query, tuple(params))
    
    # Return updated application
    return await get_application(application_id)


@app.delete("/api/applications/{application_id}")
async def delete_application(application_id: str):
    """Delete an application"""
    app = fetch_one("SELECT * FROM applications WHERE id = ?", (application_id,))
    if not app:
        raise HTTPException(status_code=404, detail="Application not found")
    
    execute_query("DELETE FROM applications WHERE id = ?", (application_id,))
    
    return {"message": "Application deleted successfully", "id": application_id}


@app.get("/api/pipeline/stats")
async def get_pipeline_stats(offer_id: Optional[str] = None):
    """Get pipeline statistics"""
    
    query = """
        SELECT 
            stage,
            COUNT(*) as count,
            AVG(match_score) as avg_score,
            AVG(excitement_level) as avg_excitement
        FROM applications
        WHERE 1=1
    """
    params = []
    
    if offer_id:
        query += " AND offer_id = ?"
        params.append(offer_id)
    
    query += " GROUP BY stage ORDER BY CASE stage WHEN 'bookmarked' THEN 1 WHEN 'applying' THEN 2 WHEN 'applied' THEN 3 WHEN 'interviewing' THEN 4 WHEN 'negotiating' THEN 5 WHEN 'accepted' THEN 6 ELSE 7 END"
    
    stats = execute_query(query, tuple(params), fetch=True)
    
    result = []
    for stat in stats:
        stat_dict = dict(stat) if hasattr(stat, 'keys') else stat
        result.append({
            "stage": stat_dict["stage"],
            "count": stat_dict["count"],
            "avg_score": round(stat_dict.get("avg_score") or 0, 1),
            "avg_excitement": round(stat_dict.get("avg_excitement") or 0, 1)
        })
    
    return {"stages": result}
