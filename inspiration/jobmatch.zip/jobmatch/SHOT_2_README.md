# Shot 2 — Auth + Activation + License + Invites

## ✅ Implementation Complete

Shot 2 has been successfully implemented with a **modular microservice architecture**.

---

## 🏗️ Architecture

### Backend Structure (Modular)
```
api/
├── auth/              # Authentication module
│   ├── routes.py      # Login, logout, password management
│   └── dependencies.py # Auth guards (get_current_user, require_admin)
├── system/            # System activation module
│   └── routes.py      # Bootstrap, activation flow
├── users/             # User management module
│   └── routes.py      # Invite system, user listing
├── license/           # License verification module
│   └── verify.py      # JWT verification, seat management
├── config/            # Configuration module
│   └── settings.py    # Environment variables
├── database/          # Database module
│   ├── connection.py  # Connection pooling
│   └── migrations.py  # Schema migrations
└── utils/             # Utility modules
    ├── password.py    # Argon2 hashing
    ├── tokens.py      # JWT creation/verification
    └── email.py       # SMTP email sending

main_new.py            # Application launcher
```

### Frontend Structure
```
frontend/src/pages/
├── ActivatePage.jsx              # Step 1: Enter activation key
├── ActivateVerifyPage.jsx        # Step 2: Enter 6-digit code
├── ActivateSetPasswordPage.jsx   # Step 3: Set admin password
├── LoginPage.jsx                 # User login
└── AcceptInvitePage.jsx          # Accept invite & set password
```

---

## 🔐 Features Implemented

### 1. First-Run Activation
- **Step 1**: Admin enters activation key + email
- **Step 2**: Central server emails 6-digit code (or local mode for dev)
- **Step 3**: Admin verifies code → license stored
- **Step 4**: Admin sets password → ready to use

**Endpoints**:
- `GET /api/system/bootstrap-status` - Check if activation needed
- `POST /api/system/activate/request-code` - Request activation code
- `POST /api/system/activate/verify-code` - Verify code & create license

### 2. Authentication System
- **Argon2** password hashing
- **JWT** access/refresh tokens in HttpOnly cookies
- **Session management** with automatic refresh
- **Role-based access** (admin, recruiter)

**Endpoints**:
- `POST /api/auth/login` - Login with email/password
- `POST /api/auth/first-set-password` - Set password after activation
- `POST /api/auth/change-password` - Change password
- `POST /api/auth/refresh` - Refresh access token
- `POST /api/auth/logout` - Logout (clear cookies)
- `GET /api/auth/me` - Get current user info

### 3. License Verification
- **Signed JWT** license from central server
- **Seat management** - enforce max active users
- **Automatic verification** on protected routes
- **Local dev mode** when central server unavailable

**Functions**:
- `verify_license_jwt()` - Verify signature & expiration
- `get_current_license()` - Get active license
- `require_valid_license()` - Dependency for protected routes
- `seats_available()` - Check if seats available

### 4. User Invite System
- **Admin-only** invite creation
- **Email invites** with secure tokens
- **7-day expiration** on invite links
- **Single-use tokens** - consumed on acceptance
- **Seat enforcement** at invite creation & acceptance

**Endpoints**:
- `POST /api/admin/users/invite` - Create invite (admin only)
- `GET /api/auth/accept-invite?token=...` - Preview invite
- `POST /api/auth/complete-invite` - Accept invite & set password
- `GET /api/admin/users/seats` - Get seat usage
- `GET /api/admin/users/list` - List all users
- `GET /api/admin/users/invites` - List pending invites

---

## 🗄️ Database Schema

### New Tables

**users**
```sql
- id, email, password_hash, first_name, last_name, role
- must_change_password, org_id, external_user_id
- is_active, deleted_at, created_at, updated_at
```

**licenses**
```sql
- id, org_id, plan, seats, expires_at, status
- license_jwt, created_at, updated_at
```

**activation_codes**
```sql
- id, email, activation_key, code_hash
- expires_at, attempts, verified, created_at
```

**user_invites**
```sql
- id, email, first_name, last_name, role, token
- expires_at, consumed_at, created_by, created_at
```

---

## 🧪 Testing the Flow

### 1. Check Bootstrap Status
```bash
curl http://127.0.0.1:8000/api/system/bootstrap-status
# Response: {"needs_activation": true}
```

### 2. Request Activation Code
```bash
curl -X POST http://127.0.0.1:8000/api/system/activate/request-code \
  -H "Content-Type: application/json" \
  -d '{"activation_key":"TEST-KEY-123","admin_email":"admin@test.com"}'

# Check backend logs for the 6-digit code
```

### 3. Verify Code
```bash
curl -X POST http://127.0.0.1:8000/api/system/activate/verify-code \
  -H "Content-Type: application/json" \
  -d '{"activation_key":"TEST-KEY-123","admin_email":"admin@test.com","code":"123456"}'
```

### 4. Set Admin Password
```bash
curl -X POST http://127.0.0.1:8000/api/auth/first-set-password \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"SecurePass123"}' \
  -c cookies.txt
```

### 5. Login
```bash
curl -X POST http://127.0.0.1:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"SecurePass123"}' \
  -c cookies.txt
```

### 6. Invite User
```bash
curl -X POST http://127.0.0.1:8000/api/admin/users/invite \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d '{"email":"user@test.com","first_name":"John","last_name":"Doe","role":"recruiter"}'

# Check backend logs for invite link with token
```

### 7. Accept Invite
```bash
# Preview invite
curl "http://127.0.0.1:8000/api/auth/accept-invite?token=TOKEN_HERE"

# Complete invite
curl -X POST http://127.0.0.1:8000/api/auth/complete-invite \
  -H "Content-Type: application/json" \
  -d '{"token":"TOKEN_HERE","password":"UserPass123"}' \
  -c user_cookies.txt
```

---

## ⚙️ Configuration

### Environment Variables (.env)
```bash
# JWT & Session
JWT_SECRET=change_me_to_a_secure_random_string_in_production
JWT_ALG=HS256
ACCESS_TOKEN_MINUTES=30
REFRESH_TOKEN_DAYS=7
COOKIE_DOMAIN=127.0.0.1
COOKIE_SECURE=false

# Central Licensing
LICENSE_API_BASE=https://license.yourcompany.com
LICENSE_API_KEY=your_server_to_server_key
LICENSE_PUBLIC_KEY_PEM=-----BEGIN PUBLIC KEY-----\n...\n-----END PUBLIC KEY-----

# SMTP (Invite Emails)
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASSWORD=
SMTP_TLS=true
SMTP_FROM_EMAIL=noreply@yourcompany.com
SMTP_FROM_NAME=JobMatch ATS

# Public Base URL (for invite links)
PUBLIC_BASE_URL=http://127.0.0.1:5173
```

---

## 🔒 Security Features

### Password Security
- **Argon2** hashing (industry standard)
- **Minimum 8 characters** enforced
- **Automatic rehashing** when parameters change

### Token Security
- **HttpOnly cookies** - not accessible via JavaScript
- **SameSite=Lax** - CSRF protection
- **Secure flag** in production
- **Short-lived access tokens** (30 min)
- **Long-lived refresh tokens** (7 days)

### Activation Security
- **6-digit codes** with 15-minute expiration
- **Max 5 attempts** per code
- **SHA-256 hashed** codes in database
- **Single-use** codes

### Invite Security
- **64-character hex tokens** (256-bit entropy)
- **7-day expiration**
- **Single-use** tokens
- **Seat enforcement** at creation & acceptance

---

## 🚀 Running the Application

### Backend
```bash
# Start the new modular backend
python main_new.py

# Or with uvicorn directly
uvicorn main_new:app --reload --host 0.0.0.0 --port 8000
```

### Frontend
```bash
cd frontend
npm run dev
```

### Access Points
- **Frontend**: http://127.0.0.1:5173
- **Backend API**: http://127.0.0.1:8000
- **API Docs**: http://127.0.0.1:8000/docs

---

## 📝 Frontend Routes

- `/activate` - Activation step 1 (enter key)
- `/activate/verify` - Activation step 2 (enter code)
- `/activate/set-password` - Activation step 3 (set password)
- `/login` - User login
- `/accept-invite?token=...` - Accept invite
- `/` - Dashboard (protected)
- `/offers` - Offers page (protected)
- `/candidates` - Candidates page (protected)
- `/tracker` - Tracker page (protected)

---

## 🎯 What's Next (Shot 3)

Deferred to future shots:
- Deleted-user cool-down (seat churn prevention)
- Audit logs and rate limits
- Daily heartbeat to central server
- Admin Settings UI (SMTP, model providers, etc.)
- GDPR redaction pipeline

---

## 📊 Database Verification

```bash
# Check users
mysql -u jobmatch -pjobmatch_pw jobmatch_db -e "SELECT id, email, role, is_active FROM users;"

# Check licenses
mysql -u jobmatch -pjobmatch_pw jobmatch_db -e "SELECT id, org_id, plan, seats, status FROM licenses;"

# Check seat usage
mysql -u jobmatch -pjobmatch_pw jobmatch_db -e "
  SELECT 
    (SELECT seats FROM licenses WHERE status='active' LIMIT 1) as total_seats,
    COUNT(*) as used_seats
  FROM users WHERE is_active=TRUE AND deleted_at IS NULL;
"
```

---

## ✅ Acceptance Criteria Met

- ✅ First-run activation with email code
- ✅ Signed license JWT storage & verification
- ✅ Local auth with Argon2 + JWT cookies
- ✅ Seat limit enforcement
- ✅ Invite-based user onboarding
- ✅ Modular microservice architecture
- ✅ No hardcoded URLs (all from .env)
- ✅ Frontend pages for all auth flows

**Status**: Shot 2 Complete! Ready for Shot 3.
