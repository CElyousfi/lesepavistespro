# Quick Start Guide - Shot 2

## 🚀 Get Started in 5 Minutes

### Prerequisites
- MariaDB running
- Python 3.11+ with venv
- Node.js 18+

---

## Step 1: Install Dependencies

```bash
# Backend
source .venv/bin/activate
pip install -r requirements.txt

# Frontend
cd frontend
npm install
cd ..
```

---

## Step 2: Start Services

### Terminal 1 - Backend
```bash
python main_new.py
```

You should see:
```
🚀 Starting JobMatch API
✓ Database tables initialized successfully
✓ API ready at http://127.0.0.1:8000
```

### Terminal 2 - Frontend
```bash
cd frontend
npm run dev
```

You should see:
```
➜  Local:   http://127.0.0.1:5173/
```

---

## Step 3: Activate System

### Option A: Using Frontend (Recommended)

1. **Open browser**: http://127.0.0.1:5173/activate

2. **Enter activation details**:
   - Activation Key: `TEST-KEY-123`
   - Admin Email: `admin@yourcompany.com`
   - Click "Continue"

3. **Check backend logs** for the 6-digit code:
   ```
   🔑 LOCAL ACTIVATION CODE: 123456
   ```

4. **Enter the code** on the verify page

5. **Set your password** (minimum 8 characters)

6. **Done!** You're now logged in as admin

### Option B: Using API (Testing)

```bash
# 1. Request code
curl -X POST http://127.0.0.1:8000/api/system/activate/request-code \
  -H "Content-Type: application/json" \
  -d '{"activation_key":"TEST-KEY-123","admin_email":"admin@test.com"}'

# 2. Check backend logs for code, then verify
curl -X POST http://127.0.0.1:8000/api/system/activate/verify-code \
  -H "Content-Type: application/json" \
  -d '{"activation_key":"TEST-KEY-123","admin_email":"admin@test.com","code":"YOUR_CODE"}'

# 3. Set password
curl -X POST http://127.0.0.1:8000/api/auth/first-set-password \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"SecurePass123"}' \
  -c cookies.txt
```

---

## Step 4: Invite Users

### Using API
```bash
# Login first (if not already)
curl -X POST http://127.0.0.1:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"YOUR_PASSWORD"}' \
  -c cookies.txt

# Invite a user
curl -X POST http://127.0.0.1:8000/api/admin/users/invite \
  -H "Content-Type: application/json" \
  -b cookies.txt \
  -d '{
    "email":"recruiter@test.com",
    "first_name":"John",
    "last_name":"Doe",
    "role":"recruiter"
  }'
```

### Check Backend Logs
You'll see the invite link:
```
http://127.0.0.1:5173/accept-invite?token=abc123...
```

### User Accepts Invite
1. User opens the invite link
2. Sets their password
3. Automatically logged in

---

## Step 5: Verify Everything Works

### Check Users
```bash
mysql -u jobmatch -pjobmatch_pw jobmatch_db -e \
  "SELECT email, role, is_active FROM users;"
```

### Check License
```bash
curl -b cookies.txt http://127.0.0.1:8000/api/admin/users/seats | jq
```

Expected output:
```json
{
  "total": 5,
  "used": 2,
  "available": 3
}
```

### Check API Docs
Open: http://127.0.0.1:8000/docs

---

## 🎯 Common Tasks

### Login
```bash
curl -X POST http://127.0.0.1:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"YOUR_PASSWORD"}' \
  -c cookies.txt
```

### Get Current User
```bash
curl -b cookies.txt http://127.0.0.1:8000/api/auth/me | jq
```

### List Users (Admin Only)
```bash
curl -b cookies.txt http://127.0.0.1:8000/api/admin/users/list | jq
```

### List Pending Invites (Admin Only)
```bash
curl -b cookies.txt http://127.0.0.1:8000/api/admin/users/invites | jq
```

### Logout
```bash
curl -X POST -b cookies.txt http://127.0.0.1:8000/api/auth/logout
```

---

## 🔧 Troubleshooting

### "needs_activation: false" but can't login
- Database already has users from previous testing
- Solution: Empty the database or use existing credentials

### "No available seats"
- License has reached seat limit
- Solution: Check seat usage with `/api/admin/users/seats`
- Deactivate unused users or upgrade license

### "Invalid or expired invite"
- Invite token is single-use or expired (7 days)
- Solution: Create a new invite

### Backend won't start
- Check if port 8000 is already in use
- Solution: `pkill -f "python main"` then restart

### Frontend shows CORS errors
- Backend not running or wrong port
- Solution: Ensure backend is on port 8000

---

## 📚 Next Steps

1. **Explore the API**: http://127.0.0.1:8000/docs
2. **Read full docs**: See `SHOT_2_README.md`
3. **Configure SMTP**: Update `.env` for real email sending
4. **Production setup**: Change `JWT_SECRET`, `COOKIE_SECURE=true`

---

## 🆘 Need Help?

- **API Docs**: http://127.0.0.1:8000/docs
- **Full Guide**: `SHOT_2_README.md`
- **Summary**: `SHOT_2_SUMMARY.md`
- **Backend Logs**: Check terminal running `main_new.py`

---

**Happy coding! 🎉**
