# 360° Job Matching - Frontend

React + Vite + Tailwind CSS frontend for the 360° Job Matching application.

## Tech Stack

- **React 18** (JavaScript, no TypeScript)
- **Vite** - Build tool
- **Tailwind CSS** - Styling with Teal color scheme
- **Axios** - HTTP client
- **React Hook Form** - Form handling
- **SWR** - Data fetching
- **Lucide React** - Icons

## Prerequisites (Arch Linux)

```bash
# Update system
sudo pacman -Syu --noconfirm

# Install Node.js and npm
sudo pacman -S --noconfirm nodejs npm

# Optional: Install pnpm if preferred
# sudo pacman -S --noconfirm pnpm
```

## Setup

```bash
# Navigate to frontend directory
cd frontend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env.local

# Edit .env.local and set your API URL
# VITE_API_BASE=http://127.0.0.1:8000
# VITE_MATCH_TOPK=5
```

## Development

```bash
# Start development server
npm run dev

# Application will be available at:
# http://127.0.0.1:5173
```

## Build for Production

```bash
# Build the application
npm run build

# Preview production build
npm run preview
```

## Environment Variables

Create a `.env.local` file with:

```bash
VITE_API_BASE=http://127.0.0.1:8000
VITE_MATCH_TOPK=5
```

- `VITE_API_BASE`: Backend API URL (must match your FastAPI server)
- `VITE_MATCH_TOPK`: Number of top candidates to return in matching

## Backend CORS Configuration

Ensure your FastAPI backend allows CORS for the frontend origin. Add to your `main.py`:

```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:5173", "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

## Features

### 1. Job Offer Management
- Paste French job offers
- LLM-powered parsing (title, must-haves, nice-to-haves)
- Browse all offers with creation dates

### 2. Candidate Management
- Create candidates
- Upload PDF CVs
- Automatic skill extraction via LLM
- Track experience years

### 3. Intelligent Matching
- Match candidates to job offers
- Top-K scoring (default: 5 candidates)
- Visual score display with progress pills
- Skill chips (matched, missing, preferred)
- Coverage percentages

### 4. User Interface
- Teal-themed design (Teal Job Tracker inspired)
- Dark teal sidebar navigation
- Clean topbar with action buttons
- Responsive card layouts
- Toast notifications
- Drawer for offer details
- Modal for match results

## API Endpoints Used

- `POST /api/offers/ingest-text` - Create offer from text
- `GET /api/offers` - List all offers
- `GET /api/offers/{id}` - Get offer details
- `POST /api/candidates` - Create candidate
- `GET /api/candidates` - List all candidates
- `POST /api/candidates/{id}/files` - Upload CV (PDF)
- `POST /api/offers/{id}/match?top_k=5` - Compute matches

## Project Structure

```
frontend/
├── src/
│   ├── components/
│   │   ├── layout/          # Sidebar, Topbar, Container
│   │   ├── ui/              # Reusable UI components
│   │   └── features/        # Feature-specific components
│   ├── lib/                 # API client, hooks, utilities
│   ├── pages/               # Dashboard page
│   ├── styles/              # Global CSS
│   ├── App.jsx              # Main app component
│   └── main.jsx             # Entry point
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.cjs
└── postcss.config.cjs
```

## Color Palette

- **Teal 900**: `#0B3C37` - Dark teal (sidebar)
- **Teal 700**: `#0F4C45` - Medium teal
- **Teal 500**: `#168B7F` - Bright teal (primary actions)
- **Mint 100**: `#E6FBF7` - Light mint (nice-to-have chips)
- **Slate**: Full range for text and backgrounds

## Usage Flow

1. **Create a Job Offer**:
   - Click "Nouvelle offre (FR)" button
   - Paste French job description
   - Submit → LLM parses structure

2. **Create a Candidate**:
   - Click "Nouveau candidat" button
   - Candidate created with unique ID
   - Upload section appears automatically

3. **Upload CV**:
   - Drag & drop PDF or click to select
   - Upload → LLM extracts skills
   - Skills displayed as chips

4. **Match Candidates**:
   - Click on an offer in the list
   - Drawer opens with offer details
   - Click "Calculer Top-5"
   - Results modal shows ranked candidates with scores

## Troubleshooting

### CORS Errors
Make sure backend has CORS middleware configured for `http://127.0.0.1:5173`.

### API Connection Failed
Check that `VITE_API_BASE` in `.env.local` matches your backend URL.

### Module Not Found
Run `npm install` to ensure all dependencies are installed.

### Port Already in Use
Change port in `vite.config.js` or kill the process using port 5173.

## License

MIT
