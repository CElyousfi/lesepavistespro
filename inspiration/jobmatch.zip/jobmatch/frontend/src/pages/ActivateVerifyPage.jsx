import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, ArrowRight } from '@phosphor-icons/react';
import { Button } from '../components/ui/Button';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000';

export const ActivateVerifyPage = () => {
  const [code, setCode] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const activationKey = sessionStorage.getItem('activation_key');
  const adminEmail = sessionStorage.getItem('admin_email');

  useEffect(() => {
    if (!activationKey || !adminEmail) {
      navigate('/activate');
    }
  }, [activationKey, adminEmail, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const response = await fetch(`${API_BASE}/api/system/activate/verify-code`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          activation_key: activationKey,
          admin_email: adminEmail,
          code: code
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || 'Invalid code');
      }

      // Navigate to set password
      navigate('/activate/set-password');
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 to-blue-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-teal-100 rounded-full mb-4">
            <ShieldCheck className="h-8 w-8 text-teal-600" weight="duotone" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">Enter Code</h1>
          <p className="text-gray-600 mt-2">
            We sent a 6-digit code to <strong>{adminEmail}</strong>
          </p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Activation Code
            </label>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 6))}
              placeholder="000000"
              className="w-full px-4 py-3 text-center text-2xl tracking-widest border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 font-mono"
              maxLength={6}
              required
            />
            <p className="text-xs text-gray-500 mt-2 text-center">
              Enter the 6-digit code from your email
            </p>
          </div>

          <Button
            type="submit"
            disabled={isLoading || code.length !== 6}
            className="w-full"
          >
            {isLoading ? (
              'Verifying...'
            ) : (
              <>
                Verify Code
                <ArrowRight className="h-5 w-5 ml-2" weight="bold" />
              </>
            )}
          </Button>
        </form>

        <div className="mt-6 text-center">
          <button
            onClick={() => navigate('/activate')}
            className="text-sm text-teal-600 hover:text-teal-700"
          >
            ← Back to activation
          </button>
        </div>
      </div>
    </div>
  );
};
