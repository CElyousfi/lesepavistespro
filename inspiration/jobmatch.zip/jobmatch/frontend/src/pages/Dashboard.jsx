import { useState } from 'react';
import { PlusCircle, Loader2, Briefcase, Users, Target, Zap } from 'lucide-react';
import { Topbar } from '../components/layout/Topbar';
import { Button } from '../components/ui/Button';
import { OfferIngest } from '../components/features/OfferIngest';
import { OfferList } from '../components/features/OfferList';
import { OfferDrawer } from '../components/features/OfferDrawer';
import { CandidateList } from '../components/features/CandidateList';
import { CandidateDrawer } from '../components/features/CandidateDrawer';
import { ResumeUpload } from '../components/features/ResumeUpload';
import { NewCandidateModal } from '../components/features/NewCandidateModal';
import { MatchResults } from '../components/features/MatchResults';
import { createCandidate } from '../lib/api';
import { showToast } from '../components/ui/Toast';
import { mutate } from 'swr';
import { useOffers, useCandidates } from '../lib/useApi';

export const Dashboard = () => {
  const [showOfferIngest, setShowOfferIngest] = useState(false);
  const [selectedOfferId, setSelectedOfferId] = useState(null);
  const [selectedCandidateId, setSelectedCandidateId] = useState(null);
  const [matchResults, setMatchResults] = useState(null);
  const [uploadCandidateId, setUploadCandidateId] = useState(null);
  const [isCreatingCandidate, setIsCreatingCandidate] = useState(false);
  const [showNewCandidateModal, setShowNewCandidateModal] = useState(false);
  
  // Fetch data for stats
  const { offers } = useOffers(100);
  const { candidates } = useCandidates(100);

  const handleCreateCandidate = () => setShowNewCandidateModal(true);

  const handleOfferCreated = (offer) => {
    // Refresh offers list
    mutate(['offers', 10]);
    // Open the newly created offer
    setSelectedOfferId(offer.id);
  };

  const handleSelectOffer = (offerId) => {
    setSelectedOfferId(offerId);
  };

  const handleCloseDrawer = () => {
    setSelectedOfferId(null);
  };

  const handleMatchResults = (results) => {
    setMatchResults(results);
  };

  const handleCloseMatchResults = () => {
    setMatchResults(null);
  };

  const handleUploadCV = (candidateId) => {
    setUploadCandidateId(candidateId);
  };

  const handleUploadSuccess = () => {
    // Refresh candidates list
    mutate(['candidates', 10]);
  };

  // Calculate stats
  const totalOffers = offers?.length || 0;
  const totalCandidates = candidates?.length || 0;
  const candidatesWithCV = candidates?.filter(c => c.profile_count > 0).length || 0;

  return (
    <>
      <Topbar
        title="Tableau de Bord"
        actions={
          <>
            <Button
              variant="secondary"
              onClick={handleCreateCandidate}
              disabled={isCreatingCandidate}
            >
              {isCreatingCandidate ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Création...
                </>
              ) : (
                <>
                  <PlusCircle className="h-4 w-4" />
                  Nouveau candidat
                </>
              )}
            </Button>
            <Button onClick={() => setShowOfferIngest(true)}>
              <PlusCircle className="h-4 w-4" />
              Nouvelle offre (FR)
            </Button>
          </>
        }
      />

      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Main Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Job Applications & Priorities */}
          <div className="lg:col-span-2 space-y-6">
            {/* Offers Section */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm">
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#E6F2F1] flex items-center justify-center">
                    <Briefcase className="h-5 w-5 text-[#005149]" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">Offres d'emploi</h2>
                    <p className="text-sm text-slate-500">{totalOffers} postes actifs</p>
                  </div>
                </div>
              </div>
              <div className="p-5 max-h-96 overflow-y-auto">
                <OfferList onSelectOffer={handleSelectOffer} />
              </div>
            </div>

            {/* Candidates Section */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm">
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-[#E6F2F1] flex items-center justify-center">
                    <Users className="h-5 w-5 text-[#005149]" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">Candidats</h2>
                    <p className="text-sm text-slate-500">{candidatesWithCV} avec CV</p>
                  </div>
                </div>
              </div>
              <div className="p-5 max-h-96 overflow-y-auto">
                <CandidateList 
                  onUploadCV={handleUploadCV}
                  onSelectCandidate={setSelectedCandidateId}
                />
              </div>
            </div>
          </div>

          {/* Right Column - Stats & Info */}
          <div className="space-y-6">
            {/* Stats Card */}
            <div className="bg-[#005149] rounded-xl p-6 text-white shadow-sm">
              <div className="flex items-center gap-2 mb-4">
                <Target className="h-5 w-5" />
                <h3 className="font-bold text-lg">Matching Intelligent</h3>
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between py-3 border-b border-teal-500/30">
                  <span className="text-teal-100 text-sm">Offres actives</span>
                  <span className="text-2xl font-bold">{totalOffers}</span>
                </div>
                <div className="flex items-center justify-between py-3 border-b border-teal-500/30">
                  <span className="text-teal-100 text-sm">Candidats</span>
                  <span className="text-2xl font-bold">{totalCandidates}</span>
                </div>
                <div className="flex items-center justify-between py-3">
                  <span className="text-teal-100 text-sm">Avec CV</span>
                  <span className="text-2xl font-bold">{candidatesWithCV}</span>
                </div>
              </div>
              <div className="mt-6 pt-4 border-t border-teal-500/30">
                <div className="flex items-center gap-2 text-teal-100 text-sm">
                  <Zap className="h-4 w-4" />
                  <span>IA-powered matching</span>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
              <h3 className="font-semibold text-slate-900 mb-4">Actions rapides</h3>
              <div className="space-y-3">
                <Button
                  variant="secondary"
                  onClick={handleCreateCandidate}
                  disabled={isCreatingCandidate}
                  className="w-full justify-start"
                >
                  {isCreatingCandidate ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Création...
                    </>
                  ) : (
                    <>
                      <PlusCircle className="h-4 w-4" />
                      Nouveau candidat
                    </>
                  )}
                </Button>
                <Button onClick={() => setShowOfferIngest(true)} className="w-full justify-start">
                  <PlusCircle className="h-4 w-4" />
                  Nouvelle offre
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Resume Upload Section */}
        {uploadCandidateId && (
          <div className="max-w-2xl mx-auto">
            <ResumeUpload
              candidateId={uploadCandidateId}
              onSuccess={handleUploadSuccess}
            />
          </div>
        )}
      </div>

      {/* Modals */}
      {showNewCandidateModal && (
        <NewCandidateModal
          onClose={() => setShowNewCandidateModal(false)}
          onCreated={() => {
            mutate(['candidates', 100]);
          }}
        />
      )}
      {showOfferIngest && (
        <OfferIngest
          onClose={() => setShowOfferIngest(false)}
          onSuccess={handleOfferCreated}
        />
      )}

      {selectedOfferId && (
        <OfferDrawer
          offerId={selectedOfferId}
          onClose={handleCloseDrawer}
          onMatchResults={handleMatchResults}
          onDelete={() => window.location.reload()}
        />
      )}

      {matchResults && (
        <MatchResults
          matchData={matchResults}
          onClose={handleCloseMatchResults}
        />
      )}

      {selectedCandidateId && (
        <CandidateDrawer
          candidateId={selectedCandidateId}
          onClose={() => setSelectedCandidateId(null)}
          onDelete={() => window.location.reload()}
        />
      )}
    </>
  );
};
