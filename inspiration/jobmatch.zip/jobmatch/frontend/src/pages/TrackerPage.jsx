import { useState, useMemo, useEffect } from 'react';
import useSWR, { mutate } from 'swr';
import { 
  Bookmark, PaperPlaneTilt, CheckCircle, Users as UsersIcon, Handshake, Trophy,
  MagnifyingGlass, FunnelSimple, Plus, MapPin, Buildings, Briefcase, Calendar,
  ChatCircleDots, Star, ArrowRight, PencilSimple, Trash, X, CircleNotch,
  CaretDown, CaretUp, Gauge, Envelope, Phone, LinkedinLogo, GithubLogo,
  CheckCircle as CheckCircleIcon, WarningCircle, Info
} from '@phosphor-icons/react';
import { listOffers, matchOffer, listApplications, updateApplication, createApplication, deleteApplication } from '../lib/api';
import { showToast } from '../components/ui/Toast';
import { CandidateSelector } from '../components/features/CandidateSelector';
import { CircularGauge } from '../components/ui/CircularGauge';
import { KPIFilter } from '../components/ui/KPIFilter';

const STAGES = [
  { id: 'bookmarked', label: 'Sauvegardé', icon: Bookmark, bgColor: 'bg-slate-100', textColor: 'text-slate-700', borderColor: 'border-slate-300' },
  { id: 'applying', label: 'En cours', icon: PaperPlaneTilt, bgColor: 'bg-[#CCE5E3]', textColor: 'text-[#005149]', borderColor: 'border-[#99CBC7]' },
  { id: 'applied', label: 'Postulé', icon: CheckCircle, bgColor: 'bg-[#CCE5E3]', textColor: 'text-[#00413A]', borderColor: 'border-[#66B1AB]' },
  { id: 'interviewing', label: 'Entretien', icon: UsersIcon, bgColor: 'bg-[#FDF3DB]', textColor: 'text-[#C18618]', borderColor: 'border-[#F9DB93]' },
  { id: 'negotiating', label: 'Négociation', icon: Handshake, bgColor: 'bg-[#FCE5E1]', textColor: 'text-[#D93E26]', borderColor: 'border-[#F6B1A5]' },
  { id: 'accepted', label: 'Accepté', icon: Trophy, bgColor: 'bg-[#CCE5E3]', textColor: 'text-[#005149]', borderColor: 'border-[#005149]' },
];

export const TrackerPage = () => {
  const [selectedOffer, setSelectedOffer] = useState(null);
  const [selectedCandidate, setSelectedCandidate] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [stageFilter, setStageFilter] = useState('all');
  const [showFilters, setShowFilters] = useState(false);
  const [loadingMatches, setLoadingMatches] = useState(false);
  const [showCandidateSelector, setShowCandidateSelector] = useState(false);
  const [editingNotes, setEditingNotes] = useState(false);
  const [editedNotes, setEditedNotes] = useState('');
  const [editingExcitement, setEditingExcitement] = useState(false);
  const [editedExcitement, setEditedExcitement] = useState(0);

  // Fetch offers
  const { data: offersData, error: offersError } = useSWR('offers', () => listOffers(100));
  const offers = offersData?.offers || [];

  // Fetch applications for selected offer
  const { data: applicationsData, error: applicationsError } = useSWR(
    selectedOffer ? `applications-${selectedOffer.id}` : null,
    () => selectedOffer ? listApplications(selectedOffer.id) : null,
    { refreshInterval: 5000 }
  );
  const applications = applicationsData?.applications || [];

  // Auto-select first offer
  useEffect(() => {
    if (offers.length > 0 && !selectedOffer) {
      setSelectedOffer(offers[0]);
    }
  }, [offers, selectedOffer]);

  // Get matched candidates for selected offer
  const loadMatches = async (offerId) => {
    setLoadingMatches(true);
    try {
      const topK = parseInt(import.meta.env.VITE_MATCH_TOPK || '5');
      const result = await matchOffer(offerId, topK);
      showToast(`${result.results.length} candidats matchés trouvés`, 'success');
      // Refresh applications
      mutate(`applications-${offerId}`);
    } catch (error) {
      console.error('Error loading matches:', error);
      showToast('Erreur lors du chargement des matchs', 'error');
    } finally {
      setLoadingMatches(false);
    }
  };

  // Filter candidates
  const filteredCandidates = useMemo(() => {
    let filtered = [...applications];

    if (searchQuery) {
      filtered = filtered.filter(app =>
        app.candidate_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (app.current_title && app.current_title.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    if (stageFilter !== 'all') {
      filtered = filtered.filter(app => app.stage === stageFilter);
    }

    return filtered.sort((a, b) => (b.match_score || 0) - (a.match_score || 0));
  }, [applications, searchQuery, stageFilter]);

  const getStageInfo = (stageId) => {
    return STAGES.find(s => s.id === stageId) || STAGES[0];
  };

  const renderStars = (level) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star 
        key={i} 
        className={i < level ? 'text-amber-400' : 'text-slate-300'}
        weight={i < level ? 'fill' : 'regular'}
        size={14}
      />
    ));
  };

  // Helper to parse recommendation from explanation
  const parseRecommendation = (explanation) => {
    if (!explanation) return { recommendation: 'N/A', reasoning: '' };
    
    const parts = explanation.split(':');
    if (parts.length >= 2) {
      return {
        recommendation: parts[0].trim(),
        reasoning: parts.slice(1).join(':').trim()
      };
    }
    return { recommendation: 'N/A', reasoning: explanation };
  };
  
  // Helper to get recommendation badge style
  const getRecommendationStyle = (recommendation) => {
    const rec = recommendation.toLowerCase();
    if (rec.includes('highly') || rec.includes('fortement')) {
      return { bg: 'bg-green-100', text: 'text-green-800', icon: 'CheckCircle', iconColor: 'text-green-600' };
    }
    if (rec.includes('recommended') || rec.includes('recommandé')) {
      return { bg: 'bg-blue-100', text: 'text-blue-800', icon: 'CheckCircle', iconColor: 'text-blue-600' };
    }
    if (rec.includes('consider') || rec.includes('considérer') || rec.includes('à considérer')) {
      return { bg: 'bg-yellow-100', text: 'text-yellow-800', icon: 'Info', iconColor: 'text-yellow-600' };
    }
    if (rec.includes('non adapté') || rec.includes('not suitable')) {
      return { bg: 'bg-red-100', text: 'text-red-800', icon: 'WarningCircle', iconColor: 'text-red-600' };
    }
    return { bg: 'bg-slate-100', text: 'text-slate-800', icon: 'Info', iconColor: 'text-slate-600' };
  };

  const getCandidatesByStage = (stageId) => {
    return applications.filter(app => app.stage === stageId).length;
  };

  const moveToNextStage = async (application) => {
    const currentIndex = STAGES.findIndex(s => s.id === application.stage);
    if (currentIndex >= STAGES.length - 1) {
      showToast('Le candidat est déjà à la dernière étape', 'info');
      return;
    }

    const nextStage = STAGES[currentIndex + 1];
    
    try {
      await updateApplication(application.id, { stage: nextStage.id });
      showToast(`Candidat déplacé vers "${nextStage.label}"`, 'success');
      
      // Update selected candidate immediately for instant UI feedback
      setSelectedCandidate(prev => ({
        ...prev,
        stage: nextStage.id,
        [`date_${nextStage.id}`]: new Date().toISOString()
      }));
      
      // Refresh all applications data
      await mutate(`applications-${selectedOffer.id}`);
      
      // Refresh candidate-specific applications (for candidate drawer)
      await mutate(`candidate-applications-${application.candidate_id}`);
      
      // If accepted, refresh offers list
      if (nextStage.id === 'accepted') {
        await mutate('offers');
        await mutate(['offers', 100]);
      }
    } catch (error) {
      console.error('Error updating application:', error);
      showToast('Erreur lors de la mise à jour', 'error');
    }
  };

  const handleDeleteApplication = async (applicationId) => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette candidature ?')) {
      return;
    }

    try {
      const candidateId = selectedCandidate.candidate_id;
      await deleteApplication(applicationId);
      showToast('Candidature supprimée', 'success');
      
      // Close detail panel
      setSelectedCandidate(null);
      
      // Refresh all data
      await mutate(`applications-${selectedOffer.id}`);
      await mutate(`candidate-applications-${candidateId}`);
      await mutate('offers');
      await mutate(['offers', 100]);
    } catch (error) {
      console.error('Error deleting application:', error);
      showToast('Erreur lors de la suppression', 'error');
    }
  };

  const handleSaveNotes = async () => {
    try {
      await updateApplication(selectedCandidate.id, { notes: editedNotes });
      showToast('Notes enregistrées', 'success');
      
      // Update selected candidate immediately
      setSelectedCandidate(prev => ({
        ...prev,
        notes: editedNotes
      }));
      
      // Refresh all data
      await mutate(`applications-${selectedOffer.id}`);
      await mutate(`candidate-applications-${selectedCandidate.candidate_id}`);
      
      setEditingNotes(false);
    } catch (error) {
      console.error('Error saving notes:', error);
      showToast('Erreur lors de l\'enregistrement', 'error');
    }
  };

  const handleSaveExcitement = async (level) => {
    try {
      await updateApplication(selectedCandidate.id, { excitement_level: level });
      showToast('Niveau d\'intérêt mis à jour', 'success');
      
      // Update selected candidate immediately
      setSelectedCandidate(prev => ({
        ...prev,
        excitement_level: level
      }));
      
      // Refresh all data
      await mutate(`applications-${selectedOffer.id}`);
      await mutate(`candidate-applications-${selectedCandidate.candidate_id}`);
      
      setEditingExcitement(false);
    } catch (error) {
      console.error('Error saving excitement:', error);
      showToast('Erreur lors de la mise à jour', 'error');
    }
  };

  const OfferCard = ({ offer, isSelected }) => {
    const offerApplications = applications.filter(app => app.offer_id === offer.id);
    const candidatesByStage = STAGES.map(stage => ({
      ...stage,
      count: offerApplications.filter(app => app.stage === stage.id).length
    }));

    return (
      <div
        onClick={() => {
          setSelectedOffer(offer);
          setSelectedCandidate(null);
        }}
        className={`
          p-4 border-b border-slate-200 cursor-pointer transition-all
          ${isSelected ? 'bg-teal-50 border-l-4 border-l-teal-600' : 'hover:bg-slate-50 border-l-4 border-l-transparent'}
        `}
      >
        <h3 className="font-semibold text-slate-900 mb-2 line-clamp-2">{offer.title}</h3>
        <div className="flex items-center gap-2 text-sm text-slate-600 mb-3">
          <Buildings size={14} />
          <span className="truncate">{offer.company || 'Non spécifié'}</span>
        </div>
        <div className="flex items-center gap-2 text-sm text-slate-600 mb-3">
          <MapPin size={14} />
          <span className="truncate">{offer.location || 'Non spécifié'}</span>
        </div>
        
        {/* Pipeline Mini View */}
        {offerApplications.length > 0 && (
          <div className="flex items-center gap-1 mb-2">
            {candidatesByStage.map(stage => {
              if (stage.count === 0) return null;
              return (
                <div
                  key={stage.id}
                  className={`px-2 py-1 rounded text-xs font-medium ${stage.bgColor} ${stage.textColor}`}
                  title={`${stage.count} ${stage.label}`}
                >
                  {stage.count}
                </div>
              );
            })}
          </div>
        )}

        <div className="text-xs text-slate-500">
          {offerApplications.length} candidat{offerApplications.length > 1 ? 's' : ''} suivi{offerApplications.length > 1 ? 's' : ''}
        </div>
      </div>
    );
  };

  const CandidateCard = ({ application, isSelected }) => {
    const stageInfo = getStageInfo(application.stage);
    const StageIcon = stageInfo.icon;

    return (
      <div
        onClick={() => setSelectedCandidate(application)}
        className={`
          bg-white border-2 rounded-lg p-4 cursor-pointer transition-all
          ${isSelected ? 'border-[#005149] shadow-lg ring-2 ring-[#CCE5E3]' : 'border-slate-200 hover:border-[#005149] hover:shadow-md'}
        `}
      >
        {/* Header */}
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1 min-w-0">
            <h4 className="font-semibold text-slate-900 mb-1 truncate">{application.candidate_name}</h4>
            <div className="text-sm text-slate-600 truncate">{application.current_title || 'Poste non spécifié'}</div>
          </div>
          <div className={`px-3 py-1 rounded-lg text-xs font-medium flex items-center gap-1 ${stageInfo.bgColor} ${stageInfo.textColor} flex-shrink-0 ml-2`}>
            <StageIcon size={14} weight="fill" />
            {stageInfo.label}
          </div>
        </div>

        {/* Match Score */}
        {application.match_score && (
          <div className="mb-3">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs text-slate-600">Score de match</span>
              <span className="text-sm font-bold text-[#005149]">{application.match_score}%</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2">
              <div
                className="bg-[#005149] h-2 rounded-full transition-all"
                style={{ width: `${application.match_score}%` }}
              />
            </div>
          </div>
        )}

        {/* Experience & Excitement */}
        <div className="flex items-center justify-between mb-3">
          <div className="text-xs text-slate-600">
            {application.years_experience ? `${Math.round(application.years_experience)} ans d'exp.` : 'Exp. non spécifiée'}
          </div>
          {application.excitement_level > 0 && (
            <div className="flex gap-0.5">
              {renderStars(application.excitement_level)}
            </div>
          )}
        </div>

        {/* Top Skills */}
        {application.top_skills && application.top_skills.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-3">
            {application.top_skills.slice(0, 3).map((skill, idx) => (
              <span
                key={idx}
                className="px-2 py-0.5 bg-[#E6F2F1] text-[#005149] rounded text-xs truncate"
              >
                {skill}
              </span>
            ))}
            {application.top_skills.length > 3 && (
              <span className="text-xs text-slate-500">+{application.top_skills.length - 3}</span>
            )}
          </div>
        )}

        {/* Notes Preview */}
        {application.notes && (
          <div className="text-xs text-slate-600 bg-slate-50 rounded p-2 line-clamp-2">
            {application.notes}
          </div>
        )}
      </div>
    );
  };

  if (offersError) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <p className="text-red-600 mb-2">Erreur lors du chargement des offres</p>
          <button 
            onClick={() => mutate('offers')}
            className="px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700"
          >
            Réessayer
          </button>
        </div>
      </div>
    );
  }

  if (!offers || offers.length === 0) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center text-slate-500">
          <Briefcase size={48} className="mx-auto mb-4 opacity-50" />
          <p className="text-lg mb-2">Aucune offre d'emploi disponible</p>
          <p className="text-sm">Créez une offre pour commencer le suivi des candidats</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-slate-50">
      {/* Left Panel - Offers List */}
      <div className="w-80 bg-white border-r border-slate-200 flex flex-col">
        <div className="p-4 border-b border-slate-200">
          <h1 className="text-xl font-bold text-slate-900 mb-4">
            Offres d'emploi ({offers.length})
          </h1>
          <div className="relative">
            <MagnifyingGlass size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher une offre..."
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#005149] text-sm"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto">
          {offers.map(offer => (
            <OfferCard
              key={offer.id}
              offer={offer}
              isSelected={selectedOffer?.id === offer.id}
            />
          ))}
        </div>
      </div>

      {/* Middle Panel - Candidates Grid */}
      <div className="flex-1 flex flex-col">
        {selectedOffer && (
          <>
            {/* Header */}
            <div className="bg-white border-b border-slate-200 p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-2xl font-bold text-slate-900 mb-2">
                    {selectedOffer.title}
                  </h2>
                  <div className="flex items-center gap-4 text-slate-600">
                    <div className="flex items-center gap-2">
                      <Buildings size={18} />
                      <span>{selectedOffer.company || 'Non spécifié'}</span>
                    </div>
                    <span className="text-slate-400">•</span>
                    <div className="flex items-center gap-2">
                      <MapPin size={18} />
                      <span>{selectedOffer.location || 'Non spécifié'}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setShowCandidateSelector(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-[#005149] hover:bg-[#00413A] text-white font-medium rounded-lg transition-colors shadow-sm"
                  >
                    <Plus size={20} weight="bold" />
                    Ajouter candidat
                  </button>
                  <button 
                    onClick={() => loadMatches(selectedOffer.id)}
                    disabled={loadingMatches}
                    className="flex items-center gap-2 px-4 py-2 bg-[#005149] hover:bg-[#00413A] disabled:bg-slate-400 text-white font-medium rounded-lg transition-colors shadow-sm"
                  >
                    {loadingMatches ? (
                      <>
                        <CircleNotch size={20} className="animate-spin" />
                        Chargement...
                      </>
                    ) : (
                      <>
                        <Star size={20} weight="bold" />
                        Matcher candidats
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Search & Filters */}
              <div className="flex items-center gap-3">
                <div className="flex-1 relative">
                  <MagnifyingGlass size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    placeholder="Rechercher un candidat..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className={`flex items-center gap-2 px-4 py-2 border rounded-lg transition-colors ${
                    showFilters ? 'bg-[#E6F2F1] border-[#005149] text-[#005149]' : 'border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <FunnelSimple size={18} />
                  Filtres
                </button>
              </div>

              {/* Stage Filters */}
              {showFilters && (
                <div className="mt-3 flex items-center gap-2 flex-wrap">
                  <button
                    onClick={() => setStageFilter('all')}
                    className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                      stageFilter === 'all'
                        ? 'bg-[#005149] text-white shadow-sm'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    Tous ({applications.length})
                  </button>
                  {STAGES.map(stage => {
                    const count = getCandidatesByStage(stage.id);
                    if (count === 0) return null;
                    return (
                      <button
                        key={stage.id}
                        onClick={() => setStageFilter(stage.id)}
                        className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${
                          stageFilter === stage.id
                            ? 'bg-[#005149] text-white shadow-sm'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {stage.label} ({count})
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Pipeline Summary - New Stylish KPI Cards */}
              <div className="mt-8 flex justify-center">
                <KPIFilter
                  counts={{
                    bookmarked: getCandidatesByStage('bookmarked'),
                    applying: getCandidatesByStage('applying'),
                    applied: getCandidatesByStage('applied'),
                    interviewing: getCandidatesByStage('interviewing'),
                    negotiating: getCandidatesByStage('negotiating'),
                    accepted: getCandidatesByStage('accepted'),
                  }}
                  activeFilter={stageFilter}
                  onFilterChange={setStageFilter}
                />
              </div>
            </div>

            {/* Candidates Grid */}
            <div className="flex-1 overflow-y-auto p-6">
              {applicationsError && (
                <div className="text-center text-red-600 mb-4">
                  Erreur lors du chargement des candidatures
                </div>
              )}

              {filteredCandidates.length > 0 ? (
                <div className="grid grid-cols-3 gap-4">
                  {filteredCandidates.map(application => (
                    <CandidateCard
                      key={application.id}
                      application={application}
                      isSelected={selectedCandidate?.id === application.id}
                    />
                  ))}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center h-64 text-slate-400">
                  <UsersIcon size={48} className="mb-4 opacity-50" />
                  <p className="text-lg mb-2">Aucun candidat trouvé</p>
                  <p className="text-sm mb-4">Cliquez sur "Matcher candidats" pour trouver des candidats correspondants</p>
                </div>
              )}
            </div>
          </>
        )}
      </div>

      {/* Candidate Selector Modal */}
      {showCandidateSelector && selectedOffer && (
        <CandidateSelector
          offerId={selectedOffer.id}
          onClose={() => setShowCandidateSelector(false)}
        />
      )}

      {/* Right Panel - Candidate Detail */}
      {selectedCandidate && (
        <div className="w-96 bg-white border-l border-slate-200 overflow-y-auto">
          <div className="p-6">
            {/* Header */}
            <div className="flex items-start justify-between mb-6">
              <div className="flex-1">
                <h3 className="text-xl font-bold text-slate-900 mb-1">
                  {selectedCandidate.candidate_name}
                </h3>
                <p className="text-slate-600">{selectedCandidate.current_title || 'Poste non spécifié'}</p>
              </div>
              <button
                onClick={() => setSelectedCandidate(null)}
                className="p-1 hover:bg-slate-100 rounded transition-colors"
              >
                <X size={24} />
              </button>
            </div>

            {/* Match Score Gauge */}
            {selectedCandidate.match_score && (
              <div className="bg-white border border-slate-200 rounded-lg p-6 mb-6 shadow-sm">
                <div className="flex flex-col items-center">
                  <CircularGauge percentage={selectedCandidate.match_score} size={140} strokeWidth={14} />
                  
                  {/* Recommendation Display */}
                  <div className="mt-6 w-full">
                    {selectedCandidate.explanation ? (
                      (() => {
                        const { recommendation, reasoning } = parseRecommendation(selectedCandidate.explanation);
                        const recStyle = getRecommendationStyle(recommendation);
                        const RecommendationIcon = recStyle.icon === 'CheckCircle' ? CheckCircleIcon : 
                                                  recStyle.icon === 'WarningCircle' ? WarningCircle : Info;
                        
                        return (
                          <div className="text-center">
                            <div className="text-sm text-slate-600 mb-3">Recommandation</div>
                            <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-lg ${recStyle.bg} border-2 border-${recStyle.text.replace('text-', '')}/20`}>
                              <RecommendationIcon className={`h-5 w-5 ${recStyle.iconColor}`} />
                              <span className={`font-bold text-sm ${recStyle.text}`}>
                                {recommendation}
                              </span>
                            </div>
                            {reasoning && (
                              <div className="mt-3 text-xs text-slate-600 bg-slate-50 rounded p-2 text-left">
                                {reasoning}
                              </div>
                            )}
                          </div>
                        );
                      })()
                    ) : (
                      <div className="text-center">
                        <div className="text-sm text-slate-600 mb-2">Niveau d'intérêt</div>
                        {editingExcitement ? (
                          <div className="flex items-center justify-center gap-2">
                            {[1, 2, 3, 4, 5].map(level => (
                              <button
                                key={level}
                                onClick={() => handleSaveExcitement(level)}
                                className="hover:scale-110 transition-transform"
                              >
                                <Star 
                                  size={24} 
                                  weight={level <= editedExcitement ? 'fill' : 'regular'}
                                  className="text-[#F4B639]"
                                />
                              </button>
                            ))}
                          </div>
                        ) : (
                          <div className="flex items-center justify-center gap-1">
                            {renderStars(selectedCandidate.excitement_level || 0)}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Contact Info */}
            <div className="bg-slate-50 rounded-lg p-4 mb-6 space-y-2">
              {selectedCandidate.email && (
                <div className="flex items-center gap-2 text-sm">
                  <Envelope size={16} className="text-slate-400" />
                  <a href={`mailto:${selectedCandidate.email}`} target="_blank" rel="noopener noreferrer" className="text-[#005149] hover:underline truncate font-medium">
                    {selectedCandidate.email}
                  </a>
                </div>
              )}
              {selectedCandidate.phone && (
                <div className="flex items-center gap-2 text-sm">
                  <Phone size={16} className="text-slate-400" />
                  <a href={`tel:${selectedCandidate.phone}`} className="text-[#005149] hover:underline font-medium">
                    {selectedCandidate.phone}
                  </a>
                </div>
              )}
              {selectedCandidate.location && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <MapPin size={16} className="text-slate-400" />
                  <span>{selectedCandidate.location}</span>
                </div>
              )}
              {selectedCandidate.linkedin && (
                <div className="flex items-center gap-2 text-sm">
                  <LinkedinLogo size={16} className="text-slate-400" />
                  <a 
                    href={selectedCandidate.linkedin.startsWith('http') ? selectedCandidate.linkedin : `https://${selectedCandidate.linkedin}`} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-[#0A66C2] hover:underline truncate font-medium"
                    onClick={(e) => e.stopPropagation()}
                  >
                    Profil LinkedIn
                  </a>
                </div>
              )}
              {selectedCandidate.github && (
                <div className="flex items-center gap-2 text-sm">
                  <GithubLogo size={16} className="text-slate-400" />
                  <a 
                    href={selectedCandidate.github.startsWith('http') ? selectedCandidate.github : `https://${selectedCandidate.github}`} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-[#005149] hover:underline truncate font-medium"
                    onClick={(e) => e.stopPropagation()}
                  >
                    Profil GitHub
                  </a>
                </div>
              )}
              {selectedCandidate.years_experience && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <Briefcase size={16} className="text-slate-400" />
                  <span>{Math.round(selectedCandidate.years_experience)} ans d'expérience</span>
                </div>
              )}
            </div>

            {/* Skills */}
            {selectedCandidate.top_skills && selectedCandidate.top_skills.length > 0 && (
              <div className="mb-6">
                <h4 className="font-semibold text-slate-900 mb-3">Compétences</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedCandidate.top_skills.map((skill, idx) => (
                    <span
                      key={idx}
                      className="px-3 py-1 bg-[#E6F2F1] text-[#005149] rounded-full text-sm font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Notes */}
            <div className="mb-6">
              <h4 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                <ChatCircleDots size={18} />
                Notes
              </h4>
              {editingNotes ? (
                <div>
                  <textarea
                    value={editedNotes}
                    onChange={(e) => setEditedNotes(e.target.value)}
                    className="w-full p-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#005149] text-sm"
                    rows={4}
                    placeholder="Ajoutez des notes sur ce candidat..."
                  />
                  <div className="flex items-center gap-2 mt-2">
                    <button
                      onClick={handleSaveNotes}
                      className="px-3 py-1 bg-[#005149] hover:bg-[#00413A] text-white text-sm rounded transition-colors shadow-sm"
                    >
                      Enregistrer
                    </button>
                    <button
                      onClick={() => setEditingNotes(false)}
                      className="px-3 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 text-sm rounded transition-colors"
                    >
                      Annuler
                    </button>
                  </div>
                </div>
              ) : (
                <div 
                  onClick={() => {
                    setEditingNotes(true);
                    setEditedNotes(selectedCandidate.notes || '');
                  }}
                  className="bg-slate-50 rounded-lg p-3 text-sm text-slate-700 cursor-pointer hover:bg-slate-100 transition-colors min-h-[60px]"
                >
                  {selectedCandidate.notes || 'Cliquez pour ajouter des notes...'}
                </div>
              )}
            </div>

            {/* Timeline */}
            <div className="mb-6">
              <h4 className="font-semibold text-slate-900 mb-3">Chronologie</h4>
              <div className="space-y-2 text-sm">
                {selectedCandidate.date_bookmarked && (
                  <div className="flex items-center gap-2 text-slate-600">
                    <div className="w-2 h-2 bg-teal-500 rounded-full"></div>
                    <span>Sauvegardé le {new Date(selectedCandidate.date_bookmarked).toLocaleDateString('fr-FR')}</span>
                  </div>
                )}
                {selectedCandidate.date_applied && (
                  <div className="flex items-center gap-2 text-slate-600">
                    <div className="w-2 h-2 bg-teal-500 rounded-full"></div>
                    <span>Postulé le {new Date(selectedCandidate.date_applied).toLocaleDateString('fr-FR')}</span>
                  </div>
                )}
                {selectedCandidate.date_interviewing && (
                  <div className="flex items-center gap-2 text-slate-600">
                    <div className="w-2 h-2 bg-teal-500 rounded-full"></div>
                    <span>Entretien le {new Date(selectedCandidate.date_interviewing).toLocaleDateString('fr-FR')}</span>
                  </div>
                )}
                {selectedCandidate.date_negotiating && (
                  <div className="flex items-center gap-2 text-slate-600">
                    <div className="w-2 h-2 bg-teal-500 rounded-full"></div>
                    <span>Négociation le {new Date(selectedCandidate.date_negotiating).toLocaleDateString('fr-FR')}</span>
                  </div>
                )}
                {selectedCandidate.date_accepted && (
                  <div className="flex items-center gap-2 text-green-600 font-medium">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span>Accepté le {new Date(selectedCandidate.date_accepted).toLocaleDateString('fr-FR')}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2">
              <button 
                onClick={() => moveToNextStage(selectedCandidate)}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-[#005149] hover:bg-[#00413A] text-white font-medium rounded-lg transition-colors shadow-sm"
              >
                <ArrowRight size={20} weight="bold" />
                Passer à l'étape suivante
              </button>
              <button 
                onClick={() => {
                  setEditingNotes(true);
                  setEditedNotes(selectedCandidate.notes || '');
                  setEditingExcitement(true);
                  setEditedExcitement(selectedCandidate.excitement_level || 0);
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-white hover:bg-slate-50 text-[#005149] font-medium rounded-lg transition-colors border-2 border-[#005149]"
              >
                <PencilSimple size={20} />
                Modifier
              </button>
              <button 
                onClick={() => handleDeleteApplication(selectedCandidate.id)}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-white hover:bg-red-50 text-[#E74E30] font-medium rounded-lg transition-colors border-2 border-[#E74E30]"
              >
                <Trash size={20} />
                Supprimer
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
