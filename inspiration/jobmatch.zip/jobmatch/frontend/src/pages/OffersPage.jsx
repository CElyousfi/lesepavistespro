import { useState } from 'react';
import { Plus } from '@phosphor-icons/react';
import { Button } from '../components/ui/Button';
import { OfferIngest } from '../components/features/OfferIngest';
import { RichOfferTable } from '../components/features/RichOfferTable';
import { OfferDrawer } from '../components/features/OfferDrawer';
import { MatchResults } from '../components/features/MatchResults';
import { useOffers } from '../lib/useApi';
import { mutate } from 'swr';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000';

export const OffersPage = () => {
  const [showOfferIngest, setShowOfferIngest] = useState(false);
  const [selectedOfferId, setSelectedOfferId] = useState(null);
  const [matchResults, setMatchResults] = useState(null);
  
  const { offers } = useOffers(100);

  const handleOfferCreated = (offer) => {
    mutate(['offers', 100]);
    setSelectedOfferId(offer.id);
  };

  const handleSelectOffer = (offerId) => {
    setSelectedOfferId(offerId);
  };

  const handleCloseDrawer = () => {
    setSelectedOfferId(null);
  };

  const handleMatchResults = (results) => {
    setMatchResults(results);
  };

  const handleCloseMatchResults = () => {
    setMatchResults(null);
  };

  return (
    <>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Offres d'emploi</h1>
            <p className="text-sm text-slate-600 mt-1">Gérez vos postes ouverts et trouvez les meilleurs candidats</p>
          </div>
          <Button onClick={() => setShowOfferIngest(true)}>
            <Plus className="h-5 w-5" weight="bold" />
            Nouvelle offre
          </Button>
        </div>

        <RichOfferTable 
          offers={offers} 
          onSelectOffer={handleSelectOffer}
          onUpdateOffer={async (offerId, updates) => {
            try {
              if (updates.remote_policy) {
                // Optimistic update - update UI immediately
                mutate(
                  ['offers', 100],
                  (currentData) => {
                    if (!currentData) return currentData;
                    return {
                      ...currentData,
                      offers: currentData.offers.map(offer =>
                        offer.id === offerId
                          ? { ...offer, remote_policy: updates.remote_policy }
                          : offer
                      )
                    };
                  },
                  false // Don't revalidate immediately
                );

                // Update remote policy via API
                await fetch(`${API_BASE}/api/offers/${offerId}/remote-policy?remote_policy=${updates.remote_policy}`, {
                  method: 'PATCH',
                });
                
                // Revalidate to ensure consistency
                mutate(['offers', 100]);
              }
            } catch (error) {
              console.error('Failed to update offer:', error);
              // Revert optimistic update on error
              mutate(['offers', 100]);
            }
          }}
        />
      </div>

      {/* Modals */}
      {showOfferIngest && (
        <OfferIngest
          onClose={() => setShowOfferIngest(false)}
          onSuccess={handleOfferCreated}
        />
      )}

      {selectedOfferId && (
        <OfferDrawer
          offerId={selectedOfferId}
          onClose={handleCloseDrawer}
          onMatchResults={handleMatchResults}
          onDelete={() => {
            mutate(`${API_BASE}/api/offers?limit=20`);
            setSelectedOfferId(null);
          }}
        />
      )}

      {matchResults && (
        <MatchResults
          matchData={matchResults}
          onClose={handleCloseMatchResults}
        />
      )}
    </>
  );
};
