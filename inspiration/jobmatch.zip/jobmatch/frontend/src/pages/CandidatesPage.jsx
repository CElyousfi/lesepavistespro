import { useState } from 'react';
import { Plus, CircleNotch, Warning } from '@phosphor-icons/react';
import { Button } from '../components/ui/Button';
import { CandidateCardGrid } from '../components/features/CandidateCardGrid';
import { CandidateDrawer } from '../components/features/CandidateDrawer';
import { ResumeUpload } from '../components/features/ResumeUpload';
import { NewCandidateModal } from '../components/features/NewCandidateModal';
import { createCandidate } from '../lib/api';
import { showToast } from '../components/ui/Toast';
import { mutate } from 'swr';
import { useCandidates } from '../lib/useApi';
import { mutateCandidates } from '../lib/mutate';

export const CandidatesPage = () => {
  const [selectedCandidateId, setSelectedCandidateId] = useState(null);
  const [uploadCandidateId, setUploadCandidateId] = useState(null);
  const [isCreatingCandidate, setIsCreatingCandidate] = useState(false);
  const [showNewCandidateModal, setShowNewCandidateModal] = useState(false);
  
  const { candidates, isLoading, isError } = useCandidates(100);

  if (isError) {
    return (
      <div className="p-6">
        <div className="text-center py-16 bg-white rounded-xl border border-slate-200">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-red-100 mb-4">
            <Warning className="h-10 w-10 text-red-600" weight="fill" />
          </div>
          <p className="text-red-600 font-medium text-lg">Erreur lors du chargement des candidats</p>
          <p className="text-sm text-slate-500 mt-2">Veuillez vérifier que le serveur backend est démarré</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="text-center py-16 bg-white rounded-xl border border-slate-200">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-100 mb-4">
            <CircleNotch className="h-10 w-10 text-slate-400 animate-spin" />
          </div>
          <p className="text-slate-700 font-medium text-lg">Chargement des candidats...</p>
          <p className="text-sm text-slate-500 mt-2">Veuillez patienter</p>
        </div>
      </div>
    );
  }

  const handleCreateCandidate = () => setShowNewCandidateModal(true);

  const handleUploadCV = (candidateId) => {
    setUploadCandidateId(candidateId);
  };

  const handleUploadSuccess = () => {
    mutate(['candidates', 100]);
  };

  const candidatesWithCV = candidates?.filter(c => c.profile_count > 0).length || 0;

  return (
    <>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Candidats</h1>
            <p className="text-sm text-slate-600 mt-1">
              {candidates?.length || 0} candidat{candidates?.length > 1 ? 's' : ''} • {candidatesWithCV} avec CV
            </p>
          </div>
          <Button 
            onClick={handleCreateCandidate}
            disabled={isCreatingCandidate}
          >
            {isCreatingCandidate ? (
              <>
                <CircleNotch className="h-5 w-5 animate-spin" weight="bold" />
                Création...
              </>
            ) : (
              <>
                <Plus className="h-5 w-5" weight="bold" />
                Nouveau candidat
              </>
            )}
          </Button>
        </div>

        <CandidateCardGrid 
          candidates={candidates || []}
          onSelectCandidate={setSelectedCandidateId}
          onUploadCV={setUploadCandidateId}
        />

        {uploadCandidateId && (
          <div className="mt-6">
            <ResumeUpload
              candidateId={uploadCandidateId}
              onSuccess={handleUploadSuccess}
            />
          </div>
        )}
      </div>

      {selectedCandidateId && (
        <CandidateDrawer
          candidateId={selectedCandidateId}
          onClose={() => setSelectedCandidateId(null)}
        />
      )}

      {showNewCandidateModal && (
        <NewCandidateModal
          onClose={() => setShowNewCandidateModal(false)}
          onCreated={() => {
            mutateCandidates();
            setShowNewCandidateModal(false);
          }}
        />
      )}
    </>
  );
};
