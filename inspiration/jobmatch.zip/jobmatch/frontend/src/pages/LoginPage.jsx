import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Envelope, Lock, Eye, EyeSlash } from '@phosphor-icons/react';
import { useAuth } from '../contexts/AuthContext';

export const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { login } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const user = await login(email, password);

      // Check if must change password
      if (user.must_change_password) {
        navigate('/force-change-password');
      } else {
        navigate('/');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top bar */}
      <div className="w-full bg-teal-600 text-white">
        <div className="max-w-6xl mx-auto flex items-center justify-between gap-4 px-4 py-2">
          <div className="flex items-center gap-3">
            <p className="text-[12px] sm:text-xs font-medium tracking-wide opacity-90">Beyond Hiring - towards understanding talent</p>
          </div>
          <div className="hidden sm:block flex-1 text-center"></div>
          <div className="opacity-0 select-none">.</div>
        </div>
      </div>

      <div className="relative overflow-hidden flex-1 flex items-center justify-center p-4 pt-6">
      {/* Glassy gradient background - teal to transparent */}
      <div className="absolute inset-0 bg-gradient-to-br from-teal-400/30 via-teal-200/15 to-transparent backdrop-blur-3xl"></div>

      {/* Top-left logo (overlay) */}
      <div className="absolute top-6 left-0 right-0 px-6 pointer-events-none">
        <div className="relative max-w-6xl mx-auto">
          <img
            src="/logo.png"
            onError={(e) => { e.currentTarget.src = '/favicon.ico'; }}
            alt="App Logo"
            className="absolute left-2 sm:left-0 top-0 h-8 w-auto select-none pointer-events-none"
          />
        </div>
      </div>
      
      {/* Decorative glassy blobs */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-teal-400/30 rounded-full mix-blend-normal filter blur-3xl opacity-60 animate-blob"></div>
      <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-teal-300/25 rounded-full mix-blend-normal filter blur-3xl opacity-50 animate-blob animation-delay-2000"></div>
      <div className="absolute bottom-0 left-1/2 w-[450px] h-[450px] bg-teal-200/20 rounded-full mix-blend-normal filter blur-3xl opacity-40 animate-blob animation-delay-4000"></div>
      
      {/* Side brand mark removed for cleaner header-first layout */}

      {/* Login card with glassmorphism */}
      <div className="relative w-full max-w-md">
        {/* Glassy card */}
        <div className="backdrop-blur-xl bg-white/70 rounded-3xl shadow-2xl border border-white/20 p-10">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-slate-800 mb-1">Access your account</h1>
            <p className="text-slate-600 text-sm">Welcome back</p>
          </div>

          {error && (
            <div className="bg-red-50/80 backdrop-blur-sm border border-red-200/50 text-red-700 px-4 py-3 rounded-xl mb-6 text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                EMAIL
              </label>
              <div className="relative">
                <Envelope className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your.email@company.com"
                  className="w-full pl-12 pr-4 py-3.5 bg-white/50 backdrop-blur-sm border border-slate-200/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500/50 transition-all text-slate-900 placeholder:text-slate-400"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                PASSWORD
              </label>
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full pl-12 pr-12 py-3.5 bg-white/50 backdrop-blur-sm border border-slate-200/50 rounded-xl focus:outline-none focus:ring-2 focus:ring-teal-500/50 focus:border-teal-500/50 transition-all text-slate-900 placeholder:text-slate-400"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-slate-500 hover:text-teal-600 transition"
                  aria-label={showPassword ? 'Hide password' : 'Show password'}
                >
                  {showPassword ? <EyeSlash className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700 text-white font-semibold py-3.5 rounded-xl transition-all duration-200 shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed mt-6"
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  Signing in...
                </span>
              ) : (
                'LOGIN'
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <a href="#" className="text-sm text-slate-600 hover:text-teal-600 transition-colors">
              Forgot password?
            </a>
          </div>
        </div>

        {/* Subtle bottom text */}
        <p className="text-center mt-6 text-sm text-slate-500">
          Don't have an account? Contact your administrator
        </p>
      </div>

      <style>{`
        @keyframes blob {
          0%, 100% { transform: translate(0, 0) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
        }
        .animate-blob { animation: blob 7s infinite; }
        .animation-delay-2000 { animation-delay: 2s; }
        .animation-delay-4000 { animation-delay: 4s; }
      `}</style>
      </div>
    </div>
  );
};
