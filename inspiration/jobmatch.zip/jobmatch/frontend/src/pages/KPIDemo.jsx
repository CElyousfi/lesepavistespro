import React from 'react';
import { KPIFilter } from './components/ui/KPIFilter';

// Demo component to showcase the new KPI cards
const KPIDemo = () => {
  const [activeFilter, setActiveFilter] = React.useState('all');
  
  const demoCounts = {
    bookmarked: 12,
    applying: 8,
    applied: 15,
    interviewing: 5,
    negotiating: 3,
    accepted: 2,
  };

  return (
    <div className="p-8 bg-slate-50 min-h-screen">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold text-slate-900 mb-8 text-center">
          New Stylish KPI Filter Cards
        </h1>
        
        <div className="bg-white rounded-xl p-8 shadow-sm border border-slate-200">
          <h2 className="text-xl font-semibold text-slate-800 mb-6 text-center">
            Application Pipeline Overview
          </h2>
          
          <KPIFilter
            counts={demoCounts}
            activeFilter={activeFilter}
            onFilterChange={setActiveFilter}
            className="justify-center"
          />
          
          <div className="mt-8 text-center">
            <p className="text-slate-600">
              Active Filter: <span className="font-semibold text-[#005149]">
                {activeFilter === 'all' ? 'All Stages' : activeFilter}
              </span>
            </p>
            <p className="text-sm text-slate-500 mt-2">
              Click on any card to filter candidates by stage
            </p>
          </div>
        </div>
        
        <div className="mt-8 bg-white rounded-xl p-6 shadow-sm border border-slate-200">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Features:</h3>
          <ul className="space-y-2 text-slate-600">
            <li className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              Clean minimalist design with green/grey color scheme
            </li>
            <li className="flex items-center gap-2">
              <span className="w-2 h-2 bg-gray-500 rounded-full"></span>
              Phosphor Icons for consistent iconography
            </li>
            <li className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              Interactive filtering with visual feedback
            </li>
            <li className="flex items-center gap-2">
              <span className="w-2 h-2 bg-gray-500 rounded-full"></span>
              Smooth hover effects and transitions
            </li>
            <li className="flex items-center gap-2">
              <span className="w-2 h-2 bg-green-500 rounded-full"></span>
              Active state indicators with arrow icons
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default KPIDemo;
