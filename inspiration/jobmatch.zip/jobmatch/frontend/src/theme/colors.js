// Brand Color System
export const colors = {
  // Primary - Teal
  primary: {
    DEFAULT: '#005149',
    50: '#E6F2F1',
    100: '#CCE5E3',
    200: '#99CBC7',
    300: '#66B1AB',
    400: '#33978F',
    500: '#005149',
    600: '#00413A',
    700: '#00312C',
    800: '#00201D',
    900: '#00100F',
  },
  
  // Secondary - Orange
  secondary: {
    DEFAULT: '#E74E30',
    50: '#FEF2F0',
    100: '#FCE5E1',
    200: '#F9CBC3',
    300: '#F6B1A5',
    400: '#F39787',
    500: '#E74E30',
    600: '#D93E26',
    700: '#B3331F',
    800: '#8C2818',
    900: '#661D11',
  },
  
  // Accent - Yellow
  accent: {
    DEFAULT: '#F4B639',
    50: '#FEF9ED',
    100: '#FDF3DB',
    200: '#FBE7B7',
    300: '#F9DB93',
    400: '#F7CF6F',
    500: '#F4B639',
    600: '#E6A11E',
    700: '#C18618',
    800: '#9B6B13',
    900: '#75500E',
  },
  
  // Neutrals
  slate: {
    50: '#F8FAFC',
    100: '#F1F5F9',
    200: '#E2E8F0',
    300: '#CBD5E1',
    400: '#94A3B8',
    500: '#64748B',
    600: '#475569',
    700: '#334155',
    800: '#1E293B',
    900: '#0F172A',
  },
  
  // Semantic Colors
  success: '#005149',  // Use primary for success
  warning: '#F4B639',  // Use accent for warning
  error: '#E74E30',    // Use secondary for error
  info: '#005149',     // Use primary for info
};

// Stage Colors (using brand colors)
export const stageColors = {
  bookmarked: {
    bg: 'bg-slate-100',
    text: 'text-slate-700',
    border: 'border-slate-300',
  },
  applying: {
    bg: 'bg-[#CCE5E3]',  // primary-100
    text: 'text-[#005149]',  // primary-500
    border: 'border-[#99CBC7]',  // primary-200
  },
  applied: {
    bg: 'bg-[#CCE5E3]',
    text: 'text-[#00413A]',  // primary-600
    border: 'border-[#66B1AB]',  // primary-300
  },
  interviewing: {
    bg: 'bg-[#FDF3DB]',  // accent-100
    text: 'text-[#C18618]',  // accent-700
    border: 'border-[#F9DB93]',  // accent-300
  },
  negotiating: {
    bg: 'bg-[#FCE5E1]',  // secondary-100
    text: 'text-[#D93E26]',  // secondary-600
    border: 'border-[#F6B1A5]',  // secondary-300
  },
  accepted: {
    bg: 'bg-[#CCE5E3]',  // primary-100
    text: 'text-[#005149]',  // primary-500
    border: 'border-[#005149]',  // primary-500
  },
};

export default colors;
