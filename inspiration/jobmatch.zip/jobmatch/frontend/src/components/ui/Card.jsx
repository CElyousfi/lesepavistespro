import clsx from 'clsx';

export const Card = ({ children, className, onClick }) => {
  return (
    <div
      onClick={onClick}
      className={clsx(
        'bg-white rounded-xl shadow-sm border border-slate-200 p-5 transition-all',
        onClick && 'cursor-pointer hover:shadow-lg hover:border-teal-300 hover:-translate-y-0.5',
        className
      )}
    >
      {children}
    </div>
  );
};
