export const CircularGauge = ({ percentage, size = 120, strokeWidth = 12 }) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const offset = circumference - (percentage / 100) * circumference;
  
  // Calculate smooth gradient color based on percentage
  // Red (#E74E30) → Yellow (#F4B639) → Green (#005149)
  const getColor = (percent) => {
    if (percent <= 50) {
      // Red to Yellow (0-50%)
      const ratio = percent / 50;
      return interpolateColor('#E74E30', '#F4B639', ratio);
    } else {
      // Yellow to Green (50-100%)
      const ratio = (percent - 50) / 50;
      return interpolateColor('#F4B639', '#005149', ratio);
    }
  };
  
  // Interpolate between two hex colors
  const interpolateColor = (color1, color2, ratio) => {
    const hex = (color) => {
      const r = parseInt(color.slice(1, 3), 16);
      const g = parseInt(color.slice(3, 5), 16);
      const b = parseInt(color.slice(5, 7), 16);
      return { r, g, b };
    };
    
    const c1 = hex(color1);
    const c2 = hex(color2);
    
    const r = Math.round(c1.r + (c2.r - c1.r) * ratio);
    const g = Math.round(c1.g + (c2.g - c1.g) * ratio);
    const b = Math.round(c1.b + (c2.b - c1.b) * ratio);
    
    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
  };
  
  const color = getColor(percentage);
  
  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width={size} height={size} className="transform -rotate-90">
        {/* Background circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#E2E8F0"
          strokeWidth={strokeWidth}
          fill="none"
        />
        {/* Progress circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={color}
          strokeWidth={strokeWidth}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          className="transition-all duration-500 ease-out"
        />
      </svg>
      {/* Percentage text */}
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-3xl font-bold text-slate-900">{percentage}%</span>
        <span className="text-xs text-slate-600 mt-1">Match Score</span>
      </div>
    </div>
  );
};
