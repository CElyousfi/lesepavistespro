import clsx from 'clsx';

export const ProgressPill = ({ score, className }) => {
  const getColor = (score) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-teal-500';
    if (score >= 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };
  
  const getTextColor = (score) => {
    if (score >= 80) return 'text-green-700';
    if (score >= 60) return 'text-teal-700';
    if (score >= 40) return 'text-yellow-700';
    return 'text-red-700';
  };
  
  return (
    <div className={clsx('relative', className)}>
      <div className="flex items-center justify-center w-20 h-20 rounded-full bg-white border-4 border-slate-100 relative overflow-hidden shadow-lg">
        <div
          className={clsx('absolute inset-0 opacity-10', getColor(score))}
          style={{ clipPath: `inset(${100 - score}% 0 0 0)` }}
        />
        <div className="relative z-10 text-center">
          <span className={clsx('text-2xl font-bold', getTextColor(score))}>
            {Math.round(score)}
          </span>
          <span className="text-xs text-slate-500 block">%</span>
        </div>
      </div>
    </div>
  );
};
