import clsx from 'clsx';

export const Chip = ({ children, variant = 'teal', className }) => {
  const variants = {
    teal: 'bg-teal-500 text-white shadow-sm',
    mint: 'bg-mint-100 text-teal-800 border border-teal-300',
    red: 'bg-red-50 text-red-700 border border-red-300',
    gray: 'bg-slate-100 text-slate-700 border border-slate-300',
  };
  
  return (
    <span
      className={clsx(
        'inline-flex items-center px-3 py-1.5 rounded-full text-sm font-medium transition-all',
        variants[variant],
        className
      )}
    >
      {children}
    </span>
  );
};
