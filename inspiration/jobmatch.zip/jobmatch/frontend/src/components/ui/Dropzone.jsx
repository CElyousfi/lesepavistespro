import { useRef, useState } from 'react';
import { Upload } from 'lucide-react';
import clsx from 'clsx';

export const Dropzone = ({ onFileSelect, accept = '.pdf', multiple = false }) => {
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef(null);
  
  const handleDragOver = (e) => {
    e.preventDefault();
    setIsDragging(true);
  };
  
  const handleDragLeave = (e) => {
    e.preventDefault();
    setIsDragging(false);
  };
  
  const handleDrop = (e) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    const validFiles = files.filter(file => 
      accept.split(',').some(type => file.name.endsWith(type.trim()))
    );
    
    if (validFiles.length > 0) {
      onFileSelect(multiple ? validFiles : validFiles[0]);
    }
  };
  
  const handleChange = (e) => {
    const files = Array.from(e.target.files);
    if (files.length > 0) {
      onFileSelect(multiple ? files : files[0]);
    }
  };
  
  const handleClick = () => {
    inputRef.current?.click();
  };
  
  return (
    <div
      onClick={handleClick}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
      className={clsx(
        'border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors',
        isDragging
          ? 'border-teal-500 bg-teal-50'
          : 'border-slate-300 hover:border-teal-400 hover:bg-slate-50'
      )}
    >
      <input
        ref={inputRef}
        type="file"
        accept={accept}
        multiple={multiple}
        onChange={handleChange}
        className="hidden"
      />
      <Upload className="mx-auto h-12 w-12 text-slate-400 mb-3" />
      <p className="text-sm text-slate-600">
        {accept === '.pdf'
          ? 'Cliquez pour sélectionner ou glissez-déposez un fichier PDF'
          : 'Cliquez pour sélectionner ou glissez-déposez un fichier'}
      </p>
      <p className="text-xs text-slate-500 mt-1">
        {accept === '.pdf' ? 'PDF uniquement' : `Types autorisés: ${accept}`}
      </p>
    </div>
  );
};
