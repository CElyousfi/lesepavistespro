import { useState } from 'react';
import { 
  Bookmark, PaperPlaneTilt, CheckCircle, Users as UsersIcon, Handshake, Trophy,
  ArrowUpRight
} from '@phosphor-icons/react';
import clsx from 'clsx';

const STAGES = [
  { 
    id: 'bookmarked', 
    label: 'Sauvegardé', 
    icon: Bookmark
  },
  { 
    id: 'applying', 
    label: 'En cours', 
    icon: PaperPlaneTilt
  },
  { 
    id: 'applied', 
    label: 'Postulé', 
    icon: CheckCircle
  },
  { 
    id: 'interviewing', 
    label: 'Entretien', 
    icon: UsersIcon
  },
  { 
    id: 'negotiating', 
    label: 'Négociation', 
    icon: Handshake
  },
  { 
    id: 'accepted', 
    label: 'Accepté', 
    icon: Trophy
  },
];

export const KPIFilter = ({ 
  counts = {}, 
  activeFilter = 'all', 
  onFilterChange,
  className = ''
}) => {
  const handleCardClick = (stageId) => {
    if (onFilterChange) {
      onFilterChange(stageId === activeFilter ? 'all' : stageId);
    }
  };

  return (
    <div className={clsx('flex gap-8 overflow-x-auto pb-4', className)}>
      {STAGES.map((stage) => {
        const StageIcon = stage.icon;
        const count = counts[stage.id] || 0;
        const isActive = activeFilter === stage.id;

        return (
          <div
            key={stage.id}
            onClick={() => handleCardClick(stage.id)}
            className={clsx(
              'relative flex-shrink-0 w-36 h-36 rounded-xl border cursor-pointer transition-all duration-200',
              'hover:shadow-lg active:scale-95 flex flex-col items-center justify-center',
              isActive 
                ? 'bg-[#E6F2F1] border-[#005149] shadow-md' 
                : 'bg-white border-gray-200 hover:bg-gray-50 hover:border-gray-300'
            )}
          >
            {/* Icon */}
            <div className="mb-2">
              <StageIcon 
                size={24} 
                weight="regular" 
                className={clsx(
                  'transition-colors duration-200',
                  isActive ? 'text-[#005149]' : 'text-gray-500'
                )}
              />
            </div>

            {/* Count */}
            <div className="mb-2">
              <span className={clsx(
                'text-2xl font-bold',
                isActive ? 'text-[#005149]' : 'text-gray-600'
              )}>
                {count}
              </span>
            </div>

            {/* Label */}
            <div>
              <span className={clsx(
                'text-xs font-medium text-center leading-tight',
                isActive ? 'text-[#005149]' : 'text-gray-600'
              )}>
                {stage.label}
              </span>
            </div>

            {/* Arrow Indicator */}
            <div className={clsx(
              'absolute bottom-2 right-2 transition-all duration-200',
              isActive ? 'opacity-100' : 'opacity-0'
            )}>
              <ArrowUpRight 
                size={12} 
                weight="bold" 
                className="text-[#005149]"
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default KPIFilter;
