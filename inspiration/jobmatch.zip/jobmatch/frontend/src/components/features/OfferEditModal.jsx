import { useState } from 'react';
import { X, FloppyDisk, Warning, CircleNotch } from '@phosphor-icons/react';
import { Button } from '../ui/Button';
import { showToast } from '../ui/Toast';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000';

export const OfferEditModal = ({ offer, onClose, onSuccess }) => {
  const [rawText, setRawText] = useState(offer.raw_text || '');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!rawText.trim()) {
      showToast('Le texte de l\'offre ne peut pas être vide', 'error');
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await fetch(`${API_BASE}/api/offers/${offer.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ raw_text: rawText }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Erreur lors de la modification');
      }

      const data = await response.json();
      showToast('Offre modifiée avec succès', 'success');
      onSuccess?.(data);
      onClose();
    } catch (error) {
      console.error('Error updating offer:', error);
      showToast(error.message || 'Erreur lors de la modification', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-300">
        {/* Header */}
        <div className="bg-gradient-to-r from-teal-600 to-teal-500 text-white p-6">
          <div className="flex items-start justify-between">
            <div>
              <h2 className="text-2xl font-bold">Modifier l'offre</h2>
              <p className="text-teal-100 mt-1">
                Modifiez le texte de l'offre et l'IA réanalysera automatiquement
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-white/80 hover:text-white transition-colors p-2 hover:bg-white/10 rounded-lg"
            >
              <X className="h-6 w-6" weight="bold" />
            </button>
          </div>
        </div>

        {/* Warning Banner */}
        <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 m-6 mb-0">
          <div className="flex items-start gap-3">
            <Warning className="h-5 w-5 text-yellow-600 flex-shrink-0 mt-0.5" weight="fill" />
            <div className="text-sm text-yellow-800">
              <p className="font-semibold">Attention</p>
              <p className="mt-1">
                La modification de l'offre déclenchera une nouvelle analyse IA. 
                Les correspondances existantes seront conservées mais pourraient ne plus être pertinentes.
              </p>
            </div>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-slate-700 mb-2">
                Texte de l'offre d'emploi
              </label>
              <textarea
                value={rawText}
                onChange={(e) => setRawText(e.target.value)}
                placeholder="Collez ici le texte complet de l'offre d'emploi..."
                className="w-full h-96 px-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent resize-none font-mono text-sm"
                disabled={isSubmitting}
              />
              <p className="text-xs text-slate-500 mt-2">
                {rawText.length} caractères
              </p>
            </div>
          </div>
        </form>

        {/* Footer */}
        <div className="border-t border-slate-200 p-6 bg-slate-50">
          <div className="flex items-center justify-end gap-3">
            <Button
              type="button"
              variant="secondary"
              onClick={onClose}
              disabled={isSubmitting}
            >
              Annuler
            </Button>
            <Button
              type="submit"
              onClick={handleSubmit}
              disabled={isSubmitting || !rawText.trim()}
            >
              {isSubmitting ? (
                <>
                  <CircleNotch className="h-4 w-4 animate-spin" weight="bold" />
                  Modification en cours...
                </>
              ) : (
                <>
                  <FloppyDisk className="h-5 w-5" weight="bold" />
                  Enregistrer les modifications
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
