import { useState } from 'react';
import { Upload, Loader2, CheckCircle, FileText, Sparkles } from 'lucide-react';
import { Card } from '../ui/Card';
import { Button } from '../ui/Button';
import { Chip } from '../ui/Chip';
import { Badge } from '../ui/Badge';
import { Dropzone } from '../ui/Dropzone';
import { uploadCV, uploadCandidateFile } from '../../lib/api';
import { showToast } from '../ui/Toast';

export const ResumeUpload = ({ candidateId, onSuccess }) => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadedData, setUploadedData] = useState(null);
  const [kind, setKind] = useState('resume');
  
  const kindToAccept = {
    resume: '.pdf',
    cover_letter: '.pdf,.doc,.docx,.txt',
    portfolio: '.pdf,.zip,.ppt,.pptx',
    certificate: '.pdf,.png,.jpg,.jpeg',
    id: '.pdf,.png,.jpg,.jpeg',
    contract: '.pdf',
    document: '.pdf,.doc,.docx,.txt,.png,.jpg,.jpeg,.zip'
  };
  
  const handleFileSelect = (file) => {
    setSelectedFile(file);
    setUploadedData(null);
  };
  
  const handleUpload = async () => {
    if (!selectedFile) return;
    
    setIsUploading(true);
    
    try {
      const result = await uploadCandidateFile(candidateId, selectedFile, kind);
      if (kind === 'resume') {
        showToast('CV téléversé et analysé avec succès!', 'success');
      } else {
        showToast('Document ajouté avec succès', 'success');
      }
      setUploadedData(result);
      setSelectedFile(null);
      onSuccess?.(result);
    } catch (error) {
      console.error('Error uploading CV:', error);
      showToast(
        error.response?.data?.detail || 'Erreur lors du téléversement',
        'error'
      );
    } finally {
      setIsUploading(false);
    }
  };
  
  return (
    <Card className="bg-gradient-to-br from-white to-slate-50 border-2 border-teal-200">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 bg-teal-100 rounded-lg flex items-center justify-center">
          <FileText className="h-5 w-5 text-teal-600" />
        </div>
        <div>
          <h4 className="font-bold text-slate-900">Ajouter un document</h4>
          <p className="text-xs text-slate-600">CV, lettre de motivation, certificats, etc.</p>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <label className="text-sm text-slate-700">Type de document</label>
          <select
            value={kind}
            onChange={(e) => setKind(e.target.value)}
            className="border border-slate-300 rounded-md px-2 py-1 text-sm"
          >
            <option value="resume">CV</option>
            <option value="cover_letter">Lettre de motivation</option>
            <option value="portfolio">Portfolio</option>
            <option value="certificate">Certificat</option>
            <option value="id">Pièce d'identité</option>
            <option value="contract">Contrat</option>
            <option value="document">Autre document</option>
          </select>
        </div>

        <Dropzone onFileSelect={handleFileSelect} accept={kindToAccept[kind] || '.pdf'} />
        
        {selectedFile && !uploadedData && (
          <div className="flex items-center justify-between p-4 bg-white rounded-lg border-2 border-teal-300 shadow-sm">
            <div className="flex items-center gap-3 text-sm text-slate-700 flex-1 min-w-0">
              <Upload className="h-5 w-5 text-teal-600 flex-shrink-0" />
              <span className="font-medium truncate">{selectedFile.name}</span>
              <Badge variant="default" className="text-xs">
                {(selectedFile.size / 1024).toFixed(0)} KB
              </Badge>
            </div>
            <Button
              size="sm"
              onClick={handleUpload}
              disabled={isUploading}
              className="ml-3 flex-shrink-0"
            >
              {isUploading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Analyse...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  Analyser
                </>
              )}
            </Button>
          </div>
        )}
        
        {uploadedData && (
          <div className="p-5 bg-gradient-to-br from-green-50 to-teal-50 border-2 border-green-300 rounded-xl space-y-4">
            <div className="flex items-center gap-3 text-green-800">
              <div className="w-10 h-10 bg-green-200 rounded-full flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-green-700" />
              </div>
              <div>
                <p className="font-bold">Analysé avec succès</p>
                <p className="text-sm text-green-700">{uploadedData.file_name}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-white/60 rounded-lg p-3 border border-green-200">
                <p className="text-xs text-slate-600 font-medium mb-1">Texte extrait</p>
                <p className="text-lg font-bold text-slate-900">
                  {uploadedData.extracted_text_length}
                  <span className="text-xs font-normal text-slate-500 ml-1">caractères</span>
                </p>
              </div>
              <div className="bg-white/60 rounded-lg p-3 border border-green-200">
                <p className="text-xs text-slate-600 font-medium mb-1">Expérience</p>
                <p className="text-lg font-bold text-slate-900">
                  {uploadedData.years_experience}
                  <span className="text-xs font-normal text-slate-500 ml-1">ans</span>
                </p>
              </div>
            </div>
            
            <div>
              <p className="text-sm font-bold text-slate-700 mb-3 flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-teal-600" />
                Compétences détectées ({uploadedData.skills?.length || 0})
              </p>
              <div className="flex flex-wrap gap-2">
                {uploadedData.skills?.map((skill, idx) => (
                  <Chip key={idx} variant="teal" className="text-xs">
                    {skill}
                  </Chip>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
};
