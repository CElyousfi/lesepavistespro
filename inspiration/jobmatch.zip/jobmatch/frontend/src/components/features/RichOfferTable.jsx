import { useState } from 'react';
import { 
  Users, 
  MapPin, 
  Calendar, 
  CurrencyDollar, 
  Briefcase,
  CaretUp,
  CaretDown,
  FunnelSimple,
  Eye,
  CheckCircle,
  Buildings,
  ArrowsLeftRight,
  House,
  Lightning
} from '@phosphor-icons/react';
import { Badge } from '../ui/Badge';
import { formatDate } from '../../lib/format';

const REMOTE_POLICY_OPTIONS = [
  { value: 'on_site', label: 'Sur site', color: 'slate', Icon: Buildings },
  { value: 'hybrid', label: 'Hybride', color: 'blue', Icon: ArrowsLeftRight },
  { value: 'full_remote', label: 'Full Remote', color: 'green', Icon: House },
  { value: 'flexible', label: 'Flexible', color: 'purple', Icon: Lightning },
];

export const RichOfferTable = ({ offers, onSelectOffer, onUpdateOffer }) => {
  const [sortBy, setSortBy] = useState('created_at');
  const [sortOrder, setSortOrder] = useState('desc');
  const [filterStatus, setFilterStatus] = useState('all');

  const handleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  const handleRemotePolicyChange = (e, offerId) => {
    e.stopPropagation();
    onUpdateOffer?.(offerId, { remote_policy: e.target.value });
  };

  // Filter and sort offers
  let processedOffers = offers || [];
  
  if (filterStatus !== 'all') {
    processedOffers = processedOffers.filter(o => o.remote_policy === filterStatus);
  }

  processedOffers = [...processedOffers].sort((a, b) => {
    let aVal = a[sortBy];
    let bVal = b[sortBy];
    
    if (sortBy === 'created_at') {
      aVal = new Date(aVal);
      bVal = new Date(bVal);
    }
    
    if (sortOrder === 'asc') {
      return aVal > bVal ? 1 : -1;
    }
    return aVal < bVal ? 1 : -1;
  });

  const SortIcon = ({ field }) => {
    if (sortBy !== field) return null;
    return sortOrder === 'asc' ? 
      <CaretUp className="h-4 w-4" weight="fill" /> : 
      <CaretDown className="h-4 w-4" weight="fill" />;
  };

  const MatchedCandidates = ({ count, total }) => {
    const percentage = total > 0 ? Math.round((count / total) * 100) : 0;
    return (
      <div className="flex items-center gap-2">
        <div className="flex items-center gap-1.5">
          <Users className="h-4 w-4 text-teal-600" weight="fill" />
          <span className="font-semibold text-slate-900">{count}</span>
          <span className="text-slate-500 text-sm">/ {total}</span>
        </div>
        {count > 0 && (
          <div className="flex items-center gap-1 px-2 py-0.5 bg-teal-50 rounded-full">
            <CheckCircle className="h-3 w-3 text-teal-600" weight="fill" />
            <span className="text-xs font-medium text-teal-700">{percentage}%</span>
          </div>
        )}
      </div>
    );
  };

  // Remote policy summary
  const remotePolicyCounts = REMOTE_POLICY_OPTIONS.map(policy => ({
    ...policy,
    count: offers?.filter(o => o.remote_policy === policy.value).length || 0
  }));

  return (
    <div className="space-y-4">
      {/* Remote Policy Summary Bar */}
      <div className="flex items-center gap-2 p-4 bg-slate-50 rounded-lg border border-slate-200 overflow-x-auto">
        <button
          onClick={() => setFilterStatus('all')}
          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
            filterStatus === 'all'
              ? 'bg-teal-600 text-white'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          Tous ({offers?.length || 0})
        </button>
        {remotePolicyCounts.map(policy => (
          <button
            key={policy.value}
            onClick={() => setFilterStatus(policy.value)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors whitespace-nowrap ${
              filterStatus === policy.value
                ? 'bg-teal-600 text-white'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {policy.icon} {policy.label} ({policy.count})
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-4 py-3 text-left">
                  <button
                    onClick={() => handleSort('title')}
                    className="flex items-center gap-2 text-xs font-semibold text-slate-700 uppercase tracking-wider hover:text-teal-600"
                  >
                    Poste
                    <SortIcon field="title" />
                  </button>
                </th>
                <th className="px-4 py-3 text-left">
                  <button
                    onClick={() => handleSort('company')}
                    className="flex items-center gap-2 text-xs font-semibold text-slate-700 uppercase tracking-wider hover:text-teal-600"
                  >
                    Entreprise
                    <SortIcon field="company" />
                  </button>
                </th>
                <th className="px-4 py-3 text-left">
                  <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                    Localisation
                  </span>
                </th>
                <th className="px-4 py-3 text-left">
                  <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                    Télétravail
                  </span>
                </th>
                <th className="px-4 py-3 text-left">
                  <button
                    onClick={() => handleSort('created_at')}
                    className="flex items-center gap-2 text-xs font-semibold text-slate-700 uppercase tracking-wider hover:text-teal-600"
                  >
                    Date ajoutée
                    <SortIcon field="created_at" />
                  </button>
                </th>
                <th className="px-4 py-3 text-left">
                  <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                    Candidats Matchés
                  </span>
                </th>
                <th className="px-4 py-3 text-left">
                  <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                    Actions
                  </span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {processedOffers.length === 0 ? (
                <tr>
                  <td colSpan="7" className="px-4 py-12 text-center text-slate-500">
                    <Briefcase className="h-12 w-12 mx-auto mb-3 text-slate-300" />
                    <p className="font-medium">Aucune offre trouvée</p>
                    <p className="text-sm mt-1">
                      {filterStatus !== 'all' 
                        ? 'Aucune offre avec ce statut' 
                        : 'Commencez par ajouter une nouvelle offre'}
                    </p>
                  </td>
                </tr>
              ) : (
                processedOffers.map((offer) => (
                  <tr
                    key={offer.id}
                    onClick={() => onSelectOffer(offer.id)}
                    className="hover:bg-slate-50 cursor-pointer transition-colors"
                  >
                    <td className="px-4 py-4">
                      <div className="font-medium text-slate-900">{offer.title || 'Sans titre'}</div>
                      {offer.experience_level && (
                        <div className="text-xs text-slate-500 mt-1">{offer.experience_level}</div>
                      )}
                    </td>
                    <td className="px-4 py-4">
                      <div className="text-sm text-slate-700">{offer.company || '-'}</div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-1.5 text-sm text-slate-600">
                        <MapPin className="h-4 w-4 text-slate-400" />
                        {offer.location || '-'}
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-2">
                        {(() => {
                          const policy = REMOTE_POLICY_OPTIONS.find(p => p.value === (offer.remote_policy || 'on_site'));
                          const PolicyIcon = policy?.Icon || Buildings;
                          return <PolicyIcon size={16} className="text-slate-400" />;
                        })()}
                        <select
                          value={offer.remote_policy || 'on_site'}
                          onChange={(e) => handleRemotePolicyChange(e, offer.id)}
                          onClick={(e) => e.stopPropagation()}
                          className="text-sm border border-slate-200 rounded-lg px-3 py-1.5 focus:outline-none focus:ring-2 focus:ring-teal-500 cursor-pointer hover:border-teal-400 transition-colors"
                        >
                          {REMOTE_POLICY_OPTIONS.map(policy => (
                            <option key={policy.value} value={policy.value}>
                              {policy.label}
                            </option>
                          ))}
                        </select>
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-1.5 text-sm text-slate-600">
                        <Calendar className="h-4 w-4 text-slate-400" />
                        {formatDate(offer.created_at)}
                      </div>
                    </td>
                    <td className="px-4 py-4">
                      <MatchedCandidates 
                        count={offer.matched_candidates_count || 0} 
                        total={offer.total_candidates || 0} 
                      />
                    </td>
                    <td className="px-4 py-4">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          onSelectOffer(offer.id);
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-teal-600 hover:bg-teal-50 rounded-lg transition-colors"
                      >
                        <Eye className="h-4 w-4" />
                        Voir
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Summary Footer */}
      {processedOffers.length > 0 && (
        <div className="flex items-center justify-between px-4 py-3 bg-slate-50 rounded-lg border border-slate-200 text-sm text-slate-600">
          <div>
            Affichage de <span className="font-semibold text-slate-900">{processedOffers.length}</span> offre{processedOffers.length > 1 ? 's' : ''}
            {filterStatus !== 'all' && ` • Filtre: ${REMOTE_POLICY_OPTIONS.find(p => p.value === filterStatus)?.label}`}
          </div>
          <div className="flex items-center gap-2">
            <FunnelSimple className="h-4 w-4" />
            Trié par: <span className="font-semibold text-slate-900">
              {sortBy === 'created_at' ? 'Date' : sortBy === 'title' ? 'Poste' : 'Entreprise'}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
