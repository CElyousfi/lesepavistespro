import { useState, useMemo } from 'react';
import { 
  User, 
  MapPin, 
  Briefcase, 
  Calendar, 
  Eye, 
  Users,
  Trophy,
  Envelope,
  Phone,
  Code
} from '@phosphor-icons/react';
import { formatDate } from '../../lib/format';
import { Chip } from '../ui/Chip';

const MatchedOffers = ({ count, total }) => {
  const percentage = total > 0 ? Math.round((count / total) * 100) : 0;
  
  return (
    <div className="flex items-center gap-2">
      <div className="flex items-center gap-1">
        <span className="font-semibold text-[#005149]">{count}</span>
        <span className="text-slate-500">/ {total}</span>
      </div>
      {count > 0 && (
        <div className="text-xs text-[#005149] font-medium">
          {percentage}%
        </div>
      )}
    </div>
  );
};

export const RichCandidateTable = ({ candidates, onSelectCandidate }) => {
  const [sortBy, setSortBy] = useState('date');
  const [sortOrder, setSortOrder] = useState('desc');
  const [filterExperience, setFilterExperience] = useState('all');

  // Experience filter options
  const EXPERIENCE_FILTERS = [
    { value: 'all', label: 'Tous', min: 0, max: 999 },
    { value: 'junior', label: 'Junior (0-2 ans)', min: 0, max: 2 },
    { value: 'mid', label: 'Intermédiaire (3-5 ans)', min: 3, max: 5 },
    { value: 'senior', label: 'Senior (6-10 ans)', min: 6, max: 10 },
    { value: 'expert', label: 'Expert (10+ ans)', min: 10, max: 999 },
  ];

  // Filter and sort candidates
  const filteredAndSortedCandidates = useMemo(() => {
    let filtered = [...candidates];

    // Apply experience filter
    if (filterExperience !== 'all') {
      const filter = EXPERIENCE_FILTERS.find(f => f.value === filterExperience);
      filtered = filtered.filter(c => 
        c.years_experience >= filter.min && c.years_experience <= filter.max
      );
    }

    // Sort
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'name':
          comparison = `${a.first_name} ${a.last_name}`.localeCompare(`${b.first_name} ${b.last_name}`);
          break;
        case 'experience':
          comparison = (a.years_experience || 0) - (b.years_experience || 0);
          break;
        case 'skills':
          comparison = (a.skills_count || 0) - (b.skills_count || 0);
          break;
        case 'matches':
          comparison = (a.matched_offers_count || 0) - (b.matched_offers_count || 0);
          break;
        case 'date':
        default:
          comparison = new Date(a.created_at) - new Date(b.created_at);
          break;
      }
      
      return sortOrder === 'asc' ? comparison : -comparison;
    });

    return filtered;
  }, [candidates, sortBy, sortOrder, filterExperience]);

  // Summary stats
  const stats = useMemo(() => {
    const byExperience = EXPERIENCE_FILTERS.slice(1).map(filter => ({
      ...filter,
      count: candidates.filter(c => 
        c.years_experience >= filter.min && c.years_experience <= filter.max
      ).length
    }));

    return { byExperience };
  }, [candidates]);

  const handleSort = (column) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('desc');
    }
  };

  if (candidates.length === 0) {
    return (
      <div className="text-center py-16 bg-white rounded-xl border border-slate-200">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-100 mb-4">
          <Users className="h-10 w-10 text-slate-400" />
        </div>
        <p className="text-slate-700 font-medium text-lg">Aucun candidat pour le moment</p>
        <p className="text-sm text-slate-500 mt-2">Créez votre premier candidat en cliquant sur le bouton ci-dessus</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Summary Bar */}
      <div className="bg-white rounded-xl p-4 border border-slate-200">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-[#005149]" weight="fill" />
              <span className="text-sm font-medium text-slate-700">
                {filteredAndSortedCandidates.length} candidat{filteredAndSortedCandidates.length > 1 ? 's' : ''}
              </span>
            </div>
            
            {stats.byExperience.map(exp => (
              <button
                key={exp.value}
                onClick={() => setFilterExperience(filterExperience === exp.value ? 'all' : exp.value)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  filterExperience === exp.value
                    ? 'bg-[#005149] text-white shadow-sm'
                    : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                }`}
              >
                <Briefcase className="h-4 w-4" />
                <span>{exp.label.split(' ')[0]}</span>
                <span className={`px-1.5 py-0.5 rounded text-xs ${
                  filterExperience === exp.value ? 'bg-[#00413A]' : 'bg-slate-100'
                }`}>
                  {exp.count}
                </span>
              </button>
            ))}
          </div>

          {filterExperience !== 'all' && (
            <button
              onClick={() => setFilterExperience('all')}
              className="text-sm text-[#005149] hover:text-[#00413A] font-medium"
            >
              Réinitialiser les filtres
            </button>
          )}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
        <table className="w-full">
          <thead className="bg-slate-50 border-b border-slate-200">
            <tr>
              <th 
                className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider cursor-pointer hover:bg-slate-100"
                onClick={() => handleSort('name')}
              >
                <div className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Candidat
                  {sortBy === 'name' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                </div>
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">
                <div className="flex items-center gap-2">
                  <Briefcase className="h-4 w-4" />
                  Poste actuel
                </div>
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  Localisation
                </div>
              </th>
              <th 
                className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider cursor-pointer hover:bg-slate-100"
                onClick={() => handleSort('experience')}
              >
                <div className="flex items-center gap-2">
                  <Trophy className="h-4 w-4" />
                  Expérience
                  {sortBy === 'experience' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                </div>
              </th>
              <th 
                className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider cursor-pointer hover:bg-slate-100"
                onClick={() => handleSort('skills')}
              >
                <div className="flex items-center gap-2">
                  <Code className="h-4 w-4" />
                  Compétences
                  {sortBy === 'skills' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                </div>
              </th>
              <th 
                className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider cursor-pointer hover:bg-slate-100"
                onClick={() => handleSort('matches')}
              >
                <div className="flex items-center gap-2">
                  <Trophy className="h-4 w-4" />
                  Offres matchées
                  {sortBy === 'matches' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                </div>
              </th>
              <th 
                className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider cursor-pointer hover:bg-slate-100"
                onClick={() => handleSort('date')}
              >
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Date ajoutée
                  {sortBy === 'date' && <span>{sortOrder === 'asc' ? '↑' : '↓'}</span>}
                </div>
              </th>
              <th className="px-4 py-3 text-left text-xs font-semibold text-slate-700 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {filteredAndSortedCandidates.map((candidate) => (
              <tr
                key={candidate.id}
                onClick={() => onSelectCandidate(candidate.id)}
                className="hover:bg-slate-50 cursor-pointer transition-colors"
              >
                <td className="px-4 py-4">
                  <div>
                    <div className="font-medium text-slate-900">
                      {candidate.first_name} {candidate.last_name}
                    </div>
                    {(candidate.email || candidate.phone) && (
                      <div className="flex items-center gap-3 mt-1">
                        {candidate.email && (
                          <div className="flex items-center gap-1 text-xs text-slate-500">
                            <Envelope className="h-3 w-3" />
                            <a 
                              href={`mailto:${candidate.email}`} 
                              className="text-[#005149] hover:underline"
                              onClick={(e) => e.stopPropagation()}
                            >
                              {candidate.email}
                            </a>
                          </div>
                        )}
                        {candidate.phone && (
                          <div className="flex items-center gap-1 text-xs text-slate-500">
                            <Phone className="h-3 w-3" />
                            <a 
                              href={`tel:${candidate.phone}`} 
                              className="text-[#005149] hover:underline"
                              onClick={(e) => e.stopPropagation()}
                            >
                              {candidate.phone}
                            </a>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="text-sm text-slate-700">
                    {candidate.current_title || '-'}
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-1.5 text-sm text-slate-600">
                    {candidate.location ? (
                      <>
                        <MapPin className="h-4 w-4 text-slate-400" />
                        {candidate.location}
                      </>
                    ) : (
                      '-'
                    )}
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="text-sm font-medium text-slate-900">
                    {candidate.years_experience > 0 ? `${candidate.years_experience} an${candidate.years_experience > 1 ? 's' : ''}` : '-'}
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="flex flex-wrap gap-1.5">
                    {candidate.top_skills && candidate.top_skills.length > 0 ? (
                      <>
                        {candidate.top_skills.slice(0, 3).map((skill, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-1 bg-[#E6F2F1] text-[#005149] text-xs font-medium rounded-md border border-[#CCE5E3]"
                          >
                            {skill}
                          </span>
                        ))}
                        {candidate.skills_count > 3 && (
                          <span className="px-2 py-1 text-xs text-slate-600 font-medium">
                            +{candidate.skills_count - 3}
                          </span>
                        )}
                      </>
                    ) : (
                      <span className="text-sm text-slate-400">-</span>
                    )}
                  </div>
                </td>
                <td className="px-4 py-4">
                  <MatchedOffers 
                    count={candidate.matched_offers_count || 0} 
                    total={candidate.total_offers || 0} 
                  />
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center gap-1.5 text-sm text-slate-600">
                    <Calendar className="h-4 w-4 text-slate-400" />
                    {formatDate(candidate.created_at)}
                  </div>
                </td>
                <td className="px-4 py-4">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectCandidate(candidate.id);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 text-sm font-medium text-[#005149] hover:bg-[#E6F2F1] rounded-lg transition-colors"
                  >
                    <Eye className="h-4 w-4" />
                    Voir
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Results count */}
      <div className="text-sm text-slate-500 text-center">
        Affichage de {filteredAndSortedCandidates.length} candidat{filteredAndSortedCandidates.length > 1 ? 's' : ''}
        {filterExperience !== 'all' && ` • Filtre: ${EXPERIENCE_FILTERS.find(f => f.value === filterExperience)?.label}`}
        {' • '}
        <button
          onClick={() => setSortBy('date')}
          className="text-indigo-600 hover:text-indigo-700 font-medium"
        >
          Trier par: Date
        </button>
      </div>
    </div>
  );
};
