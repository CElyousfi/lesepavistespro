import { useState, useMemo } from 'react';
import { 
  Users, 
  Briefcase, 
  FunnelSimple,
  SortAscending,
  SortDescending,
  MagnifyingGlass,
  FileText,
  Star,
  Calendar,
  User,
  Code
} from '@phosphor-icons/react';
import { CandidateCard } from './CandidateCard';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

export const CandidateCardGrid = ({ candidates, onSelectCandidate, onUploadCV }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('date');
  const [sortOrder, setSortOrder] = useState('desc');
  const [filterExperience, setFilterExperience] = useState('all');

  // Add safety check for candidates data
  if (!candidates || !Array.isArray(candidates)) {
    return (
      <div className="text-center py-16 bg-white rounded-xl border border-slate-200">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-100 mb-4">
          <Users className="h-10 w-10 text-slate-400" />
        </div>
        <p className="text-slate-700 font-medium text-lg">Chargement des candidats...</p>
        <p className="text-sm text-slate-500 mt-2">Veuillez patienter</p>
      </div>
    );
  }

  // Experience filter options
  const EXPERIENCE_FILTERS = [
    { value: 'all', label: 'Tous', min: 0, max: 999 },
    { value: 'junior', label: 'Junior (0-2 ans)', min: 0, max: 2 },
    { value: 'mid', label: 'Intermédiaire (3-5 ans)', min: 3, max: 5 },
    { value: 'senior', label: 'Senior (6-10 ans)', min: 6, max: 10 },
    { value: 'expert', label: 'Expert (10+ ans)', min: 10, max: 999 },
  ];

  // Filter and sort candidates
  const filteredAndSortedCandidates = useMemo(() => {
    let filtered = [...candidates];

    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(candidate => {
        const fullName = `${candidate.first_name || ''} ${candidate.last_name || ''}`.toLowerCase();
        const title = (candidate.current_title || '').toLowerCase();
        const location = (candidate.location || '').toLowerCase();
        const skills = (candidate.top_skills || []).join(' ').toLowerCase();
        
        return fullName.includes(term) || 
               title.includes(term) || 
               location.includes(term) || 
               skills.includes(term);
      });
    }

    // Apply experience filter
    if (filterExperience !== 'all') {
      const filter = EXPERIENCE_FILTERS.find(f => f.value === filterExperience);
      filtered = filtered.filter(c => 
        (c.years_experience || 0) >= filter.min && (c.years_experience || 0) <= filter.max
      );
    }

    // Sort
    filtered.sort((a, b) => {
      let comparison = 0;
      
      switch (sortBy) {
        case 'name':
          const nameA = `${a.first_name || ''} ${a.last_name || ''}`.toLowerCase();
          const nameB = `${b.first_name || ''} ${b.last_name || ''}`.toLowerCase();
          comparison = nameA.localeCompare(nameB);
          break;
        case 'experience':
          comparison = (a.years_experience || 0) - (b.years_experience || 0);
          break;
        case 'skills':
          comparison = (a.skills_count || 0) - (b.skills_count || 0);
          break;
        case 'matches':
          comparison = (a.matched_offers_count || 0) - (b.matched_offers_count || 0);
          break;
        case 'date':
        default:
          comparison = new Date(a.created_at) - new Date(b.created_at);
          break;
      }
      
      return sortOrder === 'asc' ? comparison : -comparison;
    });

    return filtered;
  }, [candidates, searchTerm, sortBy, sortOrder, filterExperience]);

  // Summary stats
  const stats = useMemo(() => {
    const byExperience = EXPERIENCE_FILTERS.slice(1).map(filter => ({
      ...filter,
      count: candidates.filter(c => 
        (c.years_experience || 0) >= filter.min && (c.years_experience || 0) <= filter.max
      ).length
    }));

    const withProfiles = candidates.filter(c => c.profile_count > 0).length;
    const totalMatches = candidates.reduce((sum, c) => sum + (c.matched_offers_count || 0), 0);

    return { byExperience, withProfiles, totalMatches };
  }, [candidates]);

  const handleSort = (column) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(column);
      setSortOrder('desc');
    }
  };

  if (candidates.length === 0) {
    return (
      <div className="text-center py-16 bg-white rounded-xl border border-slate-200">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-100 mb-4">
          <Users className="h-10 w-10 text-slate-400" />
        </div>
        <p className="text-slate-700 font-medium text-lg">Aucun candidat pour le moment</p>
        <p className="text-sm text-slate-500 mt-2">Créez votre premier candidat en cliquant sur le bouton ci-dessus</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="bg-white rounded-xl p-4 border border-slate-200">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="flex-1">
            <div className="relative">
              <MagnifyingGlass className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
              <Input
                type="text"
                placeholder="Rechercher un candidat..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Sort Options */}
          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-600 font-medium">Trier par:</span>
            <div className="flex gap-1">
              {[
                { key: 'date', label: 'Date', icon: Calendar },
                { key: 'name', label: 'Nom', icon: User },
                { key: 'experience', label: 'Expérience', icon: Briefcase },
                { key: 'skills', label: 'Compétences', icon: Code },
                { key: 'matches', label: 'Matches', icon: Star }
              ].map(option => {
                const IconComponent = option.icon;
                return (
                <button
                  key={option.key}
                  onClick={() => handleSort(option.key)}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    sortBy === option.key
                      ? 'bg-[#005149] text-white shadow-sm'
                      : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  <IconComponent className="h-4 w-4" />
                  <span>{option.label}</span>
                  {sortBy === option.key && (
                    sortOrder === 'asc' ? <SortAscending className="h-3 w-3" /> : <SortDescending className="h-3 w-3" />
                  )}
                </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Experience Filters */}
        <div className="mt-4 pt-4 border-t border-slate-100">
          <div className="flex items-center gap-4 flex-wrap">
            <span className="text-sm text-slate-600 font-medium">Filtrer par expérience:</span>
            <div className="flex gap-2">
              {EXPERIENCE_FILTERS.map(filter => (
                <button
                  key={filter.value}
                  onClick={() => setFilterExperience(filterExperience === filter.value ? 'all' : filter.value)}
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    filterExperience === filter.value
                      ? 'bg-[#005149] text-white shadow-sm'
                      : 'bg-white text-slate-700 hover:bg-slate-50 border border-slate-200'
                  }`}
                >
                  <Briefcase className="h-4 w-4" />
                  <span>{filter.label.split(' ')[0]}</span>
                  <span className={`px-1.5 py-0.5 rounded text-xs ${
                    filterExperience === filter.value ? 'bg-[#00413A]' : 'bg-slate-100'
                  }`}>
                    {filter.count}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="bg-white rounded-xl p-4 border border-slate-200">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-[#005149]" weight="fill" />
              <span className="text-sm font-medium text-slate-700">
                {filteredAndSortedCandidates.length} candidat{filteredAndSortedCandidates.length > 1 ? 's' : ''}
              </span>
            </div>
            
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-[#005149]" weight="fill" />
              <span className="text-sm font-medium text-slate-700">
                {stats.withProfiles} avec CV
              </span>
            </div>

            <div className="flex items-center gap-2">
              <Star className="h-5 w-5 text-[#005149]" weight="fill" />
              <span className="text-sm font-medium text-slate-700">
                {stats.totalMatches} match{stats.totalMatches > 1 ? 'es' : ''} total
              </span>
            </div>
          </div>

          {(searchTerm || filterExperience !== 'all') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setFilterExperience('all');
              }}
              className="text-sm text-[#005149] hover:text-[#00413A] font-medium"
            >
              Réinitialiser les filtres
            </button>
          )}
        </div>
      </div>

      {/* Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredAndSortedCandidates.map((candidate) => (
          <CandidateCard
            key={candidate.id}
            candidate={candidate}
            onSelectCandidate={onSelectCandidate}
            onUploadCV={onUploadCV}
          />
        ))}
      </div>

      {/* Results count */}
      <div className="text-sm text-slate-500 text-center">
        Affichage de {filteredAndSortedCandidates.length} candidat{filteredAndSortedCandidates.length > 1 ? 's' : ''}
        {filterExperience !== 'all' && ` • Filtre: ${EXPERIENCE_FILTERS.find(f => f.value === filterExperience)?.label}`}
        {searchTerm && ` • Recherche: "${searchTerm}"`}
      </div>
    </div>
  );
};
