import { X, FilePdf, Calendar, User, Briefcase, MapPin, Envelope, Phone, Certificate, GraduationCap, CheckCircle, Trash, Buildings, Star, ArrowRight, Bookmark, PaperPlaneTilt, UsersThree, Handshake, Trophy, Wrench, Lightbulb, Desktop } from '@phosphor-icons/react';
import { useState } from 'react';
import useSWR from 'swr';
import { useCandidate } from '../../lib/useApi';
import { listApplications } from '../../lib/api';
import { fmtDate } from '../../lib/format';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000';

export const CandidateDrawer = ({ candidateId, onClose, onDelete }) => {
  const { candidate, isLoading, isError } = useCandidate(candidateId);
  const [activeTab, setActiveTab] = useState('details'); // 'details' or 'pdf'
  const [selectedFileId, setSelectedFileId] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const navigate = useNavigate();
  
  // Fetch applications for this candidate
  const { data: applicationsData } = useSWR(
    candidateId ? `candidate-applications-${candidateId}` : null,
    () => candidateId ? listApplications(null, candidateId) : null,
    { refreshInterval: 5000 }
  );
  const applications = applicationsData?.applications || [];
  
  const handleDelete = async () => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer ce candidat ? Tous les CV et données seront supprimés. Cette action est irréversible.')) {
      return;
    }
    
    setIsDeleting(true);
    try {
      await axios.delete(`${API_BASE}/api/candidates/${candidateId}`);
      alert('Candidat supprimé avec succès');
      onDelete?.();
      onClose();
    } catch (error) {
      console.error('Error deleting candidate:', error);
      alert(error.response?.data?.detail || 'Erreur lors de la suppression');
    } finally {
      setIsDeleting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
        <div className="bg-white p-8 shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
          <div className="flex items-center justify-center py-16">
            <div className="animate-spin h-8 w-8 border-4 border-teal-600 border-t-transparent"></div>
          </div>
        </div>
      </div>
    );
  }

  if (isError || !candidate) {
    return (
      <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
        <div className="bg-white p-8 shadow-2xl w-full max-w-2xl">
          <div className="text-center py-8">
            <p className="text-slate-600">Erreur lors du chargement du candidat</p>
            <button
              onClick={onClose}
              className="mt-4 px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white transition-colors rounded-lg"
            >
              Fermer
            </button>
          </div>
        </div>
      </div>
    );
  }

  const fullName = candidate.first_name && candidate.last_name
    ? `${candidate.first_name} ${candidate.last_name}`
    : `Candidat ${candidate.id.slice(-8)}`;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-slate-200 p-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-teal-600 flex items-center justify-center">
              <User size={24} weight="bold" className="text-white" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-slate-900">{fullName}</h2>
              <p className="text-sm text-slate-500">Détails du candidat</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-100 transition-colors"
          >
            <X size={20} weight="bold" />
          </button>
        </div>

        {/* Tabs */}
        <div className="border-b border-slate-200 px-6">
          <div className="flex gap-4">
            <button
              onClick={() => setActiveTab('details')}
              className={`px-4 py-3 font-medium text-sm border-b-2 transition-colors ${
                activeTab === 'details'
                  ? 'border-teal-600 text-teal-700'
                  : 'border-transparent text-slate-600 hover:text-slate-900'
              }`}
            >
              Détails & Compétences
            </button>
            {candidate.files && candidate.files.filter(f => f.mime === 'application/pdf').length > 0 && (
              <button
                onClick={() => {
                  setActiveTab('pdf');
                  const firstPdf = candidate.files.find(f => f.mime === 'application/pdf');
                  if (!selectedFileId && firstPdf) {
                    setSelectedFileId(firstPdf.id);
                  }
                }}
                className={`px-4 py-3 font-medium text-sm border-b-2 transition-colors ${
                  activeTab === 'pdf'
                    ? 'border-teal-600 text-teal-700'
                    : 'border-transparent text-slate-600 hover:text-slate-900'
                }`}
              >
                <FilePdf size={16} weight="bold" className="inline mr-2" />
                Documents ({candidate.files.filter(f => f.mime === 'application/pdf').length})
              </button>
            )}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {activeTab === 'details' ? (
            <>
          {/* 360° Candidate Profile Overview - ATS Style */}
          {candidate.profiles && candidate.profiles.length > 0 && (candidate.profiles[0].summary || candidate.profiles[0].current_title || candidate.profiles[0].email) && (
            <div className="bg-gradient-to-r from-teal-50 to-blue-50 border border-teal-200 rounded-lg p-5">
              <div className="space-y-4">
                {/* Professional Summary */}
                {candidate.profiles[0]?.summary && (
                  <div>
                    <h3 className="font-bold text-slate-900 mb-2 flex items-center gap-2">
                      <Briefcase size={18} className="text-teal-600" />
                      Résumé Professionnel
                    </h3>
                    <p className="text-sm text-slate-700 leading-relaxed">{candidate.profiles[0].summary}</p>
                  </div>
                )}
                
                {/* Contact & Location */}
                <div className="grid grid-cols-2 gap-3 text-sm">
                  {candidate.profiles[0]?.current_title && (
                    <div className="flex items-center gap-2">
                      <Briefcase size={16} className="text-teal-600" />
                      <span className="font-medium">{candidate.profiles[0].current_title}</span>
                    </div>
                  )}
                  {candidate.profiles[0]?.location && (
                    <div className="flex items-center gap-2">
                      <MapPin size={16} className="text-teal-600" />
                      <span className="text-slate-600">{candidate.profiles[0].location}</span>
                    </div>
                  )}
                  {candidate.profiles[0]?.email && (
                    <div className="flex items-center gap-2">
                      <Envelope size={16} className="text-teal-600" />
                      <a 
                        href={`mailto:${candidate.profiles[0].email}`} 
                        className="text-[#005149] hover:underline text-xs font-medium"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {candidate.profiles[0].email}
                      </a>
                    </div>
                  )}
                  {candidate.profiles[0]?.phone && (
                    <div className="flex items-center gap-2">
                      <Phone size={16} className="text-teal-600" />
                      <a 
                        href={`tel:${candidate.profiles[0].phone}`} 
                        className="text-[#005149] hover:underline font-medium"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {candidate.profiles[0].phone}
                      </a>
                    </div>
                  )}
                </div>
                
                {/* Education & Certifications */}
                {(candidate.profiles[0]?.education?.length > 0 || candidate.profiles[0]?.certifications?.length > 0) && (
                  <div className="grid grid-cols-1 gap-3">
                    {candidate.profiles[0].education?.length > 0 && (
                      <div>
                        <h4 className="text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                          <GraduationCap size={14} /> Formation
                        </h4>
                        <div className="space-y-1">
                          {candidate.profiles[0].education.slice(0, 2).map((edu, idx) => (
                            <p key={idx} className="text-xs text-slate-600">{edu}</p>
                          ))}
                        </div>
                      </div>
                    )}
                    {candidate.profiles[0].certifications?.length > 0 && (
                      <div>
                        <h4 className="text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                          <Certificate size={14} /> Certifications
                        </h4>
                        <div className="flex flex-wrap gap-1">
                          {candidate.profiles[0].certifications.map((cert, idx) => (
                            <span key={idx} className="px-2 py-0.5 bg-teal-100 text-teal-800 rounded text-xs">{cert}</span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
                
                {/* Confidence Badge */}
                {candidate.profiles[0]?.confidence && (
                  <div className="flex items-center gap-2 pt-2 border-t border-teal-200">
                    <CheckCircle size={16} className="text-teal-600" />
                    <span className="text-xs font-medium text-teal-700">
                      Précision d'extraction: {Math.round(candidate.profiles[0].confidence * 100)}%
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}
          
          {/* Basic Info */}
          <div className="border border-slate-200 p-4">
            <h3 className="font-semibold text-slate-900 mb-3">Informations</h3>
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2">
                <Calendar size={16} weight="bold" className="text-slate-400" />
                <span className="text-slate-600">Créé le:</span>
                <span className="font-medium">{fmtDate(candidate.created_at)}</span>
              </div>
              <div className="flex items-center gap-2">
                <FilePdf size={16} weight="bold" className="text-slate-400" />
                <span className="text-slate-600">CV uploadés:</span>
                <span className="font-medium">{candidate.profiles?.length || 0}</span>
              </div>
            </div>
          </div>

          {/* Documents */}
          <div className="border border-slate-200 p-4">
            <h3 className="font-semibold text-slate-900 mb-3">Documents</h3>
            {candidate.files && candidate.files.length > 0 ? (
              <div className="space-y-2">
                {candidate.files.map((f) => (
                  <div key={f.id} className="bg-white rounded border border-slate-200 p-3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-sm text-slate-700 flex items-center gap-2">
                        <span className="font-medium capitalize">{(f.kind || 'document').replace('_',' ')}</span>
                        <span className="text-slate-400">•</span>
                        <span className="truncate max-w-[280px]" title={f.file_name}>{f.file_name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {f.mime === 'application/pdf' && (
                          <button
                            className="text-teal-700 hover:text-teal-800 text-sm underline"
                            onClick={() => { setActiveTab('pdf'); setSelectedFileId(f.id); }}
                          >
                            Voir
                          </button>
                        )}
                        <a
                          href={`${API_BASE}/api/files/${f.id}`}
                          target="_blank"
                          rel="noreferrer"
                          className="text-slate-700 hover:text-slate-900 text-sm underline"
                        >
                          Télécharger
                        </a>
                      </div>
                    </div>
                    {f.parsed_context && f.parsed_context.summary && (
                      <div className="mt-2 pt-2 border-t border-slate-100">
                        <p className="text-xs text-slate-600 line-clamp-2">{f.parsed_context.summary}</p>
                        {f.parsed_context.key_points && Array.isArray(f.parsed_context.key_points) && f.parsed_context.key_points.length > 0 && (
                          <div className="mt-1 flex flex-wrap gap-1">
                            {f.parsed_context.key_points.slice(0, 3).map((point, idx) => (
                              <span key={idx} className="text-xs px-2 py-0.5 bg-teal-50 text-teal-700 rounded">
                                {typeof point === 'string' ? point : JSON.stringify(point)}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-slate-500">Aucun document</p>
            )}
          </div>

          {/* Applications in Pipeline */}
          {applications.length > 0 && (
            <div className="bg-gradient-to-br from-teal-50 to-blue-50 border border-teal-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold text-slate-900 flex items-center gap-2">
                  <Buildings size={18} weight="fill" className="text-teal-600" />
                  Processus de recrutement en cours ({applications.length})
                </h3>
                <button
                  onClick={() => navigate('/tracker')}
                  className="text-sm text-teal-600 hover:text-teal-700 font-medium flex items-center gap-1"
                >
                  Voir pipeline
                  <ArrowRight size={14} weight="bold" />
                </button>
              </div>
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {applications.map((app) => (
                  <div
                    key={app.id}
                    className="bg-white rounded-lg p-3 border border-slate-200 hover:border-teal-300 transition-colors cursor-pointer"
                    onClick={() => navigate('/tracker')}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="font-semibold text-slate-900 text-sm">
                          {app.offer_title}
                        </div>
                        <div className="text-xs text-slate-600 mt-1">
                          Ajouté le {new Date(app.date_bookmarked || app.created_at).toLocaleDateString('fr-FR')}
                        </div>
                      </div>
                      {app.match_score && (
                        <div className="flex items-center gap-1 text-xs font-bold text-teal-600">
                          <Star size={12} weight="fill" />
                          {app.match_score}%
                        </div>
                      )}
                    </div>
                    <div className={`inline-block px-2 py-1 rounded text-xs font-medium ${
                      app.stage === 'bookmarked' ? 'bg-slate-100 text-slate-700' :
                      app.stage === 'applying' ? 'bg-[#CCE5E3] text-[#005149]' :
                      app.stage === 'applied' ? 'bg-[#CCE5E3] text-[#00413A]' :
                      app.stage === 'interviewing' ? 'bg-[#FDF3DB] text-[#C18618]' :
                      app.stage === 'negotiating' ? 'bg-[#FCE5E1] text-[#D93E26]' :
                      'bg-[#CCE5E3] text-[#005149]'
                    }`}>
                      <span className="flex items-center gap-1">
                        {app.stage === 'bookmarked' && <><Bookmark size={12} weight="fill" /> Sauvegardé</>}
                        {app.stage === 'applying' && <><PaperPlaneTilt size={12} weight="fill" /> En cours</>}
                        {app.stage === 'applied' && <><CheckCircle size={12} weight="fill" /> Postulé</>}
                        {app.stage === 'interviewing' && <><UsersThree size={12} weight="fill" /> Entretien</>}
                        {app.stage === 'negotiating' && <><Handshake size={12} weight="fill" /> Négociation</>}
                        {app.stage === 'accepted' && <><Trophy size={12} weight="fill" /> Accepté</>}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Profiles/CVs */}
          {candidate.profiles && candidate.profiles.length > 0 ? (
            <div className="border border-slate-200 p-4">
              <h3 className="font-semibold text-slate-900 mb-3">CV et Compétences</h3>
              <div className="space-y-4">
                {candidate.profiles.map((profile, index) => (
                  <div key={profile.id} className="border-l-4 border-teal-600 pl-4 py-2 bg-slate-50">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-slate-900">CV #{index + 1}</h4>
                      <span className="text-xs text-slate-500">{fmtDate(profile.created_at)}</span>
                    </div>
                    
                    {/* Years of Experience */}
                    <div className="mb-3">
                      <span className="text-sm text-slate-600">Expérience:</span>
                      <span className="ml-2 font-semibold text-teal-700">
                        {profile.years_experience} {profile.years_experience > 1 ? 'ans' : 'an'}
                      </span>
                    </div>

                    {/* Hard Skills with Proficiency */}
                    {profile.hard_skills && profile.hard_skills.length > 0 && (
                      <div className="mb-4">
                        <div className="flex items-center gap-2 mb-3">
                          <Wrench size={16} weight="fill" className="text-teal-600" />
                          <span className="text-sm font-semibold text-slate-700 uppercase tracking-wide">Compétences Techniques</span>
                          <div className="flex-1 h-px bg-slate-200"></div>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {profile.hard_skills.map((skill, idx) => (
                            <span
                              key={idx}
                              className="px-3 py-1.5 bg-[#E6F2F1] text-[#005149] text-sm font-medium rounded-md border border-[#CCE5E3] hover:bg-[#CCE5E3] transition-colors"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Soft Skills with Proficiency */}
                    {profile.soft_skills && profile.soft_skills.length > 0 && (
                      <div className="mb-4">
                        <div className="flex items-center gap-2 mb-3">
                          <Lightbulb size={16} weight="fill" className="text-slate-600" />
                          <span className="text-sm font-semibold text-slate-700 uppercase tracking-wide">Compétences Interpersonnelles</span>
                          <div className="flex-1 h-px bg-slate-200"></div>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {profile.soft_skills.map((skill, idx) => (
                            <span
                              key={idx}
                              className="px-3 py-1.5 bg-[#E6F2F1] text-[#005149] text-sm font-medium rounded-md border border-[#CCE5E3] hover:bg-[#CCE5E3] transition-colors"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* All Skills (fallback if hard/soft not available) */}
                    {(!profile.hard_skills || profile.hard_skills.length === 0) && (!profile.soft_skills || profile.soft_skills.length === 0) && (
                      <div>
                        <div className="flex items-center gap-2 mb-3">
                          <span className="text-sm font-semibold text-slate-700 uppercase tracking-wide">Compétences</span>
                          <div className="flex-1 h-px bg-slate-200"></div>
                        </div>
                        <div className="flex flex-wrap gap-2">
                          {profile.skills && profile.skills.length > 0 ? (
                            profile.skills.map((skill, idx) => (
                              <span
                                key={idx}
                                className="px-3 py-1.5 bg-[#E6F2F1] text-[#005149] text-sm font-medium rounded-md border border-[#CCE5E3] hover:bg-[#CCE5E3] transition-colors"
                              >
                                {skill}
                              </span>
                            ))
                          ) : (
                            <span className="text-sm text-slate-400">Aucune compétence détectée</span>
                          )}
                        </div>
                      </div>
                    )}
                    
                    {/* ATS-Style Categorized Keywords for Candidates */}
                    {profile.technical_skills_keywords && Object.keys(profile.technical_skills_keywords).length > 0 && (
                      <div className="mt-4 bg-teal-50 border border-teal-200 rounded p-3">
                        <h6 className="text-xs font-bold text-slate-900 mb-2 flex items-center gap-1"><Desktop size={14} weight="fill" className="text-teal-600" /> Technical Skills</h6>
                        <div className="flex flex-wrap gap-1.5">
                          {Object.entries(profile.technical_skills_keywords).map(([keyword, count]) => (
                            <span key={keyword} className="px-2 py-0.5 bg-teal-100 text-teal-800 rounded-full text-xs">
                              {keyword} {count > 1 && <span className="text-teal-600">{count}</span>}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {profile.domain_expertise_keywords && Object.keys(profile.domain_expertise_keywords).length > 0 && (
                      <div className="mt-3 bg-slate-50 border border-slate-200 rounded p-3">
                        <h6 className="text-xs font-bold text-slate-900 mb-2 flex items-center gap-1"><Buildings size={14} weight="fill" className="text-slate-600" /> Domain Expertise</h6>
                        <div className="flex flex-wrap gap-1.5">
                          {Object.entries(profile.domain_expertise_keywords).map(([keyword, count]) => (
                            <span key={keyword} className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-full text-xs">
                              {keyword} {count > 1 && <span className="text-slate-600">{count}</span>}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                    
                    {profile.soft_skills_keywords && Object.keys(profile.soft_skills_keywords).length > 0 && (
                      <div className="mt-3 bg-slate-50 border border-slate-200 rounded p-3">
                        <h6 className="text-xs font-bold text-slate-900 mb-2 flex items-center gap-1"><Lightbulb size={14} weight="fill" className="text-slate-600" /> Soft Skills</h6>
                        <div className="flex flex-wrap gap-1.5">
                          {Object.entries(profile.soft_skills_keywords).map(([keyword, count]) => (
                            <span key={keyword} className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-full text-xs">
                              {keyword} {count > 1 && <span className="text-slate-600">{count}</span>}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="border border-slate-200 p-8 text-center">
              <FilePdf size={48} weight="bold" className="text-slate-300 mx-auto mb-3" />
              <p className="text-slate-600">Aucun CV uploadé pour ce candidat</p>
              <p className="text-sm text-slate-400 mt-1">Utilisez le bouton "Upload" pour ajouter un CV</p>
            </div>
          )}
            </>
          ) : (
            /* PDF Viewer Tab */
            <div className="space-y-4">
              {candidate.files && candidate.files.filter(f => f.mime === 'application/pdf').length > 0 && (
                <div className="flex gap-2 flex-wrap border-b border-slate-200 pb-3">
                  {candidate.files.filter(f => f.mime === 'application/pdf').map((file) => (
                    <button
                      key={file.id}
                      onClick={() => setSelectedFileId(file.id)}
                      className={`px-3 py-2 text-sm rounded-lg transition-colors ${
                        selectedFileId === file.id
                          ? 'bg-teal-600 text-white'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {file.kind.replace('_', ' ').toUpperCase()}
                    </button>
                  ))}
                </div>
              )}
              <div className="h-[70vh]">
                {selectedFileId ? (
                  <iframe
                    src={`${API_BASE}/api/files/${selectedFileId}/pdf`}
                    className="w-full h-full border border-slate-200"
                    title="Document PDF"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full">
                    <p className="text-slate-500">Sélectionnez un document à visualiser</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-200 p-4 bg-slate-50 flex justify-between items-center">
          <button
            onClick={handleDelete}
            disabled={isDeleting}
            className="px-6 py-2 bg-white hover:bg-red-50 text-red-600 hover:text-red-700 font-medium transition-colors flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg border border-red-600 hover:border-red-700"
          >
            {isDeleting ? (
              <>
                <div className="animate-spin h-4 w-4 border-2 border-slate-400 border-t-transparent rounded-full"></div>
                Suppression...
              </>
            ) : (
              <>
                <Trash size={18} weight="bold" />
                Supprimer
              </>
            )}
          </button>
          <button
            onClick={onClose}
            className="px-6 py-2 bg-teal-600 hover:bg-teal-700 text-white font-medium transition-colors rounded-lg"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
