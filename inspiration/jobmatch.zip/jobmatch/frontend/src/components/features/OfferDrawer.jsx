import { useState } from 'react';
import useSWR from 'swr';
import { X, CaretDown, CaretUp, Sparkle, CircleNotch, Medal, MapPin, Briefcase, CurrencyDollar, House, Buildings, Users, TrendUp, Trash, PencilSimple, User, Star, ArrowRight, ListChecks, Lightbulb } from '@phosphor-icons/react';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Chip } from '../ui/Chip';
import { Button } from '../ui/Button';
import { useOffer } from '../../lib/useApi';
import { matchOffer, listApplications } from '../../lib/api';
import { showToast } from '../ui/Toast';
import { OfferEditModal } from './OfferEditModal';
import axios from 'axios';
import { mutate } from 'swr';
import { useNavigate } from 'react-router-dom';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000';

export const OfferDrawer = ({ offerId, onClose, onMatchResults, onDelete }) => {
  const { offer, isLoading } = useOffer(offerId);
  const [showDescription, setShowDescription] = useState(false);
  const [isMatching, setIsMatching] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const navigate = useNavigate();
  
  // Fetch applications for this offer
  const { data: applicationsData } = useSWR(
    offerId ? `applications-${offerId}` : null,
    () => offerId ? listApplications(offerId) : null,
    { refreshInterval: 5000 }
  );
  const applications = applicationsData?.applications || [];
  
  const handleDelete = async () => {
    if (!confirm('Êtes-vous sûr de vouloir supprimer cette offre ? Cette action est irréversible.')) {
      return;
    }
    
    setIsDeleting(true);
    try {
      await axios.delete(`${API_BASE}/api/offers/${offerId}`);
      showToast('Offre supprimée avec succès', 'success');
      onDelete?.();
      onClose();
    } catch (error) {
      console.error('Error deleting offer:', error);
      showToast(error.response?.data?.detail || 'Erreur lors de la suppression', 'error');
    } finally {
      setIsDeleting(false);
    }
  };
  
  const handleMatch = async () => {
    setIsMatching(true);
    
    try {
      const topK = parseInt(import.meta.env.VITE_MATCH_TOPK || '5');
      const results = await matchOffer(offerId, topK);
      showToast(`${results.results.length} candidats matchés et ajoutés au pipeline`, 'success');
      // Refresh applications
      mutate(`applications-${offerId}`);
      onMatchResults?.(results);
    } catch (error) {
      console.error('Error matching:', error);
      showToast(
        error.response?.data?.detail || 'Erreur lors du matching',
        'error'
      );
    } finally {
      setIsMatching(false);
    }
  };
  
  if (isLoading || !offer) {
    return (
      <div className="fixed right-0 top-0 bottom-0 w-[550px] bg-white shadow-2xl z-30 p-8">
        <div className="flex items-center justify-center h-full">
          <CircleNotch className="h-10 w-10 text-teal-500 animate-spin" />
        </div>
      </div>
    );
  }
  
  const parsed = offer.parsed || {};
  
  return (
    <>
      <div 
        className="fixed inset-0 bg-black/30 z-40 backdrop-blur-sm"
        onClick={onClose}
      />
      <div className="fixed right-0 top-0 bottom-0 w-[550px] bg-white shadow-2xl z-50 overflow-y-auto">
        <div className="sticky top-0 bg-gradient-to-r from-teal-600 to-teal-500 text-white p-6 shadow-lg z-10">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className="text-xl font-bold mb-1">Détails de l'offre</h3>
              <p className="text-teal-100 text-sm">Analyse et correspondances</p>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>
        
        <div className="p-6 space-y-6">
          <div>
            <h4 className="text-xl font-bold text-slate-900 mb-3">
              {parsed.title || 'Sans titre'}
            </h4>
            
            {/* LinkedIn-style metadata */}
            <div className="space-y-2 mb-4">
              {parsed.company && (
                <div className="flex items-center gap-2 text-sm text-slate-700">
                  <Buildings className="h-4 w-4 text-slate-500" />
                  <span className="font-medium">{parsed.company}</span>
                </div>
              )}
              {parsed.location && (
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <MapPin className="h-4 w-4 text-slate-500" />
                  <span>{parsed.location}</span>
                </div>
              )}
              <div className="flex items-center gap-2 flex-wrap">
                {parsed.contract_type && (
                  <Badge variant="slate" className="text-xs">
                    <Briefcase className="h-3 w-3 mr-1 inline" />
                    {parsed.contract_type}
                  </Badge>
                )}
                {parsed.experience_level && (
                  <Badge variant="indigo" className="text-xs">
                    <TrendUp className="h-3 w-3 mr-1 inline" />
                    {parsed.experience_level}
                  </Badge>
                )}
                {parsed.remote_policy && (
                  <Badge variant="teal" className="text-xs">
                    <House className="h-3 w-3 mr-1 inline" />
                    {parsed.remote_policy}
                  </Badge>
                )}
                {parsed.salary_range && (
                  <Badge variant="green" className="text-xs">
                    <CurrencyDollar className="h-3 w-3 mr-1 inline" />
                    {parsed.salary_range}
                  </Badge>
                )}
              </div>
              {(parsed.team_size || parsed.industry) && (
                <div className="flex items-center gap-4 text-xs text-slate-600">
                  {parsed.team_size && (
                    <span className="flex items-center gap-1">
                      <Users className="h-3.5 w-3.5" />
                      {parsed.team_size}
                    </span>
                  )}
                  {parsed.industry && (
                    <span className="flex items-center gap-1">
                      <Buildings className="h-3.5 w-3.5" />
                      {parsed.industry}
                    </span>
                  )}
                </div>
              )}
            </div>
            
            <div className="flex items-center gap-3">
              <Badge variant="success" className="text-sm">
                <Medal className="h-3.5 w-3.5 mr-1 inline" />
                Confiance: {Math.round((parsed.confidence || 0) * 100)}%
              </Badge>
            </div>
          </div>
          
          {parsed.description && (
            <Card className="bg-slate-50 border-slate-200">
              <button
                onClick={() => setShowDescription(!showDescription)}
                className="w-full flex items-center justify-between text-left"
              >
                <span className="font-semibold text-slate-900">Description</span>
                {showDescription ? (
                  <CaretUp className="h-5 w-5 text-slate-500" />
                ) : (
                  <CaretDown className="h-5 w-5 text-slate-500" />
                )}
              </button>
              {showDescription && (
                <p className="mt-3 text-sm text-slate-600 whitespace-pre-wrap leading-relaxed">
                  {parsed.description}
                </p>
              )}
            </Card>
          )}
          
          {parsed.responsibilities && parsed.responsibilities.length > 0 && (
            <div>
              <h5 className="font-bold text-slate-900 mb-3">Responsabilités</h5>
              <ul className="space-y-2">
                {parsed.responsibilities.map((resp, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm text-slate-700">
                    <span className="text-teal-600 mt-0.5">•</span>
                    <span>{resp}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
          
          <div>
            <div className="flex items-center justify-between mb-3">
              <h5 className="font-bold text-slate-900">
                Compétences requises
              </h5>
              <Badge variant="teal">
                {parsed.must_haves?.length || 0}
              </Badge>
            </div>
            <div className="flex flex-wrap gap-2">
              {parsed.must_haves?.length > 0 ? (
                parsed.must_haves.map((skill, idx) => (
                  <Chip key={idx} variant="teal">
                    {skill}
                  </Chip>
                ))
              ) : (
                <p className="text-sm text-slate-500 italic">Aucune compétence requise</p>
              )}
            </div>
          </div>
          
          <div>
            <div className="flex items-center justify-between mb-3">
              <h5 className="font-bold text-slate-900">
                Compétences souhaitées
              </h5>
              <Badge variant="default">
                {parsed.nice_to_haves?.length || 0}
              </Badge>
            </div>
            <div className="flex flex-wrap gap-2">
              {parsed.nice_to_haves?.length > 0 ? (
                parsed.nice_to_haves.map((skill, idx) => (
                  <Chip key={idx} variant="mint">
                    {skill}
                  </Chip>
                ))
              ) : (
                <p className="text-sm text-slate-500 italic">Aucune compétence souhaitée</p>
              )}
            </div>
          </div>
          
          {parsed.benefits && parsed.benefits.length > 0 && (
            <div>
              <h5 className="font-bold text-slate-900 mb-3">Avantages</h5>
              <div className="flex flex-wrap gap-2">
                {parsed.benefits.map((benefit, idx) => (
                  <Chip key={idx} variant="purple">
                    {benefit}
                  </Chip>
                ))}
              </div>
            </div>
          )}
          
          {/* ATS-Style Categorized Keywords */}
          {parsed.requirements_keywords && Object.keys(parsed.requirements_keywords).length > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h5 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                <ListChecks size={18} weight="fill" className="text-blue-600" /> Requirements Keywords
              </h5>
              <div className="flex flex-wrap gap-2">
                {Object.entries(parsed.requirements_keywords).map(([keyword, count]) => (
                  <span key={keyword} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                    {keyword} {count > 1 && <span className="ml-1 text-blue-600">{count}</span>}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {parsed.responsibilities_keywords && Object.keys(parsed.responsibilities_keywords).length > 0 && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h5 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                <span className="text-green-600">✓</span> Job Responsibilities
              </h5>
              <div className="flex flex-wrap gap-2">
                {Object.entries(parsed.responsibilities_keywords).map(([keyword, count]) => (
                  <span key={keyword} className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm font-medium">
                    {keyword} {count > 1 && <span className="ml-1 text-green-600">{count}</span>}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {parsed.domain_keywords && Object.keys(parsed.domain_keywords).length > 0 && (
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
              <h5 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                <span className="text-purple-600">🏢</span> About the Job
              </h5>
              <div className="flex flex-wrap gap-2">
                {Object.entries(parsed.domain_keywords).map(([keyword, count]) => (
                  <span key={keyword} className="px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-sm font-medium">
                    {keyword} {count > 1 && <span className="ml-1 text-purple-600">{count}</span>}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {parsed.soft_skills_keywords && Object.keys(parsed.soft_skills_keywords).length > 0 && (
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
              <h5 className="font-bold text-slate-900 mb-3 flex items-center gap-2">
                <Lightbulb size={18} weight="fill" className="text-amber-600" /> Soft Skills
              </h5>
              <div className="flex flex-wrap gap-2">
                {Object.entries(parsed.soft_skills_keywords).map(([keyword, count]) => (
                  <span key={keyword} className="px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-sm font-medium">
                    {keyword} {count > 1 && <span className="ml-1 text-amber-600">{count}</span>}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {/* Matched Candidates Section */}
          {applications.length > 0 && (
            <div className="bg-gradient-to-br from-teal-50 to-blue-50 border border-teal-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h5 className="font-bold text-slate-900 flex items-center gap-2">
                  <Users className="h-5 w-5 text-teal-600" weight="fill" />
                  Candidats dans le pipeline ({applications.length})
                </h5>
                <button
                  onClick={() => navigate('/tracker')}
                  className="text-sm text-teal-600 hover:text-teal-700 font-medium flex items-center gap-1"
                >
                  Voir tout
                  <ArrowRight size={14} weight="bold" />
                </button>
              </div>
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {applications.slice(0, 5).map((app) => (
                  <div
                    key={app.id}
                    className="bg-white rounded-lg p-3 border border-slate-200 hover:border-teal-300 transition-colors cursor-pointer"
                    onClick={() => navigate('/tracker')}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="font-semibold text-slate-900 text-sm">
                          {app.candidate_name}
                        </div>
                        {app.current_title && (
                          <div className="text-xs text-slate-600">
                            {app.current_title}
                          </div>
                        )}
                      </div>
                      {app.match_score && (
                        <div className="flex items-center gap-1 text-xs font-bold text-teal-600">
                          <Star size={12} weight="fill" />
                          {app.match_score}%
                        </div>
                      )}
                    </div>
                    <div className="flex items-center justify-between">
                      <div className={`px-2 py-1 rounded text-xs font-medium ${
                        app.stage === 'bookmarked' ? 'bg-slate-100 text-slate-700' :
                        app.stage === 'applying' ? 'bg-[#CCE5E3] text-[#005149]' :
                        app.stage === 'applied' ? 'bg-[#CCE5E3] text-[#00413A]' :
                        app.stage === 'interviewing' ? 'bg-[#FDF3DB] text-[#C18618]' :
                        app.stage === 'negotiating' ? 'bg-[#FCE5E1] text-[#D93E26]' :
                        'bg-[#CCE5E3] text-[#005149]'
                      }`}>
                        {app.stage === 'bookmarked' ? 'Sauvegardé' :
                         app.stage === 'applying' ? 'En cours' :
                         app.stage === 'applied' ? 'Postulé' :
                         app.stage === 'interviewing' ? 'Entretien' :
                         app.stage === 'negotiating' ? 'Négociation' :
                         'Accepté'}
                      </div>
                      {app.top_skills && app.top_skills.length > 0 && (
                        <div className="flex gap-1">
                          {app.top_skills.slice(0, 2).map((skill, idx) => (
                            <span key={idx} className="px-2 py-0.5 bg-[#E6F2F1] text-[#005149] rounded text-xs">
                              {skill}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
              {applications.length > 5 && (
                <div className="mt-2 text-center text-xs text-slate-600">
                  +{applications.length - 5} autres candidats
                </div>
              )}
            </div>
          )}
          
          <div className="pt-4 border-t border-slate-200 space-y-3">
            <Button
              onClick={handleMatch}
              disabled={isMatching || isDeleting}
              className="w-full"
              size="lg"
            >
              {isMatching ? (
                <>
                  <CircleNotch className="h-5 w-5 animate-spin" />
                  Calcul en cours...
                </>
              ) : (
                <>
                  <Sparkle className="h-5 w-5" weight="fill" />
                  Matcher candidats
                </>
              )}
            </Button>
            
            <button
              onClick={() => setShowEditModal(true)}
              disabled={isDeleting || isMatching}
              className="w-full px-4 py-3 bg-white hover:bg-slate-50 text-[#005149] font-medium rounded-lg transition-colors flex items-center justify-center gap-2 border-2 border-[#005149] disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <PencilSimple className="h-5 w-5" />
              Modifier l'offre
            </button>
            
            <button
              onClick={handleDelete}
              disabled={isDeleting || isMatching}
              className="w-full px-4 py-3 bg-white hover:bg-red-50 text-[#E74E30] font-medium rounded-lg transition-colors flex items-center justify-center gap-2 border-2 border-[#E74E30] disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isDeleting ? (
                <>
                  <CircleNotch className="h-5 w-5 animate-spin" />
                  Suppression...
                </>
              ) : (
                <>
                  <Trash className="h-5 w-5" />
                  Supprimer cette offre
                </>
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Edit Modal */}
      {showEditModal && offer && (
        <OfferEditModal
          offer={offer}
          onClose={() => setShowEditModal(false)}
          onSuccess={() => {
            mutate(`${API_BASE}/api/offers/${offerId}`);
            mutate(['offers', 100]);
            showToast('Offre mise à jour avec succès', 'success');
          }}
        />
      )}
    </>
  );
};
