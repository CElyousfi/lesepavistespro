import { Users, Calendar, Loader2, FileUp } from 'lucide-react';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { Button } from '../ui/Button';
import { useCandidates } from '../../lib/useApi';
import { fmtDate, shortId } from '../../lib/format';

export const CandidateList = ({ onUploadCV, onSelectCandidate }) => {
  const { candidates, isLoading, isError } = useCandidates(20);
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="h-10 w-10 text-teal-500 animate-spin" />
      </div>
    );
  }
  
  if (isError) {
    return (
      <div className="text-center py-16">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 mb-4">
          <Users className="h-8 w-8 text-red-600" />
        </div>
        <p className="text-red-600 font-medium">Erreur lors du chargement des candidats</p>
        <p className="text-sm text-slate-500 mt-2">Veuillez réessayer plus tard</p>
      </div>
    );
  }
  
  if (candidates.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-100 mb-4">
          <Users className="h-10 w-10 text-slate-400" />
        </div>
        <p className="text-slate-700 font-medium text-lg">Aucun candidat pour le moment</p>
        <p className="text-sm text-slate-500 mt-2">Créez votre premier candidat en cliquant sur le bouton ci-dessus</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-3">
      {candidates.map((candidate) => (
        <div
          key={candidate.id}
          onClick={() => onSelectCandidate && onSelectCandidate(candidate.id)}
          className="bg-white p-4 border border-slate-200 rounded-lg hover:border-[#005149] hover:shadow-md transition-all duration-200 group cursor-pointer"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-slate-900 mb-1">
                {candidate.first_name && candidate.last_name ? (
                  <span>{candidate.first_name} {candidate.last_name}</span>
                ) : (
                  <span>Candidat {shortId(candidate.id)}</span>
                )}
              </h4>
              <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
                <Calendar className="h-3.5 w-3.5 flex-shrink-0" />
                <span>{fmtDate(candidate.created_at)}</span>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                {/* Document checklist summary */}
                {['resume','cover_letter','portfolio','certificate','id','contract'].map((k) => {
                  const has = (candidate.files_summary?.[k] || 0) > 0 || (k === 'resume' && candidate.profile_count > 0);
                  return (
                    <span key={k} className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wide ${has ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-slate-100 text-slate-500 border border-slate-200'}`}>
                      {k.replace('_',' ')}
                    </span>
                  );
                })}
                <Button
                  size="sm"
                  variant="secondary"
                  onClick={(e) => {
                    e.stopPropagation();
                    onUploadCV(candidate.id);
                  }}
                  className="text-xs"
                >
                  <FileUp className="h-3 w-3" />
                  Upload
                </Button>
              </div>
            </div>
            <div className="flex-shrink-0">
              <div className="w-8 h-8 rounded-lg bg-[#E6F2F1] flex items-center justify-center group-hover:bg-[#CCE5E3] transition-colors">
                <Users className="h-4 w-4 text-[#005149]" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
