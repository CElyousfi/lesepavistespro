import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { X, CircleNotch, FileText, Sparkle } from '@phosphor-icons/react';
import { Card } from '../ui/Card';
import { Textarea } from '../ui/Textarea';
import { Button } from '../ui/Button';
import { createOffer } from '../../lib/api';
import { showToast } from '../ui/Toast';
import { mutateOffers } from '../../lib/mutate';

export const OfferIngest = ({ onClose, onSuccess }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { register, handleSubmit, watch, formState: { errors } } = useForm();
  
  const rawText = watch('raw_text', '');
  
  const onSubmit = async (data) => {
    if (!data.raw_text || data.raw_text.length < 10) {
      showToast('Le texte doit contenir au moins 10 caractères', 'error');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const result = await createOffer(data.raw_text);
      showToast('Offre créée avec succès!', 'success');
      
      // Trigger global refresh of all offer data
      mutateOffers();
      
      onSuccess?.(result);
      onClose?.();
    } catch (error) {
      console.error('Error creating offer:', error);
      showToast(
        error.response?.data?.detail || 'Erreur lors de la création de l\'offre',
        'error'
      );
    } finally {
      setIsSubmitting(false);
    }
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] overflow-hidden">
        <div className="bg-gradient-to-r from-teal-600 to-teal-500 text-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                <FileText className="h-6 w-6" />
              </div>
              <div>
                <h3 className="text-2xl font-bold">Nouvelle offre d'emploi</h3>
                <p className="text-teal-100 text-sm mt-1">Analysée automatiquement par IA</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 rounded-lg p-2 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>
        
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          <div>
            <Textarea
              label="Texte de l'offre en français"
              placeholder="Collez ici le texte complet de l'offre d'emploi...

Exemple:
Nous recherchons un Développeur Full Stack avec 3 ans d'expérience.
Compétences requises: React, Node.js, PostgreSQL
Compétences souhaitées: Docker, AWS"
              rows={14}
              error={errors.raw_text?.message}
              {...register('raw_text', {
                required: 'Le texte est requis',
                minLength: { value: 10, message: 'Minimum 10 caractères' }
              })}
            />
            
            <div className="flex items-center justify-between mt-2">
              <div className="text-sm text-slate-500">
                {rawText.length} caractère{rawText.length > 1 ? 's' : ''}
              </div>
              {rawText.length >= 50 && (
                <div className="text-xs text-green-600 font-medium flex items-center gap-1">
                  <Sparkle className="h-3 w-3" weight="fill" />
                  Prêt pour l'analyse IA
                </div>
              )}
            </div>
          </div>
          
          <div className="flex gap-3 justify-end pt-4 border-t border-slate-200">
            <Button variant="secondary" onClick={onClose} type="button">
              Annuler
            </Button>
            <Button type="submit" disabled={isSubmitting || rawText.length < 10} size="lg">
              {isSubmitting ? (
                <>
                  <CircleNotch className="h-5 w-5 animate-spin" />
                  Analyse en cours...
                </>
              ) : (
                <>
                  <Sparkle className="h-5 w-5" weight="fill" />
                  Créer l'offre
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};
