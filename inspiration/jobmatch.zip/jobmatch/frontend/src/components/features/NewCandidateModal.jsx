import { useState } from 'react';
import { X, Upload, FilePdf, FileText, IdentificationCard, Certificate, Briefcase, ImagesSquare } from '@phosphor-icons/react';
import { Dropzone } from '../ui/Dropzone';
import { Button } from '../ui/Button';
import { uploadCandidateFile, createCandidate } from '../../lib/api';
import { showToast } from '../ui/Toast';

export const NewCandidateModal = ({ onClose, onCreated }) => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [files, setFiles] = useState({
    resume: null,
    cover_letter: null,
    portfolio: null,
    certificate: null,
    id: null,
    contract: null,
  });

  const kindToAccept = {
    resume: '.pdf',
    cover_letter: '.pdf,.doc,.docx,.txt',
    portfolio: '.pdf,.zip,.ppt,.pptx',
    certificate: '.pdf,.png,.jpg,.jpeg',
    id: '.pdf,.png,.jpg,.jpeg',
    contract: '.pdf',
  };

  const setFile = (kind) => (file) => setFiles((prev) => ({ ...prev, [kind]: file }));

  const handleCreate = async () => {
    if (!files.resume) {
      showToast('Le CV est obligatoire', 'error');
      return;
    }
    setIsSubmitting(true);
    try {
      const created = await createCandidate();
      const candidateId = created.id;

      // Upload resume first - this parses and extracts name/skills
      showToast('Analyse du CV en cours...', 'info');
      const resumeResult = await uploadCandidateFile(candidateId, files.resume, 'resume');
      console.log('Resume parsed:', resumeResult);
      
      // Validate the response
      if (!resumeResult) {
        throw new Error('No response from server');
      }
      
      if (!resumeResult.is_parsed) {
        console.warn('⚠️ Resume was not parsed successfully');
      }
      
      if (!resumeResult.skills || resumeResult.skills.length === 0) {
        console.warn('⚠️ No skills extracted from resume');
      }

      // Upload optional docs if present (non-blocking, parallel if needed)
      const optionalKinds = ['cover_letter', 'portfolio', 'certificate', 'id', 'contract'];
      const uploadPromises = [];
      for (const k of optionalKinds) {
        const f = files[k];
        if (f) {
          uploadPromises.push(uploadCandidateFile(candidateId, f, k).catch(err => {
            console.error(`Error uploading ${k}:`, err);
            // Don't fail the whole operation if optional doc fails
          }));
        }
      }
      
      if (uploadPromises.length > 0) {
        await Promise.all(uploadPromises);
      }

      // Wait a moment for database to be fully updated
      await new Promise(resolve => setTimeout(resolve, 500));

      const name = resumeResult.skills?.length > 0 
        ? `Candidat avec ${resumeResult.skills.length} compétence${resumeResult.skills.length > 1 ? 's' : ''}` 
        : 'Candidat créé';
      showToast(`${name}. Documents ajoutés avec succès.`, 'success');
      
      // Refresh lists and close immediately after success
      onCreated?.(candidateId);
      setIsSubmitting(false);
      onClose?.();
    } catch (e) {
      console.error('Error creating candidate:', e);
      showToast(e.response?.data?.detail || 'Erreur lors de la création', 'error');
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-2xl rounded-xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between p-4 border-b border-slate-200">
          <h3 className="text-lg font-bold text-slate-900">Nouveau candidat</h3>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded">
            <X size={18} />
          </button>
        </div>

        <div className="p-4 space-y-4">
          <p className="text-sm text-slate-600">Ajoutez les documents du candidat. Le CV est obligatoire.</p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-slate-700 flex items-center gap-2 mb-2">
                <FilePdf size={16} className="text-teal-700" /> CV (obligatoire)
              </label>
              <Dropzone accept={kindToAccept.resume} onFileSelect={setFile('resume')} />
              {files.resume && <p className="text-xs text-slate-600 mt-1">{files.resume.name}</p>}
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 flex items-center gap-2 mb-2">
                <FileText size={16} className="text-slate-600" /> Lettre de motivation (optionnel)
              </label>
              <Dropzone accept={kindToAccept.cover_letter} onFileSelect={setFile('cover_letter')} />
              {files.cover_letter && <p className="text-xs text-slate-600 mt-1">{files.cover_letter.name}</p>}
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 flex items-center gap-2 mb-2">
                <ImagesSquare size={16} className="text-slate-600" /> Portfolio (optionnel)
              </label>
              <Dropzone accept={kindToAccept.portfolio} onFileSelect={setFile('portfolio')} />
              {files.portfolio && <p className="text-xs text-slate-600 mt-1">{files.portfolio.name}</p>}
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 flex items-center gap-2 mb-2">
                <Certificate size={16} className="text-slate-600" /> Certificat (optionnel)
              </label>
              <Dropzone accept={kindToAccept.certificate} onFileSelect={setFile('certificate')} />
              {files.certificate && <p className="text-xs text-slate-600 mt-1">{files.certificate.name}</p>}
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 flex items-center gap-2 mb-2">
                <IdentificationCard size={16} className="text-slate-600" /> Pièce d'identité (optionnel)
              </label>
              <Dropzone accept={kindToAccept.id} onFileSelect={setFile('id')} />
              {files.id && <p className="text-xs text-slate-600 mt-1">{files.id.name}</p>}
            </div>

            <div>
              <label className="text-sm font-medium text-slate-700 flex items-center gap-2 mb-2">
                <Briefcase size={16} className="text-slate-600" /> Contrat (optionnel)
              </label>
              <Dropzone accept={kindToAccept.contract} onFileSelect={setFile('contract')} />
              {files.contract && <p className="text-xs text-slate-600 mt-1">{files.contract.name}</p>}
            </div>
          </div>
        </div>

        <div className="p-4 border-t border-slate-200 flex justify-end gap-2">
          <Button variant="secondary" onClick={onClose} disabled={isSubmitting}>Annuler</Button>
          <Button onClick={handleCreate} disabled={isSubmitting || !files.resume}>
            {isSubmitting ? 'Création...' : 'Créer et ajouter'}
          </Button>
        </div>
      </div>
    </div>
  );
};



