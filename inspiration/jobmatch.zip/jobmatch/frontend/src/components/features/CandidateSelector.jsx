import { useState } from 'react';
import useSWR from 'swr';
import { X, MagnifyingGlass, User, Briefcase, CircleNotch } from '@phosphor-icons/react';
import { listCandidates, createApplication } from '../../lib/api';
import { showToast } from '../ui/Toast';
import { mutate } from 'swr';

export const CandidateSelector = ({ offerId, onClose }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCandidates, setSelectedCandidates] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data: candidatesData, error } = useSWR('candidates-all', () => listCandidates(100));
  const candidates = candidatesData?.candidates || [];

  const filteredCandidates = candidates.filter(c =>
    c.first_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.last_name?.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.current_title?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const toggleCandidate = (candidateId) => {
    if (selectedCandidates.includes(candidateId)) {
      setSelectedCandidates(selectedCandidates.filter(id => id !== candidateId));
    } else {
      setSelectedCandidates([...selectedCandidates, candidateId]);
    }
  };

  const handleSubmit = async () => {
    if (selectedCandidates.length === 0) {
      showToast('Veuillez sélectionner au moins un candidat', 'error');
      return;
    }

    setIsSubmitting(true);
    try {
      let successCount = 0;
      let errorCount = 0;

      for (const candidateId of selectedCandidates) {
        try {
          await createApplication(offerId, candidateId, 'bookmarked');
          successCount++;
        } catch (error) {
          if (error.response?.status === 400) {
            // Already exists, count as success
            successCount++;
          } else {
            errorCount++;
          }
        }
      }

      if (successCount > 0) {
        showToast(`${successCount} candidat${successCount > 1 ? 's' : ''} ajouté${successCount > 1 ? 's' : ''} au pipeline`, 'success');
        mutate(`applications-${offerId}`);
        onClose();
      } else {
        showToast('Erreur lors de l\'ajout des candidats', 'error');
      }
    } catch (error) {
      console.error('Error adding candidates:', error);
      showToast('Erreur lors de l\'ajout des candidats', 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-slate-200 flex items-center justify-between">
          <h2 className="text-xl font-bold text-slate-900">
            Ajouter des candidats au pipeline
          </h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-100 rounded transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Search */}
        <div className="p-6 border-b border-slate-200">
          <div className="relative">
            <MagnifyingGlass size={20} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Rechercher un candidat..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#005149]"
            />
          </div>
          {selectedCandidates.length > 0 && (
            <div className="mt-3 text-sm text-[#005149] font-medium">
              {selectedCandidates.length} candidat{selectedCandidates.length > 1 ? 's' : ''} sélectionné{selectedCandidates.length > 1 ? 's' : ''}
            </div>
          )}
        </div>

        {/* Candidates List */}
        <div className="flex-1 overflow-y-auto p-6">
          {error && (
            <div className="text-center text-red-600 py-4">
              Erreur lors du chargement des candidats
            </div>
          )}

          {!error && filteredCandidates.length === 0 && (
            <div className="text-center text-slate-500 py-8">
              <User size={48} className="mx-auto mb-4 opacity-50" />
              <p>Aucun candidat trouvé</p>
            </div>
          )}

          <div className="space-y-2">
            {filteredCandidates.map((candidate) => {
              const isSelected = selectedCandidates.includes(candidate.id);
              const fullName = `${candidate.first_name || ''} ${candidate.last_name || ''}`.trim() || 'Nom inconnu';

              return (
                <div
                  key={candidate.id}
                  onClick={() => toggleCandidate(candidate.id)}
                  className={`
                    p-4 border-2 rounded-lg cursor-pointer transition-all
                    ${isSelected 
                      ? 'border-[#005149] bg-[#E6F2F1]' 
                      : 'border-slate-200 hover:border-[#005149] hover:bg-slate-50'
                    }
                  `}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="font-semibold text-slate-900 mb-1">
                        {fullName}
                      </div>
                      {candidate.current_title && (
                        <div className="flex items-center gap-2 text-sm text-slate-600 mb-2">
                          <Briefcase size={14} />
                          <span>{candidate.current_title}</span>
                        </div>
                      )}
                      {candidate.years_experience > 0 && (
                        <div className="text-sm text-slate-600">
                          {Math.round(candidate.years_experience)} ans d'expérience
                        </div>
                      )}
                      {candidate.top_skills && candidate.top_skills.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {candidate.top_skills.slice(0, 3).map((skill, idx) => (
                            <span
                              key={idx}
                              className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-xs"
                            >
                              {skill}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                    <div className={`
                      w-6 h-6 rounded border-2 flex items-center justify-center flex-shrink-0 ml-4
                      ${isSelected 
                        ? 'border-[#005149] bg-[#005149]' 
                        : 'border-slate-300'
                      }
                    `}>
                      {isSelected && (
                        <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                        </svg>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-slate-200 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            Annuler
          </button>
          <button
            onClick={handleSubmit}
            disabled={isSubmitting || selectedCandidates.length === 0}
            className="px-6 py-2 bg-[#005149] hover:bg-[#00413A] disabled:bg-slate-300 text-white font-medium rounded-lg transition-colors flex items-center gap-2 shadow-sm"
          >
            {isSubmitting ? (
              <>
                <CircleNotch size={20} className="animate-spin" />
                Ajout en cours...
              </>
            ) : (
              `Ajouter ${selectedCandidates.length > 0 ? `(${selectedCandidates.length})` : ''}`
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
