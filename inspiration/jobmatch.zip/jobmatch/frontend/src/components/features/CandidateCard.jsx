import { useState } from 'react';
import { 
  User, 
  MapPin, 
  Briefcase, 
  Calendar, 
  Eye, 
  Envelope,
  Phone,
  Code,
  Trophy,
  Download,
  FileText,
  Star,
  Clock
} from '@phosphor-icons/react';
import { formatDate, shortId } from '../../lib/format';
import { Chip } from '../ui/Chip';

export const CandidateCard = ({ candidate, onSelectCandidate, onUploadCV }) => {
  const [isHovered, setIsHovered] = useState(false);

  // Add safety checks for candidate data
  if (!candidate) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5">
        <p className="text-slate-500">Données du candidat indisponibles</p>
      </div>
    );
  }

  const fullName = candidate.first_name && candidate.last_name 
    ? `${candidate.first_name} ${candidate.last_name}`
    : `Candidat ${shortId(candidate.id)}`;

  const hasProfile = (candidate.profile_count || 0) > 0;
  const matchPercentage = candidate.total_offers > 0 
    ? Math.round((candidate.matched_offers_count / candidate.total_offers) * 100) 
    : 0;

  const getExperienceLevel = (years) => {
    if (years === 0) return { label: 'Débutant', color: 'bg-slate-100 text-slate-600' };
    if (years <= 2) return { label: 'Junior', color: 'bg-blue-100 text-blue-700' };
    if (years <= 5) return { label: 'Intermédiaire', color: 'bg-green-100 text-green-700' };
    if (years <= 10) return { label: 'Senior', color: 'bg-orange-100 text-orange-700' };
    return { label: 'Expert', color: 'bg-purple-100 text-purple-700' };
  };

  const experienceLevel = getExperienceLevel(candidate.years_experience || 0);

  const REQUIRED_KINDS = ['resume', 'cover_letter', 'portfolio', 'certificate', 'id', 'contract'];
  const filesSummary = candidate.files_summary || {};

  return (
    <div
      className="bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md hover:border-[#005149] transition-all duration-200 cursor-pointer group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={() => onSelectCandidate(candidate.id)}
    >
      {/* Header */}
      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1 min-w-0 pr-3">
            <h3 className="font-bold text-slate-900 text-xl mb-2 truncate">
              {fullName}
            </h3>
            <div className="flex items-center gap-2 text-sm text-slate-500 mb-3">
              <Calendar className="h-4 w-4 flex-shrink-0" />
              <span>Ajouté le {formatDate(candidate.created_at)}</span>
            </div>
            
            {/* Status Badge */}
            <div className={`inline-block px-3 py-1.5 rounded-md text-sm font-semibold ${
              hasProfile 
                ? 'bg-green-50 text-green-700 border border-green-200' 
                : 'bg-slate-50 text-slate-600 border border-slate-200'
            }`}>
              {hasProfile ? 'Profil complet' : 'Profil incomplet'}
            </div>
          </div>
          
          {/* Action Button */}
          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onSelectCandidate(candidate.id);
              }}
              className={`p-2.5 rounded-full transition-all duration-200 ${
                isHovered 
                  ? 'bg-[#005149] text-white shadow-md' 
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
              title="Voir le profil"
            >
              <Eye className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Match Score */}
        {candidate.matched_offers_count > 0 && (
          <div className="flex items-center gap-1.5 text-sm mb-4">
            <Star className="h-4 w-4 text-[#005149]" weight="fill" />
            <span className="font-semibold text-[#005149]">{candidate.matched_offers_count}</span>
            <span className="text-slate-500">match{candidate.matched_offers_count > 1 ? 'es' : ''}</span>
          </div>
        )}

        {/* Key Information */}
        <div className="space-y-3.5">
          {/* Current Position */}
          {candidate.current_title && (
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm text-slate-600 min-w-0 flex-shrink-0">
                <Briefcase className="h-4 w-4 text-slate-400 flex-shrink-0" />
                <span className="whitespace-nowrap">Poste actuel</span>
              </div>
              <div className="text-sm font-semibold text-slate-900 text-right truncate max-w-[60%]">
                {candidate.current_title}
              </div>
            </div>
          )}

          {/* Location */}
          {candidate.location && (
            <div className="flex items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm text-slate-600 min-w-0 flex-shrink-0">
                <MapPin className="h-4 w-4 text-slate-400 flex-shrink-0" />
                <span className="whitespace-nowrap">Localisation</span>
              </div>
              <div className="text-sm font-semibold text-slate-900 text-right truncate max-w-[60%]">
                {candidate.location}
              </div>
            </div>
          )}

          {/* Experience Level */}
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-sm text-slate-600 min-w-0 flex-shrink-0">
              <Trophy className="h-4 w-4 text-slate-400 flex-shrink-0" />
              <span className="whitespace-nowrap">Expérience</span>
            </div>
            <div className="flex items-center gap-2.5">
              <span className="text-sm font-semibold text-slate-900">
                {candidate.years_experience || 0} an{(candidate.years_experience || 0) > 1 ? 's' : ''}
              </span>
              <span className={`px-2.5 py-1 rounded-md text-xs font-semibold ${experienceLevel.color}`}>
                {experienceLevel.label}
              </span>
            </div>
          </div>

          {/* Skills */}
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2 text-sm text-slate-600 min-w-0 flex-shrink-0 pt-0.5">
              <Code className="h-4 w-4 text-slate-400 flex-shrink-0" />
              <span className="whitespace-nowrap">Compétences</span>
            </div>
            <div className="flex-1 text-right min-w-0">
              {candidate.top_skills && candidate.top_skills.length > 0 ? (
                <div className="flex flex-wrap gap-1.5 justify-end items-center">
                  {candidate.top_skills.slice(0, 2).map((skill, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 bg-teal-50 text-teal-700 text-xs font-semibold rounded-md border border-teal-200"
                    >
                      {skill}
                    </span>
                  ))}
                  {candidate.skills_count > 2 && (
                    <span className="px-2 py-0.5 text-xs text-slate-500 font-medium">
                      +{candidate.skills_count - 2}
                    </span>
                  )}
                </div>
              ) : (
                <span className="text-sm text-slate-400">Aucune compétence</span>
              )}
            </div>
          </div>

          {/* Contact Information */}
          {(candidate.email || candidate.phone) && (
            <div className="pt-4 border-t border-slate-100">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-sm text-slate-600 min-w-0 flex-shrink-0">
                  <User className="h-4 w-4 text-slate-400 flex-shrink-0" />
                  <span className="whitespace-nowrap">Contact</span>
                </div>
                <div className="flex items-center gap-3 flex-1 justify-end min-w-0">
                  {candidate.email && (
                    <a
                      href={`mailto:${candidate.email}`}
                      onClick={(e) => e.stopPropagation()}
                      className="flex items-center gap-1.5 text-xs text-[#005149] hover:text-[#00413A] transition-colors truncate"
                    >
                      <Envelope className="h-3.5 w-3.5 flex-shrink-0" />
                      <span className="truncate">{candidate.email}</span>
                    </a>
                  )}
                  {candidate.phone && (
                    <a
                      href={`tel:${candidate.phone}`}
                      onClick={(e) => e.stopPropagation()}
                      className="flex items-center gap-1.5 text-xs text-[#005149] hover:text-[#00413A] transition-colors flex-shrink-0"
                    >
                      <Phone className="h-3.5 w-3.5" />
                      <span>{candidate.phone}</span>
                    </a>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Documents */}
          <div className="pt-4 border-t border-slate-100">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2 text-sm text-slate-600 min-w-0 flex-shrink-0">
                <FileText className="h-4 w-4 text-slate-400 flex-shrink-0" />
                <span className="whitespace-nowrap">Documents</span>
              </div>
              <div className="flex flex-wrap items-center gap-1.5 flex-1 justify-end">
                {/* Checklist chips */}
                {REQUIRED_KINDS.map((k) => {
                  const has = (filesSummary[k] || 0) > 0 || (k === 'resume' && hasProfile);
                  return (
                    <span
                      key={k}
                      className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${
                        has 
                          ? 'bg-green-100 text-green-700 border border-green-300 shadow-sm' 
                          : 'bg-slate-100 text-slate-500 border border-slate-200'
                      }`}
                      title={has ? 'Téléversé' : 'Manquant'}
                    >
                      {k.replace('_', ' ')}
                    </span>
                  );
                })}
                {/* Upload quick action */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onUploadCV(candidate.id);
                  }}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold text-[#005149] hover:bg-teal-50 hover:text-[#00413A] rounded-md transition-colors border border-transparent hover:border-teal-200"
                >
                  <Download className="h-3.5 w-3.5" />
                  Upload
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
