import { Briefcase, Calendar, CircleNotch, FileText, MapPin, Buildings, House } from '@phosphor-icons/react';
import { Card } from '../ui/Card';
import { Badge } from '../ui/Badge';
import { useOffers } from '../../lib/useApi';
import { fmtDate } from '../../lib/format';

export const OfferList = ({ onSelectOffer }) => {
  const { offers, isLoading, isError } = useOffers(20);
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <CircleNotch className="h-10 w-10 text-teal-500 animate-spin" />
      </div>
    );
  }
  
  if (isError) {
    return (
      <div className="text-center py-16">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-red-100 mb-4">
          <FileText className="h-8 w-8 text-red-600" />
        </div>
        <p className="text-red-600 font-medium">Erreur lors du chargement des offres</p>
        <p className="text-sm text-slate-500 mt-2">Veuillez réessayer plus tard</p>
      </div>
    );
  }
  
  if (offers.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-100 mb-4">
          <Briefcase className="h-10 w-10 text-slate-400" />
        </div>
        <p className="text-slate-700 font-medium text-lg">Aucune offre pour le moment</p>
        <p className="text-sm text-slate-500 mt-2">Créez votre première offre en cliquant sur le bouton ci-dessus</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-3">
      {offers.map((offer) => (
        <div
          key={offer.id}
          onClick={() => onSelectOffer(offer.id)}
          className="bg-white rounded-lg p-4 border border-slate-200 hover:border-teal-400 hover:shadow-md transition-all duration-200 cursor-pointer group"
        >
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-slate-900 mb-1 group-hover:text-teal-700 transition-colors">
                {offer.title || 'Sans titre'}
              </h4>
              
              {/* Company and Location */}
              <div className="space-y-1 mb-2">
                {offer.company && offer.company !== 'Non spécifié' && (
                  <div className="flex items-center gap-1.5 text-xs text-slate-600">
                    <Buildings className="h-3.5 w-3.5 text-slate-400" weight="fill" />
                    <span>{offer.company}</span>
                  </div>
                )}
                {offer.location && offer.location !== 'Non spécifié' && (
                  <div className="flex items-center gap-1.5 text-xs text-slate-600">
                    <MapPin className="h-3.5 w-3.5 text-slate-400" weight="fill" />
                    <span>{offer.location}</span>
                  </div>
                )}
              </div>
              
              {/* Remote Policy and Date */}
              <div className="flex items-center gap-2 flex-wrap">
                {offer.remote_policy && (
                  <span className="inline-flex items-center gap-1 px-2 py-1 bg-teal-50 text-teal-700 rounded text-xs font-medium">
                    <House className="h-3 w-3" weight="fill" />
                    {offer.remote_policy === 'hybrid' ? 'Hybride' : 
                     offer.remote_policy === 'full_remote' ? 'Remote' : 
                     offer.remote_policy === 'flexible' ? 'Flexible' : 'Sur site'}
                  </span>
                )}
                <span className="inline-flex items-center gap-1 px-2 py-1 bg-slate-50 text-slate-600 rounded text-xs">
                  <Calendar className="h-3 w-3" />
                  {fmtDate(offer.created_at)}
                </span>
              </div>
            </div>
            <div className="flex-shrink-0">
              <div className="w-8 h-8 rounded-lg bg-teal-50 flex items-center justify-center group-hover:bg-teal-100 transition-colors">
                <Briefcase className="h-4 w-4 text-teal-600" />
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};
