import { X, Trophy, TrendUp, Medal, User, Brain, CheckCircle, WarningCircle, Info } from '@phosphor-icons/react';
import { Card } from '../ui/Card';
import { Chip } from '../ui/Chip';
import { Button } from '../ui/Button';
import { ProgressPill } from '../ui/ProgressPill';
import { Badge } from '../ui/Badge';
import { shortId, formatPercent } from '../../lib/format';

export const MatchResults = ({ matchData, onClose }) => {
  if (!matchData || !matchData.results) {
    return null;
  }
  
  // Helper to parse recommendation from explanation
  const parseRecommendation = (explanation) => {
    if (!explanation) return { recommendation: 'N/A', reasoning: '' };
    
    const parts = explanation.split(':');
    if (parts.length >= 2) {
      return {
        recommendation: parts[0].trim(),
        reasoning: parts.slice(1).join(':').trim()
      };
    }
    return { recommendation: 'N/A', reasoning: explanation };
  };
  
  // Helper to get recommendation badge style
  const getRecommendationStyle = (recommendation) => {
    const rec = recommendation.toLowerCase();
    if (rec.includes('highly') || rec.includes('fortement')) {
      return { bg: 'bg-green-100', text: 'text-green-800', icon: CheckCircle, iconColor: 'text-green-600' };
    }
    if (rec.includes('recommended') || rec.includes('recommandé')) {
      return { bg: 'bg-blue-100', text: 'text-blue-800', icon: CheckCircle, iconColor: 'text-blue-600' };
    }
    if (rec.includes('consider') || rec.includes('considérer') || rec.includes('à considérer')) {
      return { bg: 'bg-yellow-100', text: 'text-yellow-800', icon: Info, iconColor: 'text-yellow-600' };
    }
    if (rec.includes('non adapté') || rec.includes('not suitable')) {
      return { bg: 'bg-red-100', text: 'text-red-800', icon: WarningCircle, iconColor: 'text-red-600' };
    }
    return { bg: 'bg-slate-100', text: 'text-slate-800', icon: Info, iconColor: 'text-slate-600' };
  };
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-300">
        <div className="bg-gradient-to-r from-teal-600 to-teal-500 text-white p-8">
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-4">
              <div className="w-14 h-14 bg-white/20 rounded-xl flex items-center justify-center backdrop-blur-sm">
                <Trophy className="h-8 w-8" />
              </div>
              <div>
                <h3 className="text-3xl font-bold mb-2 flex items-center gap-3">
                  Résultats du matching
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 rounded-full text-sm font-medium backdrop-blur-sm">
                    <Brain className="h-4 w-4" />
                    AI-Powered
                  </span>
                </h3>
                <p className="text-teal-100 text-lg">
                  {matchData.offer_title || 'Offre'}
                </p>
                <p className="text-teal-200 text-sm mt-1">
                  {matchData.total_candidates} candidat{matchData.total_candidates > 1 ? 's' : ''} analysé{matchData.total_candidates > 1 ? 's' : ''} avec intelligence artificielle
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:bg-white/20 rounded-xl p-2.5 transition-colors"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-8">
          {matchData.results.length === 0 ? (
            <div className="text-center py-16">
              <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-slate-100 mb-4">
                <User className="h-10 w-10 text-slate-400" />
              </div>
              <p className="text-slate-700 font-medium text-lg">Aucun candidat trouvé</p>
              <p className="text-sm text-slate-500 mt-2">Essayez d'ajuster vos critères ou d'ajouter plus de candidats</p>
            </div>
          ) : (
            <div className="space-y-5">
              {matchData.results.map((result, index) => {
                const { recommendation, reasoning } = parseRecommendation(result.explanation);
                const recStyle = getRecommendationStyle(recommendation);
                const RecommendationIcon = recStyle.icon;
                
                return (
                <Card key={result.candidate_id} className="border-2 hover:border-teal-300">
                  <div className="flex gap-6">
                    <div className="flex-shrink-0">
                      <ProgressPill score={result.score} />
                      <div className="text-center mt-3">
                        <Badge variant="teal" className="text-xs font-bold">
                          #{index + 1}
                        </Badge>
                      </div>
                    </div>
                    
                    <div className="flex-1 space-y-4">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <h4 className="font-bold text-lg text-slate-900 flex items-center gap-2">
                            <User className="h-5 w-5 text-slate-500" />
                            {result.candidate_name || `Candidat ${shortId(result.candidate_id)}`}
                          </h4>
                          <p className="text-sm text-slate-600 mt-1">
                            <Medal className="h-4 w-4 inline mr-1" />
                            {result.years_experience} an{result.years_experience > 1 ? 's' : ''} d'expérience
                          </p>
                        </div>
                        <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${recStyle.bg} border-2 border-${recStyle.text.replace('text-', '')}/20`}>
                          <RecommendationIcon className={`h-5 w-5 ${recStyle.iconColor}`} />
                          <span className={`font-bold text-sm ${recStyle.text}`}>
                            {recommendation}
                          </span>
                        </div>
                      </div>
                      
                      {/* LLM Reasoning Box */}
                      {reasoning && (
                        <div className="bg-gradient-to-r from-indigo-50 to-purple-50 border-l-4 border-indigo-400 p-4 rounded-r-lg">
                          <div className="flex items-start gap-3">
                            <Brain className="h-5 w-5 text-indigo-600 flex-shrink-0 mt-0.5" />
                            <div>
                              <p className="text-xs font-bold text-indigo-900 mb-1 uppercase tracking-wide">
                                Analyse IA
                              </p>
                              <p className="text-sm text-slate-700 leading-relaxed">
                                {reasoning}
                              </p>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 p-4 bg-slate-50 rounded-lg">
                        <div className="text-center">
                          <div className="text-xl font-bold text-teal-600">
                            {formatPercent(result.required_coverage)}
                          </div>
                          <div className="text-xs text-slate-600 mt-1 font-medium">
                            <TrendUp className="h-3 w-3 inline mr-1" />
                            Requis
                          </div>
                        </div>
                        <div className="text-center">
                          <div className="text-xl font-bold text-teal-600">
                            {formatPercent(result.preferred_coverage)}
                          </div>
                          <div className="text-xs text-slate-600 mt-1 font-medium">
                            <TrendUp className="h-3 w-3 inline mr-1" />
                            Souhaité
                          </div>
                        </div>
                        {result.experience_fit !== undefined && (
                          <div className="text-center">
                            <div className="text-xl font-bold text-indigo-600">
                              {formatPercent(result.experience_fit)}
                            </div>
                            <div className="text-xs text-slate-600 mt-1 font-medium">
                              <Medal className="h-3 w-3 inline mr-1" />
                              Expérience
                            </div>
                          </div>
                        )}
                        {result.language_fit !== undefined && (
                          <div className="text-center">
                            <div className="text-xl font-bold text-purple-600">
                              {formatPercent(result.language_fit)}
                            </div>
                            <div className="text-xs text-slate-600 mt-1 font-medium">
                              <TrendUp className="h-3 w-3 inline mr-1" />
                              Langue
                            </div>
                          </div>
                        )}
                      </div>
                      
                      {result.matched_skills?.length > 0 && (
                        <div>
                          <p className="text-xs font-bold text-slate-700 mb-2 uppercase tracking-wide">
                            ✓ Compétences matchées ({result.matched_skills.length})
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {result.matched_skills.map((skill, idx) => (
                              <Chip key={idx} variant="teal" className="text-xs">
                                {skill}
                              </Chip>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {result.missing_must_haves?.length > 0 && (
                        <div>
                          <p className="text-xs font-bold text-red-700 mb-2 uppercase tracking-wide">
                            ✗ Compétences manquantes requises ({result.missing_must_haves.length})
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {result.missing_must_haves.map((skill, idx) => (
                              <Chip key={idx} variant="red" className="text-xs">
                                {skill}
                              </Chip>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {result.nice_hits?.length > 0 && (
                        <div>
                          <p className="text-xs font-bold text-teal-700 mb-2 uppercase tracking-wide">
                            + Compétences souhaitées matchées ({result.nice_hits.length})
                          </p>
                          <div className="flex flex-wrap gap-2">
                            {result.nice_hits.map((skill, idx) => (
                              <Chip key={idx} variant="mint" className="text-xs">
                                {skill}
                              </Chip>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </Card>
                );
              })}
            </div>
          )}
        </div>
        
        <div className="border-t border-slate-200 p-6 bg-slate-50">
          <div className="flex items-center justify-between">
            <p className="text-sm text-slate-600">
              Affichage de {matchData.results.length} meilleur{matchData.results.length > 1 ? 's' : ''} candidat{matchData.results.length > 1 ? 's' : ''}
            </p>
            <Button onClick={onClose} variant="secondary">
              <X className="h-4 w-4" />
              Fermer
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};
