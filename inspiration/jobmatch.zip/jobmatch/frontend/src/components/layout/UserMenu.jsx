import { useState, useRef, useEffect } from 'react';
import { SignOut, UserCircle, Gear, CaretDown } from '@phosphor-icons/react';
import { useAuth } from '../../contexts/AuthContext';
import clsx from 'clsx';

export const UserMenu = ({ isCollapsed }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { user, logout } = useAuth();
  const menuRef = useRef(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!user) return null;

  const getInitials = () => {
    return `${user.first_name?.[0] || ''}${user.last_name?.[0] || ''}`.toUpperCase();
  };

  const getRoleBadge = () => {
    return user.role === 'admin' ? 'Admin' : 'Recruiter';
  };

  const handleLogout = async () => {
    setIsOpen(false);
    await logout();
  };

  if (isCollapsed) {
    return (
      <div className="relative" ref={menuRef}>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full p-2 hover:bg-slate-100 transition-colors rounded-lg flex items-center justify-center"
        >
          <div className="w-8 h-8 bg-teal-600 rounded-full flex items-center justify-center text-white font-semibold text-sm">
            {getInitials()}
          </div>
        </button>

        {isOpen && (
          <div className="absolute bottom-full left-16 mb-2 w-56 bg-white rounded-lg shadow-xl border border-slate-200 py-2 z-50">
            <div className="px-4 py-3 border-b border-slate-200">
              <p className="font-semibold text-slate-900">{user.first_name} {user.last_name}</p>
              <p className="text-sm text-slate-600">{user.email}</p>
              <span className="inline-block mt-1 px-2 py-0.5 bg-teal-100 text-teal-700 text-xs rounded-full">
                {getRoleBadge()}
              </span>
            </div>

            <button
              onClick={handleLogout}
              className="w-full px-4 py-2 text-left hover:bg-slate-50 transition-colors flex items-center gap-3 text-slate-700"
            >
              <SignOut size={20} weight="bold" />
              <span>Log out</span>
            </button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full p-3 hover:bg-slate-100 transition-colors rounded-lg flex items-center gap-3"
      >
        <div className="w-10 h-10 bg-teal-600 rounded-full flex items-center justify-center text-white font-semibold">
          {getInitials()}
        </div>
        <div className="flex-1 text-left">
          <p className="font-semibold text-slate-900 text-sm">{user.first_name} {user.last_name}</p>
          <p className="text-xs text-slate-600">{getRoleBadge()}</p>
        </div>
        <CaretDown 
          size={16} 
          weight="bold" 
          className={clsx(
            "text-slate-400 transition-transform",
            isOpen && "rotate-180"
          )}
        />
      </button>

      {isOpen && (
        <div className="absolute bottom-full left-0 right-0 mb-2 bg-white rounded-lg shadow-xl border border-slate-200 py-2 z-50">
          <div className="px-4 py-2 border-b border-slate-200">
            <p className="text-xs text-slate-500">Signed in as</p>
            <p className="text-sm font-medium text-slate-900">{user.email}</p>
          </div>

          <button
            onClick={handleLogout}
            className="w-full px-4 py-2 text-left hover:bg-red-50 transition-colors flex items-center gap-3 text-red-600"
          >
            <SignOut size={20} weight="bold" />
            <span className="font-medium">Log out</span>
          </button>
        </div>
      )}
    </div>
  );
};
