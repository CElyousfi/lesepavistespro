import { useState } from 'react';
import { House, Briefcase, Users, Target, CaretLeft, CaretRight, ChartLine, Gear } from '@phosphor-icons/react';
import clsx from 'clsx';
import { UserMenu } from './UserMenu';
import { useAuth } from '../../contexts/AuthContext';

const navItems = [
  { id: 'dashboard', label: 'Tableau de bord', icon: House },
  { id: 'offers', label: 'Offres d\'emploi', icon: Briefcase },
  { id: 'candidates', label: 'Candidats', icon: Users },
  { id: 'tracker', label: 'Suivi Pipeline', icon: ChartLine },
];

export const Sidebar = ({ activeTab, onTabChange, isCollapsed, setIsCollapsed }) => {
  const { isAdmin } = useAuth();
  
  return (
    <div className={clsx(
      "fixed left-0 top-0 bottom-0 bg-white text-slate-900 shadow-lg z-40 border-r border-slate-200 transition-all duration-300",
      isCollapsed ? "w-16" : "w-64"
    )}>
      {/* Header with Logo */}
      <div className="p-4 border-b border-slate-200 flex items-center justify-between">
        {!isCollapsed && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-teal-500 to-teal-600 rounded-lg flex items-center justify-center shadow-sm">
              <Target size={20} weight="bold" className="text-white" />
            </div>
            <span className="text-lg font-bold bg-gradient-to-r from-teal-600 to-teal-700 bg-clip-text text-transparent">Meridian</span>
          </div>
        )}
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="p-2 hover:bg-slate-100 transition-colors"
        >
          {isCollapsed ? <CaretRight size={20} weight="bold" /> : <CaretLeft size={20} weight="bold" />}
        </button>
      </div>
      
      {/* Navigation */}
      <nav className="mt-2 px-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={clsx(
                'w-full flex items-center gap-3 px-3 py-3 text-left mb-1 font-medium transition-all duration-200',
                isActive
                  ? 'bg-teal-50 text-teal-700 border-l-4 border-teal-600'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              )}
              title={isCollapsed ? item.label : ''}
            >
              <Icon size={20} weight="bold" className="flex-shrink-0" />
              {!isCollapsed && (
                <span className="text-sm font-medium">{item.label}</span>
              )}
            </button>
          );
        })}

        {/* Admin Panel Link (Admin Only) */}
        {isAdmin && (
          <>
            <div className="my-2 border-t border-slate-200"></div>
            <button
              onClick={() => onTabChange('admin')}
              className={clsx(
                'w-full flex items-center gap-3 px-3 py-3 text-left mb-1 font-medium transition-all duration-200',
                activeTab === 'admin'
                  ? 'bg-purple-50 text-purple-700 border-l-4 border-purple-600'
                  : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
              )}
              title={isCollapsed ? 'Admin Panel' : ''}
            >
              <Gear size={20} weight="bold" className="flex-shrink-0" />
              {!isCollapsed && (
                <span className="text-sm font-medium">Admin Panel</span>
              )}
            </button>
          </>
        )}
      </nav>
      
      {/* User Menu at Bottom */}
      <div className="absolute bottom-0 left-0 right-0 p-2 border-t border-slate-200 bg-white">
        <UserMenu isCollapsed={isCollapsed} />
      </div>
    </div>
  );
};