export const Container = ({ children, sidebarCollapsed }) => {
  return (
    <div 
      className="min-h-screen bg-slate-50 transition-all duration-300"
      style={{ marginLeft: sidebarCollapsed ? '64px' : '256px' }}
    >
      <div className="max-w-[1800px] mx-auto">
        {children}
      </div>
    </div>
  );
};
