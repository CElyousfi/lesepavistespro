import { useState } from 'react';
import { BrowserRouter, Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import { SWRConfig } from 'swr';
import { AuthProvider } from './contexts/AuthContext';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { Sidebar } from './components/layout/Sidebar';
import { Container } from './components/layout/Container';
import { Toast } from './components/ui/Toast';
import { Dashboard } from './pages/Dashboard';
import { OffersPage } from './pages/OffersPage';
import { CandidatesPage } from './pages/CandidatesPage';
import { TrackerPage } from './pages/TrackerPage';
import { AdminPanel } from './pages/AdminPanel';
import { ActivatePage } from './pages/ActivatePage';
import { ActivateVerifyPage } from './pages/ActivateVerifyPage';
import { ActivateSetPasswordPage } from './pages/ActivateSetPasswordPage';
import { LoginPage } from './pages/LoginPage';
import { AcceptInvitePage } from './pages/AcceptInvitePage';

function AppContent() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  // Check if we're on an auth page (no sidebar)
  const isAuthPage = ['/activate', '/activate/verify', '/activate/set-password', '/login', '/accept-invite'].some(
    path => location.pathname.startsWith(path)
  );

  // Determine active tab from URL
  const getActiveTab = () => {
    if (location.pathname === '/offers') return 'offers';
    if (location.pathname === '/candidates') return 'candidates';
    if (location.pathname === '/tracker') return 'tracker';
    if (location.pathname === '/admin') return 'admin';
    return 'dashboard';
  };

  const handleTabChange = (tab) => {
    if (tab === 'dashboard') navigate('/');
    else navigate(`/${tab}`);
  };

  // Auth pages (no sidebar)
  if (isAuthPage) {
    return (
      <div className="min-h-screen">
        <Routes>
          <Route path="/activate" element={<ActivatePage />} />
          <Route path="/activate/verify" element={<ActivateVerifyPage />} />
          <Route path="/activate/set-password" element={<ActivateSetPasswordPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/accept-invite" element={<AcceptInvitePage />} />
        </Routes>
        <Toast />
      </div>
    );
  }

  // Main app pages (with sidebar) - Protected
  return (
    <ProtectedRoute>
      <div className="min-h-screen bg-slate-50">
        <Sidebar 
          activeTab={getActiveTab()} 
          onTabChange={handleTabChange}
          isCollapsed={sidebarCollapsed}
          setIsCollapsed={setSidebarCollapsed}
        />
        
        <Container sidebarCollapsed={sidebarCollapsed}>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/offers" element={<OffersPage />} />
            <Route path="/candidates" element={<CandidatesPage />} />
            <Route path="/tracker" element={<TrackerPage />} />
            <Route path="/admin" element={<AdminPanel />} />
          </Routes>
        </Container>

        <Toast />
      </div>
    </ProtectedRoute>
  );
}

function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <SWRConfig
          value={{
            revalidateOnFocus: true,  // Auto-refresh on window focus
            revalidateOnReconnect: true,  // Auto-refresh on reconnect
            refreshInterval: 5000,  // Auto-refresh every 5 seconds (like Facebook)
            dedupingInterval: 2000,
          }}
        >
          <AppContent />
        </SWRConfig>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
