# Test User Credentials

## 🔐 Login Credentials

### Admin User
- **Email**: `admin@test.com`
- **Password**: `admin123`
- **Role**: Admin
- **Permissions**: Full access (create users, manage system)

### Recruiter User
- **Email**: `recruiter@test.com`
- **Password**: `recruiter123`
- **Role**: Recruiter
- **Permissions**: Standard user access

---

## 🚀 How to Login

### Using the Frontend
1. Visit: http://127.0.0.1:5173/login
2. Enter email and password
3. Click "Sign In"

### Using the API
```bash
# Admin login
curl -X POST http://127.0.0.1:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"admin123"}' \
  -c cookies.txt

# Recruiter login
curl -X POST http://127.0.0.1:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"recruiter@test.com","password":"recruiter123"}' \
  -c cookies.txt
```

---

## ✅ Verified Working

- ✅ Both users can login
- ✅ Cookies are set correctly
- ✅ Auth endpoints work
- ✅ Existing offer/candidate endpoints work
- ✅ Unified backend running on port 8000

---

## 🔄 Backend Status

**Current Backend**: `main.py` (unified)
- ✅ All existing routes (offers, candidates, matching)
- ✅ All auth routes (login, logout, invites)
- ✅ Both Shot 1 and Shot 2 features

**Port**: 8000
**Status**: Running ✅

---

## 📝 Quick Test Commands

```bash
# Check if backend is running
curl http://127.0.0.1:8000/

# Login as admin
curl -X POST http://127.0.0.1:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"admin123"}' \
  -c cookies.txt

# Get current user
curl -b cookies.txt http://127.0.0.1:8000/api/auth/me

# List offers
curl http://127.0.0.1:8000/api/offers?limit=10

# List candidates
curl http://127.0.0.1:8000/api/candidates?limit=10
```

---

## 🎯 What You Can Test Now

### With Admin Account
- ✅ Login/logout
- ✅ Create/view offers
- ✅ Create/view candidates
- ✅ Match candidates to offers
- ✅ Invite new users
- ✅ View seat usage
- ✅ Manage applications

### With Recruiter Account
- ✅ Login/logout
- ✅ Create/view offers
- ✅ Create/view candidates
- ✅ Match candidates to offers
- ✅ Manage applications
- ❌ Cannot invite users (admin only)

---

**Note**: The database is currently empty. You can create test data through the frontend or API.
